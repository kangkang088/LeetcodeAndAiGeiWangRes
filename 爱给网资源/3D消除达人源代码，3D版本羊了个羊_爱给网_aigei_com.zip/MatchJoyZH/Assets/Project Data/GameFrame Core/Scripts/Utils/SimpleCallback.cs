﻿
public delegate void SimpleCallback();
public delegate void SimpleFloatCallback(float value);
public delegate void SimpleIntCallback(int value);
public delegate void SimpleBoolCallback(bool value);
