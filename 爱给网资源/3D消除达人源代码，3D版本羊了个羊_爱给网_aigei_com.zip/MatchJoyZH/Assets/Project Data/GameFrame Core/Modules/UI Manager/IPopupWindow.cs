namespace PandaXGame
{
    public interface IPopupWindow 
    {
        bool IsOpened { get; }
    }
}
