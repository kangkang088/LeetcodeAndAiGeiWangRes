﻿#pragma warning disable 0649

using UnityEngine;

namespace PandaXGame
{
    [RegisterModule("Core/Audio Controller")]
    public class AudioControllerInitModule : InitModule
    {
        [SerializeField] AudioSettings audioSettings;

        [Space]
        [SerializeField] bool playRandomMusic = true;

        public override void CreateComponent(Initialiser initialiser)
        {
            AudioController audioController = new AudioController();
            audioController.Initialise(audioSettings, initialiser.gameObject);

            // Create audio listener
            AudioController.CreateAudioListener();
        }

        public AudioControllerInitModule()
        {
            moduleName = "Audio Controller";
        }
    }
}