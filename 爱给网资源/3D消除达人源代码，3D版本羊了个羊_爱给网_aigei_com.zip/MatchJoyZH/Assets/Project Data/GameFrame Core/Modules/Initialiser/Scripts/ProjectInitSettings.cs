﻿#pragma warning disable 0649
using UnityEngine;

namespace PandaXGame
{
    [SetupTab("Init Settings", priority = 1, texture = "icon_puzzle")]
    [CreateAssetMenu(fileName = "Project Init Settings", menuName = "Settings/Project Init Settings")]
    public class ProjectInitSettings : ScriptableObject
    {
        [SerializeField] InitModule[] coreModules;
        public InitModule[] CoreModules => coreModules;

        [SerializeField] InitModule[] modules;
        public InitModule[] Modules => modules;

        public void Initialise(Initialiser initialiser)
        {
            // 控制模块初始化
            for (int i = 0; i < coreModules.Length; i++)
            {
                if(coreModules[i] != null)
                {
                    Debug.Log("coreModules CreateComponent : " + coreModules[i].name);
                    coreModules[i].CreateComponent(initialiser);
                }
            }

            for (int i = 0; i < modules.Length; i++)
            {
                if(modules[i] != null)
                {
                    Debug.Log("modules CreateComponent : " + modules[i].name);
                    modules[i].CreateComponent(initialiser);
                }
            }
        }
    }
}