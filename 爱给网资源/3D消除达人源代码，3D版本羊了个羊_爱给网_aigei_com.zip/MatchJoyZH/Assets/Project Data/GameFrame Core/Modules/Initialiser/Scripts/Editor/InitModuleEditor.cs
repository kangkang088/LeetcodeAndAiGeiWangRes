﻿using UnityEditor;

namespace PandaXGame
{
    public abstract class InitModuleEditor : Editor
    {
        public abstract void Buttons();
    }
}