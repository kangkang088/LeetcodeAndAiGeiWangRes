﻿#pragma warning disable 0649
#pragma warning disable 0414

using UnityEngine;

/// <summary>
/// 用来设置屏幕显示和帧率
/// </summary>
namespace PandaXGame
{
    [System.Serializable]
    public class ScreenSettings
    {
        public void Initialise()
        {
            Screen.sleepTimeout = -1;
            Application.targetFrameRate = 60;
        }
    }
}
