﻿#pragma warning disable 0649

using System;
using UnityEngine;
using UnityEngine.EventSystems;

namespace PandaXGame
{
    [DefaultExecutionOrder(-999)]
    public class Initialiser : MonoBehaviour
    {
        // 项目设置 
        [SerializeField] ProjectInitSettings initSettings;
        // 系统画布
        [SerializeField] Canvas systemCanvas;
        // 事件系统
        [SerializeField] EventSystem eventSystem;

        [Space]
        // 屏幕和帧率设置
        [SerializeField] ScreenSettings screenSettings;
        

        // 系统画布  -- 用来显示GDRP和模拟广告等使用
        public static Canvas SystemCanvas;
        
        public static GameObject InitialiserGameObject;

        public static bool IsInititalized { get; private set; }
        public static bool IsStartInitialized { get; private set; }
        // 系统设置
        public static ProjectInitSettings InitSettings { get; private set; }

        public void Awake()
        {
            // 设置屏幕参数和帧率
            screenSettings.Initialise();

            if (!IsInititalized)
            {
                IsInititalized = true;
                InitSettings = initSettings;
                SystemCanvas = systemCanvas;
                InitialiserGameObject = gameObject;
#if MODULE_INPUT_SYSTEM
                eventSystem.gameObject.AddComponent<UnityEngine.InputSystem.UI.InputSystemUIInputModule>();
#else
                eventSystem.gameObject.AddComponent<StandaloneInputModule>();
#endif
                DontDestroyOnLoad(gameObject);
                //
                initSettings.Initialise(this);
            }
        }

        public void Start()
        {
            Initialise(true);
        }

        public void Initialise(bool loadingScene)
        {
            // 使用Game Loading Module
            if (!IsStartInitialized)
            {
                IsStartInitialized = true;

                if (loadingScene)
                {
                    GameLoading.LoadGameScene();
                }
                else
                {
                    GameLoading.SimpleLoad();
                }
            }
        }
        
        public static bool IsModuleInitialised(Type moduleType)
        {
            ProjectInitSettings projectInitSettings = InitSettings;

            InitModule[] coreModules = null;
            InitModule[] initModules = null;

#if UNITY_EDITOR
            if (!IsInititalized)
            {
                projectInitSettings = RuntimeEditorUtils.GetAssetByName<ProjectInitSettings>();
            }
#endif

            if (projectInitSettings != null)
            {
                coreModules = projectInitSettings.CoreModules;
                initModules = projectInitSettings.Modules;
            }

            for (int i = 0; i < coreModules.Length; i++)
            {
                if (coreModules[i].GetType() == moduleType)
                {
                    return true;
                }
            }

            for (int i = 0; i < initModules.Length; i++)
            {
                if (initModules[i].GetType() == moduleType)
                {
                    return true;
                }
            }

            return false;
        }

        private void OnDestroy()
        {
            IsInititalized = false;
#if UNITY_EDITOR
            SaveController.Save(true);
#endif
        }

        private void OnApplicationFocus(bool focus)
        {
#if !UNITY_EDITOR
            if(!focus) 
            {
                SaveController.Save();
            }
#endif
        }
    }
}
