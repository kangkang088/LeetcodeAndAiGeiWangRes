using System.Collections;
using System.Collections.Generic;
using PandaXGame;
using TMPro;
using UnityEngine;
using UnityEngine.UI;

public class PowerUIPanelSimple : MonoBehaviour
{
    public TextMeshProUGUI PowerText;

    public TextMeshProUGUI TimeText;

    public TextMeshProUGUI FullText;






    void Update()
    {
        PowerText.text = PowerManager.Instance.NowHP.ToString();
        if (string.IsNullOrEmpty(PowerManager.Instance.StrTimeDValue))
        {
            TimeText.gameObject.SetActive(false);
            FullText.gameObject.SetActive(true);
        }
        else
        {
            TimeText.gameObject.SetActive(true);
            FullText.gameObject.SetActive(false);
            TimeText.text = PowerManager.Instance.StrTimeDValue;
        }
    }
}
