using UnityEngine;
using UnityEditor;

namespace PandaXGame
{
    public static class CurrencyActionsMenu
    {
        [MenuItem("Actions/Lots of Money", priority = 21)]
        private static void LotsOfMoney()
        {
            CurrenciesController.Set(CurrencyType.Coin, 2000000);
        }

        [MenuItem("Actions/Lots of Money", true)]
        private static bool LotsOfMoneyValidation()
        {
            return Application.isPlaying;
        }

        [MenuItem("Actions/No Money", priority = 22)]
        private static void NoMoney()
        {
            CurrenciesController.Set(CurrencyType.Coin, 0);
        }

        [MenuItem("Actions/No Money", true)]
        private static bool NoMoneyValidation()
        {
            return Application.isPlaying;
        }
    }
}