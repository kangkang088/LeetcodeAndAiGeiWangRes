﻿namespace PandaXGame
{
    // DO NOT CHANGE ORDER OF THE CURRENCIES AFTER RELEASE. IT CAN BRAKE THE SAVES OF THE GAME!
    public enum CurrencyType
    {
        Coin = 0,
    }
}