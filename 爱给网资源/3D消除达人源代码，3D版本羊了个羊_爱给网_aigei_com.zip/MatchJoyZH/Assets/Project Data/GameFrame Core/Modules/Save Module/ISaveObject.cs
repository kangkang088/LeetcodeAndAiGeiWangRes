﻿namespace PandaXGame
{
    public interface ISaveObject
    {
        public void Flush();
    }
}