using System.Collections;
using System.Collections.Generic;
using UnityEngine;

[System.Serializable]
public enum SavePresetType 
{
    Custom = 0,
    AutoSave = 1,
    Mission = 2
}
