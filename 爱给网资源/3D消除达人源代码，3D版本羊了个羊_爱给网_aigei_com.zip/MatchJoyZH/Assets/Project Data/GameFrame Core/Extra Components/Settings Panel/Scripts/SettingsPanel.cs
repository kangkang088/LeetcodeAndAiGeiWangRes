﻿#pragma warning disable 0414, 0649

using UnityEngine;

namespace PandaXGame
{
    public class SettingsPanel : MonoBehaviour
    {
        private static SettingsPanel instance;

        [DrawReference]
        [SerializeField] SettingsAnimation settingsAnimation;

        [Space]
        [SerializeField] UIScaleAnimation mainRect;

        [Header("Panel Paddings")]
        [SerializeField] float xPanelPosition;
        [SerializeField] float yPanelPosition;

        [Header("Element Paddings")]
        [SerializeField] float elementSpace;

        [SerializeField] SettingsButtonInfo[] settingsButtonsInfo;
        public SettingsButtonInfo[] SettingsButtonsInfo
        {
            get { return settingsButtonsInfo; }
        }

        private bool isActiveSettingsButton = false;
        public bool IsActiveSettingsButton => isActiveSettingsButton;

        private static bool IsPanelActive { get; set; }
        private static UIScaleAnimation MainRect => instance.mainRect;

        private bool isAnimationActive = false;

        private Vector2[] buttonPositions;
        public Vector2[] ButtonPositions
        {
            get { return buttonPositions; }
        }

        private void Awake()
        {
            instance = this;

            // Disable all buttons
            for (int i = 0; i < settingsButtonsInfo.Length; i++)
            {
                settingsButtonsInfo[i].SettingsButton.gameObject.SetActive(true);
            }
            InitPositions();

        }


        public void InitPositions()
        {
            Vector2 lastPosition = new Vector2(xPanelPosition, yPanelPosition);

            buttonPositions = new Vector2[settingsButtonsInfo.Length];
            for (int i = 0; i < buttonPositions.Length; i++)
            {
                if (settingsButtonsInfo[i].SettingsButton != null)
                {
                    settingsButtonsInfo[i].SettingsButton.Init(i, this);
                }
                else
                {
                    Debug.Log("[Settings Panel]: Button reference is missing!");
                }
            }
        }

        public void SettingsButton()
        {
            Show();
            AudioController.PlaySound(AudioController.Sounds.buttonSound);
        }

        public void Show()
        {
            gameObject.SetActive(true);
        }

        public void Hide()
        {
            gameObject.SetActive(false);
        }

       

        public static void HidePanel(bool immediately = false)
        {
            if (!IsPanelActive)
                return;

            IsPanelActive = false;
            if (instance != null)
            {
                instance.Hide();
            }
        }

      

        [System.Serializable]
        public class SettingsButtonInfo
        {
            public SettingsButtonBase SettingsButton { get => settingsButton; set => settingsButton = value; }
            [SerializeField] SettingsButtonBase settingsButton;
        }
    }
}

// -----------------
// Settings Panel v 0.3.1
// -----------------

// Changelog
// v 0.3.1
// • Added animations
// v 0.3
// • Added button sounds
// v 0.2.1
// • Removed GDPR controller refference from GDPR button
// • Added extra check for IAP button (don't show it if the product already purchased)
// v 0.2
// • Fast toggle fix
// v 0.1
// • Added basic version
// • Added example prefab