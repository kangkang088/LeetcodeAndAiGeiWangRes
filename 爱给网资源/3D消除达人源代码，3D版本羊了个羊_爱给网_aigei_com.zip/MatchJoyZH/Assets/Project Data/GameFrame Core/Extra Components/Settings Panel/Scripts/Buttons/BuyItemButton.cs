﻿using UnityEngine;

namespace PandaXGame
{
    public class BuyItemButton : MonoBehaviour
    {
       
    }
}

// -----------------
// Settings Panel v 0.3
// -----------------