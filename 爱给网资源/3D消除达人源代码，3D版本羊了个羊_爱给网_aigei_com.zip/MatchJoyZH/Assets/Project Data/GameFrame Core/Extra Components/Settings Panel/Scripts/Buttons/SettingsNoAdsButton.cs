﻿using UnityEngine;

namespace PandaXGame
{
    public class SettingsNoAdsButton : MonoBehaviour
    {
//         private void Awake()
//         {
//             gameObject.SetActive(IsActive());
//             IAPManager.OnPurchaseComplete += OnPurchaseComplete;
//         }
//
//         private void OnPurchaseComplete(ProductKeyType productKeyType)
//         {
//             if(productKeyType == ProductKeyType.NoAds)
//             {
//                gameObject.SetActive(false);
//             }
//         }
//
//         public bool IsActive()
//         {
// #if MODULE_IAP
//             return AdsManager.IsForcedAdEnabled();
// #else
//             return false;
// #endif
//         }
//
//         
//
//         public void OnClick()
//         {
//             IAPManager.BuyProduct(AdsManager.NO_ADS_PRODUCT_KEY);
//             // Play button sound
//             AudioController.PlaySound(AudioController.Sounds.buttonSound);
//         }
    }
}

// -----------------
// Settings Panel v 0.3
// -----------------