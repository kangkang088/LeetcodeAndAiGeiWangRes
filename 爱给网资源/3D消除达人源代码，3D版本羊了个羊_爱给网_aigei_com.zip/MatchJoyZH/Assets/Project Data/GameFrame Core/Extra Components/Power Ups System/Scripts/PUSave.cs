﻿namespace PandaXGame
{
    public class PUSave : ISaveObject
    {
        public int Amount = -1;

        public void Flush()
        {

        }
    }
}
