﻿namespace PandaXGame
{
    public enum PUType
    {
        Type_01 = 0,
        Type_02 = 1,
        Type_03 = 2,
    }
}
