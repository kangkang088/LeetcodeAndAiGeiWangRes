
namespace PandaXGame
{
    public enum VibrationIntensity
    {
        Light = 0,
        Medium = 1,
        Hard = 2,
    }
}