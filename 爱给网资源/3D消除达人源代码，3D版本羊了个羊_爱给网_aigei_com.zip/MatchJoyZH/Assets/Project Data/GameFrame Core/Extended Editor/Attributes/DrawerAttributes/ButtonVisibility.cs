﻿namespace PandaXGame
{
    public enum ButtonVisibility
    {
        ShowIf = 0,
        HideIf = 1
    }
}
