﻿using System;
using UnityEngine;

namespace PandaXGame
{
    [AttributeUsage(AttributeTargets.Field, AllowMultiple = false)]
    public sealed class DrawReferenceAttribute : PropertyAttribute
    {

    }
}