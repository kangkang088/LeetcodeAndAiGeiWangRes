﻿using System;

namespace PandaXGame
{
    public class ExtendedEditorAttribute : Attribute
    {
    }
}
