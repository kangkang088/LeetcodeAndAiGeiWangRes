using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using PandaXGame;

namespace PandaXGame
{
    [AttributeUsage(AttributeTargets.Field, AllowMultiple = false)]
    public class ToggleAttribute : DrawerAttribute
    {
        
    }
}
