﻿using System;

namespace PandaXGame
{
    public abstract class DrawerAttribute : ExtendedEditorAttribute
    {
    }
}