﻿using System;

namespace PandaXGame
{
    public class DrawConditionAttribute : ExtendedEditorAttribute
    {

    }
}
