﻿namespace PandaXGame
{
    public interface ISceneSavingCallback
    {
        public void OnSceneSaving();
    }
}