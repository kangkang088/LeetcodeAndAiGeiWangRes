using UnityEngine;
using UnityEditor;
using UnityEditor.SceneManagement;

public class ScreenshotTool : EditorWindow
{
    private string path = "Screenshots/"; // 默认保存路径
    private string fileName = "screenshot.png"; // 默认文件名

    [MenuItem("Tools/Screenshot Tool")]
    private static void Init()
    {
        // 创建窗口
        ScreenshotTool window = (ScreenshotTool)EditorWindow.GetWindow(typeof(ScreenshotTool));
        window.titleContent = new GUIContent("Screenshot Tool");
        window.Show();
    }

    private void OnGUI()
    {
        GUILayout.Label("Screenshot Settings", EditorStyles.boldLabel);
        path = EditorGUILayout.TextField("Save Path", path);
        if (GUILayout.Button("Take Screenshot"))
        {
            TakeScreenshot();
        }
    }

    private void TakeScreenshot()
    {
        // 创建保存路径的文件夹
        if (!System.IO.Directory.Exists(path))
        {
            System.IO.Directory.CreateDirectory(path);
        }

        System.Type T = System.Type.GetType("UnityEditor.GameView,UnityEditor");
        System.Reflection.MethodInfo GetSizeOfMainGameView = T.GetMethod("GetSizeOfMainGameView", System.Reflection.BindingFlags.NonPublic | System.Reflection.BindingFlags.Static);
        object Res = GetSizeOfMainGameView.Invoke(null, null);
        Vector2 resolution = (Vector2)Res;
    
        fileName = resolution.x+"x"+resolution.y+".png";
        // 组合完整的文件路径
        string filePath = System.IO.Path.Combine(path, fileName);

        // 调用截图 API
        ScreenCapture.CaptureScreenshot(filePath); // '1' 代表不进行截图缩放

        Debug.Log("Screenshot saved to: " + filePath);

        // 刷新编辑器项目窗口，以显示新文件
        AssetDatabase.Refresh();
    }
}
