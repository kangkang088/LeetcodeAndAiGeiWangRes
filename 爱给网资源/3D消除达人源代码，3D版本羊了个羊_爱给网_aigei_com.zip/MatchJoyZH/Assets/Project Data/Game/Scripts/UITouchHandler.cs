﻿#pragma warning disable 0414

using UnityEngine;
using UnityEngine.EventSystems;

namespace PandaXGame
{
    public class UITouchHandler : MonoBehaviour, IPointerDownHandler, IPointerUpHandler, IPointerMoveHandler
    {
        private bool _selected = false;
        private MatchableObjectBehavior _curMatchable;

        public void OnPointerDown(PointerEventData eventData)
        {
            _selected = true;
            OnPointerMove(eventData);
        }

        /// <summary>
        /// 失去焦点和获得焦点进行容错处理
        /// </summary>
        /// <param name="hasFocus"></param>
        public void OnApplicationFocus(bool hasFocus)
        {
            _selected = false;
            _curMatchable?.RemoveSelect();
            _curMatchable = null;
        }

        public void OnPointerMove(PointerEventData eventData)
        {
            if (!_selected)
            {
                return;
            }
            if (Physics.Raycast(CameraBehavior.MainCamera.ScreenPointToRay(eventData.position), out RaycastHit hit, 2000, 256))
            {
                MatchableObjectBehavior matchable = hit.transform.GetComponent<MatchableObjectBehavior>();
                if (matchable == null)
                {
                    _curMatchable?.RemoveSelect();
                    _curMatchable = null;
                    return;
                }
                _curMatchable?.RemoveSelect();
                _curMatchable = matchable;
                _curMatchable.SetSelect();
            }
            else
            {
                _curMatchable?.RemoveSelect();
                _curMatchable = null;
            }
        }

        public void OnPointerUp(PointerEventData eventData)
        {
            _selected = false;
            if (_curMatchable == null)
            {
                return;
            }
            _curMatchable.RemoveSelect();
            _curMatchable._rigidbody.isKinematic = true;
            if (!_curMatchable.IsPicked)
            {
                if (_curMatchable.IsActive && !SlotsController.Filled)
                {
                    LevelController.RemoveMatchable(_curMatchable);
                    AudioController.PlaySound(AudioController.Sounds.itemClick);
                    if (AudioController.IsVibrationEnabled())
                    {
                        Vibration.Vibrate(VibrationIntensity.Light);
                    }
                    _curMatchable.transform.localScale = Vector3.one*1.1f;
                }
                else
                {
                    _curMatchable.Shake();
                }
            }

            _curMatchable = null;
        }


    }
}