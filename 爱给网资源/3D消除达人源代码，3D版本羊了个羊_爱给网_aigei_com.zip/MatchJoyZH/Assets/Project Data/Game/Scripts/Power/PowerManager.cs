using System;
using UnityEngine;

namespace PandaXGame
{
    /// <summary>
    ///  体力管理系统
    /// </summary> 
    public class PowerManager : MonoBehaviour
    {
        /// <summary>
        ///  最大体力
        /// </summary> 
        private const int MAX_POWER = 5;
        /// <summary>
        /// 多长时间恢复一点体力  分钟
        /// </summary>
        private const int CDTime = 30;

        private static PowerManager instance;

        /// <summary>
        /// 当前体力
        /// </summary>
        private int nowHP;

        /// <summary>
        /// DateTime-HP恢复时间
        /// </summary>
        private DateTime DateTimeHPRecoveTime;

        /// <summary>
        /// 字符串-HP恢复时间
        /// </summary>
        private string StrHPRecoveTime;

        /// <summary>
        /// 辅助计算使用
        /// </summary>
        private string strTimeDValue;

        private float checkTime;

        public static PowerManager Instance
        {
            get
            {
                if (instance == null)
                {
                    instance = FindObjectOfType<PowerManager>();
                }
                return instance;
            }
        }

        /// <summary>
        /// 倒计时字符串
        /// </summary>
        /// <value></value>
        public string StrTimeDValue
        {
            get
            {
                return strTimeDValue;
            }
        }

        /// <summary>
        /// 玩家当前HP   NowHP=N：增加或减少N点HP
        /// </summary>
        public int NowHP
        {
            get
            {
                return nowHP;
            }
        }

        void Awake()
        {
            if (instance == null)
            {
                instance = this;
            }
            else
            {
                Destroy(gameObject);
            }
            LoadData();

        }



        /// <summary>
        /// 增加或减少体力
        /// </summary>
        /// <param name="hpvl"> 正数增加 ， 负数减少</param>
        public void AddRemoveHP(int hpvl)
        {
            nowHP = nowHP + hpvl;
            PlayerPrefs.SetInt("NowHP", nowHP);
            if (nowHP < MAX_POWER)
            {
                if (string.IsNullOrEmpty(StrHPRecoveTime))
                {
                    DateTimeHPRecoveTime = DateTime.Now;
                    StrHPRecoveTime = DateTimeHPRecoveTime.ToString();
                }
            }
            else
            {
                DateTimeHPRecoveTime = new DateTime();
                StrHPRecoveTime = "";
            }
            PlayerPrefs.SetString("HPRecoveTime", StrHPRecoveTime);
        }

        /// <summary>
        /// 加载数据
        /// </summary>
        private void LoadData()
        {
            nowHP = PlayerPrefs.GetInt("NowHP", MAX_POWER);
            StrHPRecoveTime = PlayerPrefs.GetString("HPRecoveTime", "");
            if (nowHP >= MAX_POWER)
            {
                StrHPRecoveTime = "";
            }

            if (!string.IsNullOrEmpty(StrHPRecoveTime))
            {
                DateTimeHPRecoveTime = DateTime.Parse(StrHPRecoveTime);
            }
        }

        /// <summary>
        /// 更新CD时间
        /// </summary> 
        void Update()
        {

            if (Input.GetKeyDown(KeyCode.F8))
            {
                PowerManager.Instance.AddRemoveHP(-1);
            }

            if (Input.GetKeyDown(KeyCode.F7))
            {
                PowerManager.Instance.AddRemoveHP(1);
            }

            if (Input.GetKeyDown(KeyCode.F6))
            {
                UIController.HidePage<UIMainMenu>();
                UIController.ShowPage<LevelSelectionBehavior>();
            }

            if (string.IsNullOrEmpty(StrHPRecoveTime))
            {
                strTimeDValue = "";
            }
            else
            {
                //每秒检测时间差
                checkTime += Time.deltaTime;
                if (checkTime >= 1)
                {
                    checkTime = 0;
                    GetMinDValue(DateTimeHPRecoveTime, DateTime.Now);
                }
            }
        }

        /// <summary>
        /// 计算两个时间的差值（秒）
        /// </summary>
        /// <param name="oldTime"></param>
        /// <param name="newTime"></param>
        /// <returns></returns>
        public void GetMinDValue(DateTime oldTime, DateTime newTime)
        {
            if (oldTime.Year == 1)
            {
                return;
            }
            int second = 0;
            TimeSpan ts1 = new TimeSpan(oldTime.Ticks);
            TimeSpan ts2 = new TimeSpan(newTime.Ticks);
            TimeSpan ts = ts1.Subtract(ts2).Duration();
            second = (int)ts.TotalSeconds;
            if (second <= 0)
            {
                strTimeDValue = "";
            }
            else
            {
                if (second >= 60 * CDTime)
                {
                    //差值满足回复一点体力
                    //增加体力
                    AddRemoveHP(1);
                    //扣除时间
                    if (NowHP >= MAX_POWER)
                    {
                        //已满
                        strTimeDValue = "";
                    }
                    else
                    {
                        //未满
                        DateTimeHPRecoveTime = DateTimeHPRecoveTime.AddSeconds(60 * CDTime);
                        StrHPRecoveTime = DateTimeHPRecoveTime.ToString();
                        PlayerPrefs.SetString("HPRecoveTime", StrHPRecoveTime);
                        GetMinDValue(DateTimeHPRecoveTime, DateTime.Now);
                    }
                    return;
                }
                second = 60 * CDTime - second;
                int min = second / 60;
                string str_min = min >= 10 ? min.ToString() : (min == 0 ? "00" : ("0" + min));
                int sec = second % 60;
                string str_sec = sec >= 10 ? sec.ToString() : (sec == 0 ? "00" : ("0" + sec));
                strTimeDValue = string.Format("{0}:{1}", str_min, str_sec);
            }
        }

    }
}