using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using PandaXGame;

namespace PandaXGame.MatchJoy
{
    [System.Serializable]
    public class GameSave : ISaveObject
    {
        public int CurrentLevelId;
        public int MaxLevelReachedId;

        public GameSave()
        {
            CurrentLevelId = 0;
            MaxLevelReachedId = 0;
        }

        public void Flush()
        {
        }
    }
}