﻿#pragma warning disable 0649
using System;
using UnityEngine;
using WindMill.Advertisements;

namespace PandaXGame
{
    public class AdsManager : MonoBehaviour
    {
#if UNITY_ANDROID
        private static string sigAppId = "50045";
#elif UNITY_IOS
        private static string sigAppId = "49964";
#else
        private static string sigAppId = "";
#endif

        // 异常重新尝试时间
        private const float ErrorReplayCDTimes = 5;
        public static AdsManager Instance;

        // RV广告
        private static RewardVideoAd rewardVideoAd;
        // 插屏广告
        private static IntersititialAd intersititialAd;
        // Banner广告
        public static BannerAd bannerAd;

        //插屏广告是否已经加载
        private float interstitialAdreloadCd = 0;
        //插屏广告是否已经加载
        public float bannerAdreloadCd = 0;

        private bool bannerIsShow = false;
        //RV广告CD
        private float rewardedAdReloadCd = 0;
        private Action successCallbackAct;
        private int cdtimes = 1;


        private void Awake()
        {
            Instance = this;

            interstitialAdreloadCd = 5;
            rewardedAdReloadCd     = 5;
            bannerAdreloadCd       = 5;
        }

        void Start()
        {
            Advertisement.SetDebugEnable(false);
            //初始化
            Advertisement.init(sigAppId);
            this.CreateAndLoadRewardedAd();
            this.RequestInterstitial();
            this.BannerCreateAndLoad();
        }

        public void Update()
        {
            if (interstitialAdreloadCd > 0)
            {
                interstitialAdreloadCd -= Time.deltaTime;
                if (interstitialAdreloadCd <= 0)
                {
                    this.RequestInterstitial();
                }
            }

            if (rewardedAdReloadCd > 0)
            {
                rewardedAdReloadCd -= Time.deltaTime;
                if (rewardedAdReloadCd <= 0)
                {
                    // 重新尝试加载
                    this.CreateAndLoadRewardedAd();
                }
            }

            if (bannerAdreloadCd > 0)
            {
                bannerAdreloadCd -= Time.deltaTime;
                if (bannerAdreloadCd <= 0)
                {
                    // 重新尝试加载
                    this.BannerCreateAndLoad();
                }
            }

        }

        /// <summary>
        /// 加载插屏广告
        /// </summary>
        private void RequestInterstitial()
        {
            if (intersititialAd == null)
            {
                Request requestIN = new Request();
#if UNITY_ANDROID
                requestIN.PlacementId = "8432473296737400";
#else
                requestIN.PlacementId = "5879743292124860";
#endif
                intersititialAd = new IntersititialAd(requestIN);
                intersititialAd.SetIntersititialAdListener(new IntersititialAdListener());
            }
            intersititialAd.LoadAd();
        }

        public void BannerCreateAndLoad()
        {
            if (bannerAd == null)
            {
                Request bannerAdrequest = new Request();
#if UNITY_ANDROID
                bannerAdrequest.PlacementId = "8397194488451785";
#else
                bannerAdrequest.PlacementId = "8639122697161240";
#endif
                bannerAd = new BannerAd(bannerAdrequest);
                bannerAd.SetBannerAdListener(new BannerAdListener());
            }
            bannerAd.LoadAd();
        }

        public void ShowBanner()
        {
            if (bannerAd != null && bannerAd.Ready())
            {
                float ratio = 320 / 50.0f; ;
                int width = Screen.width - 20;
                int height = (int)(width / ratio);
                int x = Screen.width > width ? (Screen.width - width) / 2 : 0;
                int y = Screen.height - height - 50;
                bannerAd.ShowAd(new Rect(x, y, width, height));

                bannerIsShow = true;
            }
        }

        public void HideBanner()
        {
            if (bannerAd != null && bannerIsShow)
            {
                bannerAd.HideAd();
                bannerIsShow = false;
            }

            BannerCreateAndLoad();
        }

        /// <summary>
        /// 显示插屏广告
        /// </summary>
        public void ShowInterstitial()
        {
            if (intersititialAd.Ready())
            {
                intersititialAd.ShowAd();
            }
            else
            {
                cdtimes -= 1;
                RequestInterstitial();
            }
        }


        /// <summary>
        /// 创建并加载视频广告
        /// </summary>
        public void CreateAndLoadRewardedAd()
        {
            if (rewardVideoAd == null)
            {
                Request request = new Request();
#if UNITY_ANDROID
                request.PlacementId = "8656522463252993";
#else
                request.PlacementId = "2118715589626474";
#endif
                rewardVideoAd = new RewardVideoAd(request);
                rewardVideoAd.SetRewardAdListener(new RewardVideoAdListener());
            }
            rewardVideoAd.LoadAd();
        }


        /// <summary>
        /// 显示视频广告
        /// </summary>
        /// <param name="callback"></param>
        public void ShowRewardedAd(Action callback)
        {
            this.successCallbackAct = callback;
            if (rewardVideoAd.Ready())
            {
                rewardVideoAd.ShowAd();
            }
            else
            {
                CreateAndLoadRewardedAd();
                FloatingMessage.ShowMessage("广告加载中...");
            }
#if UNITY_EDITOR
            if (callback != null)
            {
                callback();
            }
#endif
        }

        #region "Intersititial Listener"
        private sealed class BannerAdListener : IBannerAdListener
        {
            public BannerAdListener()
            {

            }
            public void OnAdClick(BannerAd ad)
            {
                Debug.Log("SigmobUnityPlugin -- OnAdClick  ---- " + ad.PlacementId);
            }

            public void OnAdClose(BannerAd ad)
            {
                Debug.Log("SigmobUnityPlugin -- OnAdClose  ---- " + ad.PlacementId);
                ad.Dispose();
                AdsManager.bannerAd = null;
                AdsManager.Instance.BannerCreateAndLoad();
            }

            public void OnAdShow(BannerAd ad)
            {
                Debug.Log("SigmobUnityPlugin -- OnAdShow  ---- " + ad.PlacementId);
                Debug.Log("SigmobUnityPlugin -- getAdInfo  ---- " + ad.GetAdInfo().ToString());
            }

            public void OnAdError(BannerAd ad, Error error)
            {
                Debug.Log("SigmobUnityPlugin -- OnAdError  ---- " + ad.PlacementId + ", error -- " + error.ToString());

                AdsManager.Instance.bannerAdreloadCd = 5;
            }

            public void OnAdLoad(BannerAd ad)
            {
                Debug.Log("SigmobUnityPlugin -- OnAdLoad  ---- " + ad.PlacementId);
            }

            public void OnAdAutoRefreshed(BannerAd ad)
            {
                Debug.Log("SigmobUnityPlugin -- OnAdAutoRefreshed  ---- " + ad.PlacementId);
            }

            public void OnAdAutoRefreshFail(BannerAd ad, Error error)
            {
                Debug.Log("SigmobUnityPlugin -- OnAdAutoRefreshFail  ---- " + ad.PlacementId);
            }
        }
        #endregion


        #region "激励视频Listener"
        private sealed class RewardVideoAdListener : IRewardVideoAdListener
        {
            public void OnAdClick(RewardVideoAd ad)
            {
                Debug.Log("SigmobUnityPlugin -- OnAdClick  ---- " + ad.PlacementId);
            }

            public void OnAdReward(RewardVideoAd ad, RewardInfo info)
            {
                if (Instance.successCallbackAct != null)
                {
                    Instance.successCallbackAct();
                }
                Debug.Log("SigmobUnityPlugin -- OnAdReward  ---- " + ad.PlacementId + " IsReward ----- " + info.IsReward + " TransId ----- " + info.TransId + " UserId ----- " + info.UserId);
            }

            public void OnAdClose(RewardVideoAd ad)
            {
                Debug.Log("SigmobUnityPlugin -- OnAdClose  ---- " + ad.PlacementId);
                Instance.CreateAndLoadRewardedAd();
            }

            public void OnAdShow(RewardVideoAd ad)
            {
                Debug.Log("SigmobUnityPlugin -- OnAdShow  ---- " + ad.PlacementId);
                AdInfo adInfo = ad.GetAdInfo();
                Debug.Log("SigmobUnityPlugin -- getAdInfo  ---- " + adInfo.ToString() + " | loadId " + adInfo.loadId);
            }


            public void OnAdError(RewardVideoAd ad, Error error)
            {
                Debug.Log("SigmobUnityPlugin -- OnAdError  ---- " + ad.PlacementId + ", error -- " + error.ToString());
                Instance.rewardedAdReloadCd = ErrorReplayCDTimes;
            }

            public void OnAdLoad(RewardVideoAd ad)
            {
                Debug.Log("SigmobUnityPlugin -- OnAdLoad  ---- " + ad.PlacementId);
            }

            public void OnSkippedVideo(RewardVideoAd ad)
            {
                Debug.Log("SigmobUnityPlugin -- OnSkippedVideo  ---- " + ad.PlacementId);
            }

            public void OnVideoEnd(RewardVideoAd ad)
            {
                Debug.Log("SigmobUnityPlugin -- OnVideoEnd  ---- " + ad.PlacementId);
            }

            public void OnVideoError(RewardVideoAd ad, Error error)
            {
                Debug.Log("SigmobUnityPlugin -- OnVideoError  ---- " + ad.PlacementId + ", error -- " + error.ToString());
                Instance.rewardedAdReloadCd = ErrorReplayCDTimes;
            }
        }

        #endregion
        #region "插屏视频Listener"
        private sealed class IntersititialAdListener : IIntersititialAdListener
        {
            public void OnAdClick(IntersititialAd ad)
            {
                Debug.Log("SigmobUnityPlugin -- OnAdClick  ---- " + ad.PlacementId);
            }

            public void OnAdClose(IntersititialAd ad)
            {
                Debug.Log("SigmobUnityPlugin -- OnAdClose  ---- " + ad.PlacementId);
                Instance.RequestInterstitial();
            }

            public void OnAdShow(IntersititialAd ad)
            {
                Debug.Log("SigmobUnityPlugin -- OnAdShow  ---- " + ad.PlacementId);

                Debug.Log("SigmobUnityPlugin -- getAdInfo  ---- " + ad.GetAdInfo().ToString());

            }

            public void OnAdError(IntersititialAd ad, Error error)
            {
                Debug.Log("SigmobUnityPlugin -- OnAdError  ---- " + ad.PlacementId + ", error -- " + error.ToString());
                Instance.interstitialAdreloadCd = ErrorReplayCDTimes;
            }

            public void OnAdLoad(IntersititialAd ad)
            {
                Debug.Log("SigmobUnityPlugin -- OnAdLoad  ---- " + ad.PlacementId);
            }

            public void OnSkippedVideo(IntersititialAd ad)
            {
                Debug.Log("SigmobUnityPlugin -- OnSkippedVideo  ---- " + ad.PlacementId);
            }

            public void OnVideoEnd(IntersititialAd ad)
            {
                Debug.Log("SigmobUnityPlugin -- OnVideoEnd  ---- " + ad.PlacementId);
            }

            public void OnVideoError(IntersititialAd ad, Error error)
            {
                Debug.Log("SigmobUnityPlugin -- OnVideoError  ---- " + ad.PlacementId + ", error -- " + error.ToString());
                Instance.interstitialAdreloadCd = ErrorReplayCDTimes;
            }

            public void OnAdCloseOtherVC(IntersititialAd ad)
            {
                throw new NotImplementedException();
            }
        }
        #endregion

    }
}