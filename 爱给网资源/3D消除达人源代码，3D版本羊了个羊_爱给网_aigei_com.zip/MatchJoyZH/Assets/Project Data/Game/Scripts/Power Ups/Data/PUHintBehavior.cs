﻿using System.Collections.Generic;
using UnityEngine;

namespace PandaXGame
{
    public class PUHintBehavior : PUBehavior
    {
        public float cdtimes = 1;
        private PUHintSettings customSettings;

        private TweenCase disableTweenCase;

        public override void Initialise()
        {
            customSettings = (PUHintSettings)settings;
        }

        void Update()
        {
            if(cdtimes > 0)
            {
                cdtimes -= Time.deltaTime;
            }
            
        }

        public override bool Activate()
        {
            if (cdtimes > 0)
            {
                return false;
            }
            cdtimes = 1;
            int slotsAvailable = SlotsController.GetSlotsAvailable();
            List<MatchableObjectBehavior> matchableObjects = LevelController.MatchableObjects;
            UIGame.RaycasterEnabled = false;

            if (slotsAvailable > 2)
            {
                // Can remove any three objects
                LevelController.RemoveRandomThree();

                UIGame.RaycasterEnabled = true;

                return true;
            }
            else if (slotsAvailable == 2)
            {
                IsBusy = true;

                // Can remove only objects with one in slots
                MatchableObject matchable = SlotsController.GetRandomMatchableInSlots();

                int sameInSlots = SlotsController.AmountInSlots(matchable);

                List<MatchableObjectBehavior> sameMatchables = matchableObjects.FindAll(x => x.MatchableObject == matchable);

                if (sameInSlots == 2)
                {
                    sameMatchables[0].SetActive(true);

                    LevelController.RemoveMatchable(sameMatchables[0]);
                }
                else
                {
                    sameMatchables[0].SetActive(true);
                    sameMatchables[1].SetActive(true);

                    LevelController.RemoveMatchables(sameMatchables[0], sameMatchables[1]);
                }

                SlotsController.DisableRevert();

                IsBusy = false;
                UIGame.RaycasterEnabled = true;

                return true;
            }
            else
            {
                IsBusy = true;

                // Can remove only with two in slots
                MatchableObject matchable = SlotsController.GetMatchableOfTwo();

                if (matchable == null)
                {
                    disableTweenCase = Tween.DelayedCall(0.4f, () =>
                    {
                        IsBusy = false;

                        UIGame.RaycasterEnabled = true;
                    });

                    return false;
                }

                MatchableObjectBehavior matchableObject = matchableObjects.Find((MatchableObjectBehavior matchableBehavior) => { return matchableBehavior.MatchableObject == matchable; });

                matchableObject.SetActive(true);

                LevelController.RemoveMatchable(matchableObject);

                SlotsController.DisableRevert();

                UIGame.RaycasterEnabled = true;

                return true;
            }
        }

        public override void ResetBehavior()
        {
            disableTweenCase.KillActive();

            IsBusy = false;
        }
    }
}
