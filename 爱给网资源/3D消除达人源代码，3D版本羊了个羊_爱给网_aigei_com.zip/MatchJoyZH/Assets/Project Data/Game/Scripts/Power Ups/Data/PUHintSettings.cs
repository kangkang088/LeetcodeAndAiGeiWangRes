﻿using UnityEngine;

namespace PandaXGame
{
    [CreateAssetMenu(fileName = "PU Hint Settings", menuName = "Content/Power Ups/PU Hint Settings")]
    public class PUHintSettings : PUCustomSettings
    {
        public override void Initialise()
        {

        }
    }
}
