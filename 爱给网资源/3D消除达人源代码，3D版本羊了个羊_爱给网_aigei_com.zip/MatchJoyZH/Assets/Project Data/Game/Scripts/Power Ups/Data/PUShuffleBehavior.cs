using UnityEngine;
using System.Collections.Generic;

namespace PandaXGame
{
    public class PUShuffleBehavior : PUBehavior
    {
        private PUShuffleSettings customSettings;

        private TweenCase delayTweenCase;

        public override void Initialise()
        {
            customSettings = (PUShuffleSettings)settings;
        }

        public override bool Activate()
        {
            List<MatchableObjectBehavior> matchableObjects = LevelController.MatchableObjects;
            if(matchableObjects != null)
            {
                if(matchableObjects.Count > 1)
                {
                    IsBusy = true;

                    UIGame.RaycasterEnabled = false;

                    SlotsController.DisableRevert();

                    matchableObjects.Shuffle();

                    float delay = 0.6f;

                    for (int i = 0; i < matchableObjects.Count / 2; i++)
                    {
                        int reverseI = matchableObjects.Count - 1 - i;

                        MatchableObjectBehavior first = matchableObjects[i];
                        MatchableObjectBehavior second = matchableObjects[reverseI];

                        first.transform.DOScale(0, 0.4f, 0.07f * i).SetEasing(Ease.Type.BackIn);
                        second.transform.DOScale(0, 0.4f, 0.07f * i).SetEasing(Ease.Type.BackIn).OnComplete(() =>
                        {
                            first.SwapPositions(second);

                            first.transform.DOScale(1, 0.4f).SetEasing(Ease.Type.BackOut);
                            second.transform.DOScale(1, 0.4f).SetEasing(Ease.Type.BackOut).OnComplete(() =>
                            {
                                first.SetActive(first.IsActive);
                                second.SetActive(second.IsActive);
                            });
                        });

                        delay += 0.07f;
                    }

                    Tween.DelayedCall(delay, () =>
                    {
                        IsBusy = false;

                        UIGame.RaycasterEnabled = true;
                    });

                    return true;
                }
            }

            return false;
        }

        public override void ResetBehavior()
        {
            IsBusy = false;

            delayTweenCase.KillActive();
        }
    }
}
