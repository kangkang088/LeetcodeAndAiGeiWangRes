using UnityEngine;

namespace PandaXGame
{
    public abstract class PUCustomSettings : PUSettings
    {
        [Group("Variables")]
        [SerializeField] string title;
        public string Title => title;
    }
}
