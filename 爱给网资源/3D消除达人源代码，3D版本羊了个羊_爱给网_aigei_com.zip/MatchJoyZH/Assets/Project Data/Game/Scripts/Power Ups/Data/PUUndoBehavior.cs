﻿using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

namespace PandaXGame
{
    public class PUUndoBehavior : PUBehavior
    {
        private PUUndoSettings customSettings;
        private TweenCase rotateTweenCase;

        public override void Initialise()
        {
            customSettings = (PUUndoSettings)settings;
        }

        public override bool Activate()
        {
            MatchableObjectBehavior lastPickedObject = SlotsController.LastPickedObject;

            if (lastPickedObject == null) return false;

            UIGame.RaycasterEnabled = false;
            IsBusy = true;

            // Returing last object to the level field
            LevelController.PlaceMatchable(lastPickedObject, true);
            LevelController.AddMatchableToRepresentation(lastPickedObject);
            LevelController.ResetActive();

            SlotsController.DisableRevert();

            lastPickedObject.OnReverted();
            lastPickedObject.transform.DOScale(1, 0.4f);

            List<MatchableObjectBehavior> objectsInSlots = SlotsController.ObjectsInSlots;
            List<Image> slots = SlotsController.Slots;

            objectsInSlots.Remove(lastPickedObject);

            lastPickedObject = null;

            // Shifting the rest of the objects
            Tween.DelayedCall(0.3f, () => 
            {
                for (int i = 0; i < objectsInSlots.Count; i++)
                {
                    MatchableObjectBehavior nextMatchable = objectsInSlots[i];
                    Image slot = slots[i];

                    if (nextMatchable.IsTransitioning)
                    {
                        nextMatchable.nextTransition = () => {
                            nextMatchable.transform.DOMove(slot.transform.position, 0.1f).SetEasing(Ease.Type.SineInOut);
                        };
                    }
                    else
                    {
                        nextMatchable.transform.DOMove(slot.transform.position, 0.1f).SetEasing(Ease.Type.SineInOut);
                    }
                }

                Tween.DelayedCall(0.1f, () => 
                {
                    UIGame.RaycasterEnabled = true;

                    IsBusy = false;
                });
            });

            return true;
        }

        public override void ResetBehavior()
        {
            IsBusy = false;

            rotateTweenCase.KillActive();
        }
    }
}
