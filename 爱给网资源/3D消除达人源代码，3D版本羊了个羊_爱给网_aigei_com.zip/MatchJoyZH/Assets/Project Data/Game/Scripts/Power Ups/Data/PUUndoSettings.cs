﻿using UnityEngine;

namespace PandaXGame
{
    [CreateAssetMenu(fileName = "PU Undo Settings", menuName = "Content/Power Ups/PU Undo Settings")]
    public class PUUndoSettings : PUCustomSettings
    {
        public override void Initialise()
        {

        }
    }
}
