﻿using UnityEngine;

namespace PandaXGame
{
    [CreateAssetMenu(fileName = "PU Shuffle Settings", menuName = "Content/Power Ups/PU Shuffle Settings")]
    public class PUShuffleSettings : PUCustomSettings
    {
        public override void Initialise()
        {

        }
    }
}
