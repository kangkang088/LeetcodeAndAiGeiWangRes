﻿#pragma warning disable 0649

using UnityEngine;
using PandaXGame.MatchJoy;

namespace PandaXGame
{
    /// <summary>
    /// 游戏控制器
    /// </summary>
    public class GameController : MonoBehaviour
    {
        private static GameController instance;

        [SerializeField][Header("观看广告奖励的金币")] int coinsForAdsAmount;
        public static int CoinsForAdsAmount => instance.coinsForAdsAmount;

        [Space(5)]
        [SerializeField][Range(0f, 1f)][Header("获取金币的概率")] float coinsForMatchChance;
        public static float CoinsForMatchChance => instance.coinsForMatchChance;

        [SerializeField][Header("完成单次消除给的钱")] int coinsForMatch;
        public static int CoinsForMatch => instance.coinsForMatch;

        [Space(3)]
        [SerializeField] UIController uiController;
        [SerializeField] CurrenciesController currenciesController;
        [SerializeField] LevelDatabase levelDatabase;
        [SerializeField] PUController powerUpsController;

        public static LevelDatabase LevelDatabase => instance.levelDatabase;

        public static GameSave Save { get; private set; }

        /// <summary>
        /// 当前关卡
        /// </summary>
        public static int CurrentLevelId
        {
            get => Save.CurrentLevelId;
            private set => Save.CurrentLevelId = value;
        }

        /// <summary>
        /// 当前达到的最大关卡
        /// </summary>
        public static int MaxLevelReachedId
        {
            get => Save.MaxLevelReachedId;
            private set => Save.MaxLevelReachedId = value;
        }

        /// <summary>
        /// 金币
        /// </summary>
        /// <value></value>
        public static int Coins
        {
            get => CurrenciesController.Get(CurrencyType.Coin);
            set
            {
                CurrenciesController.Set(CurrencyType.Coin, value);
            }
        }


        public static bool ShouldOpenDaily { get; set; }

        private void Awake()
        {
            instance = this;
            // 游戏保存
            Save = SaveController.GetSaveObject<GameSave>("game_save");
        }

        private void Start()
        {
            // UI控制器 初始化
            uiController.Initialise();

            // 货币控制器
            currenciesController.Initialise();
            powerUpsController.Initialise();

            // 关卡 对象池
            LevelController.CreatePools();

            ShouldOpenDaily = DailyRewardController.Init();

            // UI 页面
            uiController.InitialisePages();
            UIController.ShowPage<UIMainMenu>();

            // 关闭加载
            GameLoading.MarkAsReadyToHide();
        }

        /// <summary>
        /// 加载关卡
        /// </summary>
        /// <param name="levelId"></param>
        public static void LoadLevel(int levelId)
        {
            CurrentLevelId = levelId;
            LoadLevel(LevelDatabase.GetLevel(levelId));
        }

        /// <summary>
        /// 加载关卡
        /// </summary>
        /// <param name="level"></param>
        public static void LoadLevel(Level level)
        {
            // 永远显示最大关卡数
            UIGame.LevelNumber = MaxLevelReachedId;
            LevelController.LoadLevel(level);
        }

        /// <summary>
        /// 开始游戏
        /// </summary>
        public static void Play()
        {
            if (CurrentLevelId >= LevelDatabase.AmountOfLevels)
            {
                CurrentLevelId = Random.Range(LevelDatabase.AmountOfLevels - 50, LevelDatabase.AmountOfLevels - 1);
            }
            LoadLevel(CurrentLevelId);
            UIGame.LevelNumber = MaxLevelReachedId;
            UIController.ShowPage<UIGame>();
        }

        /// <summary>
        /// 结束游戏
        /// </summary> 
        public static void FinishLevel()
        {
            UIGame.RaycasterEnabled = false;
            NextLevel();
        }

        /// <summary>
        /// 关卡完成
        /// </summary>
        public static void LevelComplete()
        {
            MaxLevelReachedId = MaxLevelReachedId + 1;
            CurrentLevelId = CurrentLevelId + 1;
        }

        /// <summary>
        /// 下一关
        /// </summary> 
        public static void NextLevel()
        {
            CurrentLevelId++;
            if (CurrentLevelId >= LevelDatabase.AmountOfLevels)
            {
                CurrentLevelId = Random.Range(LevelDatabase.AmountOfLevels - 50, LevelDatabase.AmountOfLevels - 1);
            }
            // 加载安关卡
            LoadLevel(CurrentLevelId);
        }
    }
}