﻿#pragma warning disable 0649
using UnityEngine;
using UnityEngine.UI;
using TMPro;

namespace PandaXGame
{
    /// <summary>
    /// 主界面
    /// </summary>
    public class UIMainMenu : UIPage
    {
        public static UIMainMenu instance;

        [Header("Canvases")]
        [SerializeField] Canvas mainMenuCanvas;
        [SerializeField] CanvasGroup mainMenuCanvasGroup;

        [Header("Main Panel")]
        [SerializeField] SettingsPanel settings;
        [SerializeField] TMP_Text coinsAmount;
        [SerializeField] public CurrencyUIPanelSimple coinsPanel;

        [Header("Buttons")]
        [SerializeField] Button playButton;
        [SerializeField] Button dailyButton;
        [SerializeField] TMP_Text levelNumTxt;



        public static int CoinsAmount { set => instance.coinsAmount.text = value.ToString(); }

        private static CanvasGroup MainMenuCanvasGroup => instance.mainMenuCanvasGroup;


        private static SettingsPanel Settings => instance.settings;

        private void Awake()
        {
            instance = this;

            playButton.onClick.AddListener(PlayButton);
            dailyButton.onClick.AddListener(DailyRewardButton);
        }

        public override void Initialise()
        {
            coinsPanel.Initialise();
            levelNumTxt.text = (GameController.MaxLevelReachedId + 1).ToString();
        }

        public override void PlayShowAnimation()
        {
            levelNumTxt.text = (GameController.MaxLevelReachedId + 1).ToString();
            MainMenuCanvasGroup.alpha = 0;
            MainMenuCanvasGroup.DOFade(1, 0.4f).OnComplete(() =>
            {
                graphicRaycaster.enabled = true;
                UIController.OnPageOpened(this);
            });
            AdsManager.Instance.ShowBanner();
        }

        public override void PlayHideAnimation()
        {
            if (Settings.IsActiveSettingsButton)
            {
                SettingsPanel.HidePanel(true);
            }
            MainMenuCanvasGroup.alpha = 1;
            MainMenuCanvasGroup.DOFade(0, 0.5f).OnComplete(() =>
            {
                UIController.OnPageClosed(this);
            });
            AdsManager.Instance.HideBanner();
        }




        public void PlayButton()
        {
            if (PowerManager.Instance.NowHP > 0)
            {
                UIController.HidePage<UIMainMenu>();
                Tween.DelayedCall(0.7f, GameController.Play);
            }
            else
            {
                UIController.ShowPage<PowerPage>();
                PowerPage.instance.GetPowerCallback = () =>
                {
                    UIController.HidePage<UIMainMenu>();
                    Tween.DelayedCall(0.7f, GameController.Play);
                };
            }
        }

        public void DailyRewardButton()
        {
            UIController.HidePage<UIMainMenu>();
            Tween.DelayedCall(0.5f, () =>
            {
                DailyRewardController.Show();
            });
        }

        public void Update()
        {
            if (GameController.ShouldOpenDaily && graphicRaycaster.enabled)
            {
                GameController.ShouldOpenDaily = false;
                UIController.HidePage<UIMainMenu>();
                DailyRewardController.Show();
            }
        }


    }
}