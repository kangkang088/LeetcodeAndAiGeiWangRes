﻿#pragma warning disable 0649

using UnityEngine;
using UnityEngine.UI;
using TMPro;

namespace PandaXGame
{
    public class GamePauseCanvasBehavior : MonoBehaviour
    {
        private static GamePauseCanvasBehavior instance;

        [Header("Canvas")]
        [SerializeField] Canvas canvas;
        [SerializeField] CanvasGroup backCanvasGroup;
        [SerializeField] GraphicRaycaster raycaster;

        [Header("Panel")]
        [SerializeField] Text pauseText;
        [SerializeField] Image adsButtonImage;
        [SerializeField] Image homeButtonImage;
        [SerializeField] Image playButtonImage;
        [SerializeField] Image replayButtonImage;

        [Header("Ad Button")]
        [SerializeField] TMP_Text coinsForAdsText;
        [SerializeField] Image adsimage;
        [SerializeField] Image coinAdsImage;

        [Header("Coins")]
        [SerializeField] RectTransform coinsPanel;
        [SerializeField] TMP_Text coinsAmount;
        [SerializeField] Image coinImage;

        [Header("Button")]
        [SerializeField] Button replayButton;
        [SerializeField] Button coinsForAdsButton;
        [SerializeField] Button homeButton;
        [SerializeField] Button playButton;

        private static Canvas Canvas => instance.canvas;
        private static CanvasGroup BackCanvasGroup => instance.backCanvasGroup;
        private static GraphicRaycaster Raycaster => instance.raycaster;

        private static Text PauseText => instance.pauseText;
        private static Image AdsButton => instance.adsButtonImage;
        private static Image HomeButtonImage => instance.homeButtonImage;
        private static Image PlayButton => instance.playButtonImage;
        private static Image ReplayButtonImage => instance.replayButtonImage;

        private static TMP_Text CoinsForAdsText => instance.coinsForAdsText;
        private static Image Adsimage => instance.adsimage;
        private static Image CoinImage => instance.coinImage;
        private static Image CoinAdsImage => instance.coinAdsImage;

        private static RectTransform CoinsPanel => instance.coinsPanel;
        private static TMP_Text CoinsAmount => instance.coinsAmount;

        private void Awake()
        {
            instance = this;

            replayButton.onClick.AddListener(ReplayButton);
            coinsForAdsButton.onClick.AddListener(CoinsForAdButton);
            homeButton.onClick.AddListener(HomeButton);
            playButton.onClick.AddListener(CloseButton);
        }

        public void HomeButton()
        {
            AdsManager.Instance.ShowInterstitial();
            GoHome(true);
        }

        public void GoHome(bool interstitialWasDisplayer)
        {
            CloseButton();
            UIController.HidePage<UIGame>();

            LevelController.DisposeLevel();

            Tween.DelayedCall(0.5f, () =>
            {
                UIController.ShowPage<UIMainMenu>();
            });
        }

        public void ReplayButton()
        {
            // AdsManager.ShowInterstitial(); 
            AdsManager.Instance.ShowInterstitial();
            ReplayLevel(true);
        }

        public void ReplayLevel(bool interstitialWasDisplayer)
        {
            CloseButton();
            LevelController.DisposeLevel();

            Tween.DelayedCall(1f, () => LevelController.LoadLevel(LevelController.Level));
        }

        public void CoinsForAdButton()
        {
            AdsManager.Instance.ShowRewardedAd(() =>
            {
                FloatingCloud.SpawnCurrency("Coin", coinAdsImage.rectTransform, (RectTransform)coinsPanel.transform, 10, "", () =>
                {
                    GameController.Coins += GameController.CoinsForAdsAmount;

                    CoinsAmount.text = GameController.Coins.ToString();
                });
            });
        }

        public void CloseButton()
        {
            PauseText.transform.DOScale(0, 0.5f).SetEasing(Ease.Type.SineInOut);
            AdsButton.transform.DOScale(0, 0.5f).SetEasing(Ease.Type.SineInOut);
            HomeButtonImage.transform.DOScale(0, 0.5f).SetEasing(Ease.Type.SineInOut);
            PlayButton.transform.DOScale(0, 0.5f).SetEasing(Ease.Type.SineInOut);
            ReplayButtonImage.transform.DOScale(0, 0.5f).SetEasing(Ease.Type.SineInOut);
            CoinsPanel.transform.DOScale(0, 0.5f).SetEasing(Ease.Type.SineInOut);

            Raycaster.enabled = false;

            BackCanvasGroup.DOFade(0, 0.5f).OnComplete(() =>
            {
                BackCanvasGroup.gameObject.SetActive(false);
                Canvas.enabled = false;

                UIGame.RaycasterEnabled = true;
            });
        }

        public static void Show()
        {
            Canvas.transform.SetPanelZPosition(-0.5f);

            Currency coinCurrency = CurrenciesController.GetCurrency(CurrencyType.Coin);

            Canvas.enabled = true;

            CoinsForAdsText.text = "+" + GameController.CoinsForAdsAmount;

            CoinImage.sprite = coinCurrency.Icon;
            CoinAdsImage.sprite = coinCurrency.Icon;

            PauseText.transform.localScale = Vector3.zero;
            AdsButton.transform.localScale = Vector3.zero;
            HomeButtonImage.transform.localScale = Vector3.zero;
            PlayButton.transform.localScale = Vector3.zero;
            ReplayButtonImage.transform.localScale = Vector3.zero;
            CoinsPanel.transform.localScale = Vector3.zero;

            BackCanvasGroup.gameObject.SetActive(true);
            BackCanvasGroup.alpha = 0;
            BackCanvasGroup.DOFade(1, 0.5f).OnComplete(() =>
            {

                PauseText.transform.DOScale(1, 0.5f).SetEasing(Ease.Type.SineInOut);
                AdsButton.transform.DOScale(1, 0.5f).SetEasing(Ease.Type.SineInOut);
                HomeButtonImage.transform.DOScale(1, 0.5f).SetEasing(Ease.Type.SineInOut);
                PlayButton.transform.DOScale(1, 0.5f).SetEasing(Ease.Type.SineInOut);
                ReplayButtonImage.transform.DOScale(1, 0.5f).SetEasing(Ease.Type.SineInOut);
                CoinsPanel.transform.DOScale(1, 0.5f).SetEasing(Ease.Type.SineInOut);



                Raycaster.enabled = true;
            });

            CoinsAmount.text = GameController.Coins.ToString();
        }
    }
}