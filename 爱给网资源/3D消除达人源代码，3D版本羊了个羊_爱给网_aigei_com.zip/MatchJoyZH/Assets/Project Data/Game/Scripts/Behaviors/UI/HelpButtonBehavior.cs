﻿#pragma warning disable 0649

using System.Collections;
using System.Collections.Generic;
using TMPro;
using UnityEngine;
using UnityEngine.UI;

namespace PandaXGame
{
    public class HelpButtonBehavior : MonoBehaviour
    {
        private static Dictionary<HelpButtonType, string> names = new Dictionary<HelpButtonType, string>()
        {
            { HelpButtonType.Revert, "Revert" },
            { HelpButtonType.Tip, "Tips" },
            { HelpButtonType.Shuffle, "Shuffle"},
        };

        public static string GetName(HelpButtonType type)
        {
            return names[type];
        }

        [SerializeField] HelpButtonType type;
        [Space]
        [SerializeField] TextMeshProUGUI amountText;
        [SerializeField] Image itemIcon;
        private Button button;
        public Button Button => button;

        public HelpButtonType Type => type;

        public Sprite itemIconSprite => itemIcon.sprite;

        public void Awake()
        {
            button = GetComponent<Button>();
        }

        public void Init(int amount)
        {
            amountText.text = amount.ToString();
            
        }

        public void SetInteractable(bool isInteractable)
        {
            button.interactable = isInteractable;
        }
    }

    public enum HelpButtonType
    {
        Revert, Tip, Shuffle
    }
}