﻿#pragma warning disable 0649

using System.Collections.Generic;
using UnityEngine;

namespace PandaXGame
{    
    /// <summary>
    /// 游戏摄像机处理
    /// </summary>
    public class CameraBehavior : MonoBehaviour
    {
        private static CameraBehavior instance;
        
        [SerializeField] Transform _box;
        [SerializeField] public Transform Pos;
        
        public static Transform Box => instance._box;
        public  static Transform POS => instance.Pos;

        private static Vector3 Position { set => instance.transform.position = value; }
        // 摄像机
        public static Camera MainCamera { get; private set; }
        
        public static float HalfWidth { get; private set; }
        
        public static float ItemInSlotScale { get; private set; }

        private void Awake()
        {
            instance = this;
            MainCamera = GetComponent<Camera>();
        }

        public static void Init(int levelSize)
        {

            Box.gameObject.SetActive(true);
            MainCamera.orthographic = true;
            
            HalfWidth = (levelSize + 1) / 2f;

            MainCamera.orthographicSize = HalfWidth / MainCamera.aspect;
            Position = new Vector3(HalfWidth, 10, MainCamera.orthographicSize);

            ItemInSlotScale = HalfWidth * 2f / 10f;
            
            if(UIController.IsTablet)
            {
                Box.localScale = new Vector3(HalfWidth*2f -0.1f , HalfWidth*2f - 1f , 100);
            }
            else
            {
                Box.localScale = new Vector3(HalfWidth*2f - 0.1f ,HalfWidth*2f + 1f, 100);
            }
           
            Box.transform.localPosition = new Vector3(Box.transform.localPosition.x , Box.transform.localPosition.y ,8+ MainCamera.orthographicSize);
   
            
            Tween.NextFrame(() =>
            {
                List<UIPage> pages = UIController.Pages;
                foreach (var page in pages)
                {
                    IPanelOffset panelOffset = page as IPanelOffset;
                    if (panelOffset != null)
                    {
                        panelOffset.RecalculateOffset();
                    }
                }
            });
        }

        public static void InitBuild()
        {
            Box.gameObject.SetActive(false);
            MainCamera.orthographic = false;
            MainCamera.fieldOfView = 60f;   
        }
    }

}