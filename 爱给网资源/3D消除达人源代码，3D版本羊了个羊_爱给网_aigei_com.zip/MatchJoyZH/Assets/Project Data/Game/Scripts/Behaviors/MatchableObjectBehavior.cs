﻿#pragma warning disable 0649

using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.Events;

namespace PandaXGame
{
    public class MatchableObjectBehavior : MonoBehaviour
    {
        private static readonly int OVERLAY_STRENGTH_ID = Shader.PropertyToID("_OverlayStrength");

        public MatchableObject MatchableObject { get; set; }

        [SerializeField] MeshRenderer meshRenderer;
        [SerializeField] ShakeBehavior shakeBehavior;
        public Rigidbody _rigidbody;
        public bool IsActive { get; private set; }

        public int LayerId { get; private set; }
        public int X { get; private set; }
        public int Y { get; private set; }

        public bool IsTransitioning { get; set; }
        public bool IsPicked { get; private set; }

        public UnityAction nextTransition;

        private void Awake()
        {
            _rigidbody = GetComponent<Rigidbody>();
            meshRenderer = GetComponentInChildren<MeshRenderer>();
            shakeBehavior = GetComponent<ShakeBehavior>();
            if (_rigidbody != null)
            {
                _rigidbody.isKinematic = true;
            }
        }

        public void Init(int layerId, int x, int y)
        {
            LayerId = layerId;
            X = x;
            Y = y;
            IsPicked = false;

            if (_rigidbody != null)
            {
                _rigidbody.isKinematic = true;
            }
        }

        public void MarkAsPicked()
        {
            IsPicked = true;
            _rigidbody.isKinematic = true;
        }

        public void OnReverted()
        {
            IsPicked = false;
            _rigidbody.isKinematic = false;
        }

        public void Shake()
        {
            shakeBehavior.Shake();
        }

        public void SetActive(bool isActive)
        {
            IsActive = isActive;
            IsActive = true;

            for (int i = 0; i < meshRenderer.materials.Length; i++)
            {
                meshRenderer.materials[i].SetFloat(OVERLAY_STRENGTH_ID, (0f));
            }
            
            if (_rigidbody != null)
            {
                _rigidbody.isKinematic = false;
            }
        }

        /// <summary>
        /// 设置选中状态
        /// </summary>
        public void SetSelect()
        {
            for (int i = 0; i < meshRenderer.materials.Length; i++)
            {
                meshRenderer.materials[i].SetFloat(OVERLAY_STRENGTH_ID, (0.5f));
            }
        }

        /// <summary>
        /// 去除选中状态
        /// </summary>
        public void RemoveSelect()
        {
            for (int i = 0; i < meshRenderer.materials.Length; i++)
            {
                meshRenderer.materials[i].SetFloat(OVERLAY_STRENGTH_ID, (0f));
            }
        }


        public void SwapPositions(MatchableObjectBehavior other)
        {
            int saveLayerId = LayerId;
            LayerId = other.LayerId;
            other.LayerId = saveLayerId;

            int saveX = X;
            X = other.X;
            other.X = saveX;

            int saveY = Y;
            Y = other.Y;
            other.Y = saveY;

            Vector3 savePosition = transform.position;
            transform.position = other.transform.position;
            other.transform.position = savePosition;

            bool saveActive = IsActive;
            IsActive = other.IsActive;
            other.IsActive = saveActive;
            
           

        }

        private void FixedUpdate()
        {
            if (transform.position.y < -100f)
            {
                transform.position = CameraBehavior.MainCamera.transform.position;
                transform.localScale = Vector3.one;
            }
        }

    }
}
