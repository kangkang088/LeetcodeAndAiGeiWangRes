using System;
using UnityEngine;
using System.Collections;
using UnityEngine.EventSystems;

namespace PandaXGame
{
    public class MoveTarget : MonoBehaviour
    {
        Ray ray;
        RaycastHit hit;
        GameObject obj;
        void Update()
        {
            if (Input.GetMouseButtonDown(0))
            {
                Debug.Log("点击鼠标左键");
                ray = Camera.main.ScreenPointToRay(Input.mousePosition);
                if (Physics.Raycast(ray, out hit))
                {
                    Debug.Log(hit.collider.gameObject.name);
                    obj = hit.collider.gameObject;
                    //通过名字

                    Debug.Log("点中" + obj.name);

                    //通过标签
                    if (obj.tag == "move")
                    {
                        Debug.Log("点中" + obj.name);
                    }
                }
            }
        }

    }
}