﻿#pragma warning disable 0649

using UnityEngine;
using UnityEngine.UI;
using TMPro;


namespace PandaXGame
{
    public class LevelCompletePage : UIPage, IPanelOffset
    {
        private static LevelCompletePage instance;

        [Header("Canvas")]
        [SerializeField] CanvasGroup backCanvasGroup;
        [SerializeField] GraphicRaycaster raycaster;

        [Header("Panel")]
        [SerializeField] GameObject levelCompleteText;
        [SerializeField] Image adsButtonImage;
        [SerializeField] Image homeButtonImage;
        [SerializeField] Image playButtonImage;
        [SerializeField] Image replayButtonImage;

        [Header("Ad Button")]
        [SerializeField] TMP_Text coinsForAdsText;
        [SerializeField] Image adsimage;
        [SerializeField] Image coinImage;

        [Space]
        [SerializeField] Button adsButton;
        [SerializeField] Button homeButton;
        [SerializeField] Button playButton;
        [SerializeField] Button replayButton;
        private static CanvasGroup BackCanvasGroup => instance.backCanvasGroup;
        private static GraphicRaycaster Raycaster => instance.raycaster;

        private static GameObject LevelCompleteText => instance.levelCompleteText;
        private static Image AdsButton => instance.adsButtonImage;
        private static Image HomeButtonImage => instance.homeButtonImage;
        private static Image PlayButton => instance.playButtonImage;
        private static Image ReplayButtonImage => instance.replayButtonImage;

        private static TMP_Text CoinsForAdsText => instance.coinsForAdsText;
        private static Image Adsimage => instance.adsimage;
        private static Image CoinImage => instance.coinImage;

        private void Awake()
        {
            instance = this;

            adsButton.onClick.AddListener(CoinsForAdButton);
            homeButton.onClick.AddListener(HomeButton);
            playButton.onClick.AddListener(PlayNextLevelButton);
            replayButton.onClick.AddListener(ReplayButton);
        }

        public override void Initialise()
        {
            Currency coinCurrency = CurrenciesController.GetCurrency(CurrencyType.Coin);
            coinImage.sprite = coinCurrency.Icon;
        }

        public void RecalculateOffset()
        {
            canvas.transform.SetPanelZPosition(-0.5f);
        }

        public override void PlayShowAnimation()
        {
            EnableCanvas();

            CoinsForAdsText.text = "+" + GameController.CoinsForAdsAmount;
            
            GameController.LevelComplete();
            Tween.NextFrame(() =>
            {
                float halfSize = CoinsForAdsText.preferredWidth / 2f;
                CoinImage.rectTransform.anchoredPosition = new Vector2(halfSize + 20, 0);
                Adsimage.rectTransform.anchoredPosition = new Vector2(-halfSize, 0);
            });

            LevelCompleteText.transform.localScale = Vector3.zero;
            AdsButton.transform.localScale = Vector3.zero;

            HomeButtonImage.transform.localScale = Vector3.zero;
            PlayButton.transform.localScale = Vector3.zero;
            ReplayButtonImage.transform.localScale = Vector3.zero;

            BackCanvasGroup.gameObject.SetActive(true);
            BackCanvasGroup.alpha = 0;
            BackCanvasGroup.DOFade(1, 0.5f).OnComplete(() =>
            {
                LevelCompleteText.transform.DOScale(1, 0.5f).SetEasing(Ease.Type.SineInOut);
                AdsButton.transform.DOScale(1, 0.5f).SetEasing(Ease.Type.SineInOut);

                HomeButtonImage.transform.DOScale(1, 0.5f).SetEasing(Ease.Type.SineInOut);
                PlayButton.transform.DOScale(1, 0.5f).SetEasing(Ease.Type.SineInOut);
                ReplayButtonImage.transform.DOScale(1, 0.5f).SetEasing(Ease.Type.SineInOut);
                AdsButton.gameObject.SetActive(true);
                Raycaster.enabled = true;
                UIController.OnPageOpened(this);
            });
        }

        public override void PlayHideAnimation()
        {
            LevelCompleteText.transform.DOScale(0, 0.5f).SetEasing(Ease.Type.SineInOut);
            AdsButton.transform.DOScale(0, 0.5f).SetEasing(Ease.Type.SineInOut);
            HomeButtonImage.transform.DOScale(0, 0.5f).SetEasing(Ease.Type.SineInOut);
            PlayButton.transform.DOScale(0, 0.5f).SetEasing(Ease.Type.SineInOut);
            ReplayButtonImage.transform.DOScale(0, 0.5f).SetEasing(Ease.Type.SineInOut);

            Raycaster.enabled = false;

            BackCanvasGroup.DOFade(0, 0.5f).OnComplete(() =>
            {
                BackCanvasGroup.gameObject.SetActive(false);
                UIController.OnPageClosed(this);
            });
        }

        public void HomeButton()
        {
            // AdsManager.ShowInterstitial();
            AdsManager.Instance.ShowInterstitial();
            GoHome(true);
        }

        public void GoHome(bool interstitialWasDisplayer)
        {
            UIController.HidePage<LevelCompletePage>();
            UIController.HidePage<UIGame>();
            Tween.DelayedCall(0.5f, () =>
            {
                UIController.ShowPage<UIMainMenu>();
            });
        }

        public void ReplayButton()
        {
            // AdsManager.ShowInterstitial();
            AdsManager.Instance.ShowInterstitial();
            ReplayLevel(true);
        }

        private void ReplayLevel(bool interstitialWasDisplayer)
        {
            UIController.HidePage<LevelCompletePage>();

            Tween.DelayedCall(1f, () => LevelController.LoadLevel(LevelController.Level));
        }

        public void CoinsForAdButton()
        {
            AdsManager.Instance.ShowRewardedAd(() =>
            {
                FloatingCloud.SpawnCurrency("Coin", coinsForAdsText.rectTransform, UIMainMenu.instance.coinsPanel.RectTransform, 10, "", () =>
                {
                    GameController.Coins += GameController.CoinsForAdsAmount;
                });

            });
        }

    
        public void PlayNextLevelButton()
        {
            // AdsManager.ShowInterstitial();
            AdsManager.Instance.ShowInterstitial();
            NextLevel(true);
        }

        private void NextLevel(bool interstitialWasDisplayer)
        {
            UIController.HidePage<LevelCompletePage>();

            Tween.DelayedCall(0.5f, GameController.FinishLevel);
        }
    }
}
