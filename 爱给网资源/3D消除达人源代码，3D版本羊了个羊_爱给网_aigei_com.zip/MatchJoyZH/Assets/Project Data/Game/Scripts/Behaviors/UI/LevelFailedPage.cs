﻿#pragma warning disable 0649

using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;


namespace PandaXGame
{
    public class LevelFailedPage : UIPage, IPanelOffset
    {
        private static LevelFailedPage instance;

        [Header("Canvas")]
        [SerializeField] CanvasGroup backCanvasGroup;
        [SerializeField] GraphicRaycaster raycaster;

        [Header("Panel")]
        [SerializeField] GameObject levelFailedText;
        [SerializeField] Image extraChanceButtonImage;
        [SerializeField] Image homeButtonImage;
        [SerializeField] Image replayButtonImage;

        [Space]
        [SerializeField] Button extraChanceButton;
        [SerializeField] Button homeButton;
        [SerializeField] Button replayButton;

        private static CanvasGroup BackCanvasGroup => instance.backCanvasGroup;
        private static GraphicRaycaster Raycaster => instance.raycaster;

        private static GameObject LevelFailedText => instance.levelFailedText;
        private static Image ExtraChanceImage => instance.extraChanceButtonImage;
        private static Image HomeButtonImage => instance.homeButtonImage;
        private static Image ReplayButtonImage => instance.replayButtonImage;

        private void Awake()
        {
            instance = this;

            extraChanceButton.onClick.AddListener(ExtraChanceButton);
            homeButton.onClick.AddListener(HomeButton);
            replayButton.onClick.AddListener(TryAgainButton);
        }

        public override void Initialise()
        {
        }

        public void RecalculateOffset()
        {
            canvas.transform.SetPanelZPosition(-0.5f);
        }

        public override void PlayShowAnimation()
        {
            EnableCanvas();

            LevelFailedText.transform.localScale = Vector3.zero;
            ExtraChanceImage.transform.localScale = Vector3.zero;
            HomeButtonImage.transform.localScale = Vector3.zero;
            ReplayButtonImage.transform.localScale = Vector3.zero;

            BackCanvasGroup.gameObject.SetActive(true);
            BackCanvasGroup.alpha = 0;
            BackCanvasGroup.DOFade(1, 0.5f).OnComplete(() =>
            {

                LevelFailedText.transform.DOScale(1, 0.5f).SetEasing(Ease.Type.SineInOut);
                ExtraChanceImage.transform.DOScale(1, 0.5f).SetEasing(Ease.Type.SineInOut);
                HomeButtonImage.transform.DOScale(1, 0.5f).SetEasing(Ease.Type.SineInOut);
                ReplayButtonImage.transform.DOScale(1, 0.5f).SetEasing(Ease.Type.SineInOut);


                Raycaster.enabled = true;
                UIController.OnPageOpened(this);
            });
        }

        public override void PlayHideAnimation()
        {
            LevelFailedText.transform.DOScale(0, 0.5f).SetEasing(Ease.Type.SineInOut);
            ExtraChanceImage.transform.DOScale(0, 0.5f).SetEasing(Ease.Type.SineInOut);
            HomeButtonImage.transform.DOScale(0, 0.5f).SetEasing(Ease.Type.SineInOut);
            ReplayButtonImage.transform.DOScale(0, 0.5f).SetEasing(Ease.Type.SineInOut);



            Raycaster.enabled = false;

            BackCanvasGroup.DOFade(0, 0.5f).OnComplete(() =>
            {
                BackCanvasGroup.gameObject.SetActive(false);
                UIController.OnPageClosed(this);
            });
        }


        public void HomeButton()
        {
            // AdsManager.ShowInterstitial();
            AdsManager.Instance.ShowInterstitial();
            GoHome(true);
        }

        private void GoHome(bool interstitialWasDisplayer)
        {
            UIController.HidePage<LevelFailedPage>();
            UIController.HidePage<UIGame>();

            LevelController.DisposeLevel();

            Tween.DelayedCall(0.5f, () =>
            {
                UIController.ShowPage<UIMainMenu>();
            });
        }

        public void ExtraChanceButton()
        {
            // AdsManager.ShowRewardBasedVideo(, true);
            AdsManager.Instance.ShowRewardedAd(ExtraChance);
        }

        private void ExtraChance()
        {
            UIController.HidePage<LevelFailedPage>();
            Tween.DelayedCall(0.5f, SlotsController.ReturnThreeLast);
        }

        public void TryAgainButton()
        {
            // AdsManager.ShowInterstitial();
            AdsManager.Instance.ShowInterstitial();
            ReplayLevel(true);
        }

        private void ReplayLevel(bool interstitialWasShown)
        {
            if (PowerManager.Instance.NowHP > 0)
            {
                UIController.HidePage<LevelFailedPage>();
                LevelController.DisposeLevel();
                Tween.DelayedCall(1f, () => LevelController.LoadLevel(LevelController.Level));
            }
            else
            {
                UIController.ShowPage<PowerPage>();
                PowerPage.instance.GetPowerCallback = () =>
                {
                    UIController.HidePage<LevelFailedPage>();
                    LevelController.DisposeLevel();
                    Tween.DelayedCall(1f, () => LevelController.LoadLevel(LevelController.Level));
                };
            }
        }
    }
}