using UnityEngine;

/// <summary>
/// 方块建设
///    每一个方块需要 4 步
/// </summary> 
public class LandComment : MonoBehaviour
{
    public GameObject[] ground0;

    public GameObject[] ground1;

    public GameObject[] ground2;

    public GameObject[] ground3;

    private float rotateSpeed = 30f;
    private Vector2 nTouchPos1;
    private Vector2 nTouchPos2;
    private Vector2 oTouchPos1;
    private Vector2 oTouchPos2;

 
    void Update()
    {
        //旋转
        if (Input.GetMouseButton(0))
        {
            if (Input.touchCount == 1)
            {
                if (Input.GetTouch(0).phase == TouchPhase.Moved)
                {
                    Debug.Log("开始旋转");
                    float moveX = Input.GetTouch(0).deltaPosition.x;
                    Debug.Log("滑动的距离" + moveX);
                    transform.Rotate(Vector3.up * -rotateSpeed * moveX * Time.deltaTime);
                }
            }
        }

        // ZoomInOut();
        // if (this.transform.position.y > 0)
        // {
        //     return;
        // }
        // this.transform.Translate(new Vector3(0, 0.5f, 0) * Time.deltaTime);
    }


    bool IsEnLarge(Vector2 nPos1, Vector2 nPos2, Vector2 oPos1, Vector2 oPos2)
    {
        float nDis = Vector2.Distance(nPos1, nPos2);
        float oDis = Vector2.Distance(oPos1, oPos2);

        if (nDis < oDis)
        {
            return false;
        }
        else
        {
            return true;
        }
    }

    void ZoomInOut()
    {
        if (Input.touchCount == 2)
        {
            if (Input.GetTouch(0).phase == TouchPhase.Moved || Input.GetTouch(1).phase == TouchPhase.Moved)
            {
                nTouchPos1 = Input.GetTouch(0).position;
                nTouchPos2 = Input.GetTouch(1).position;

                if (IsEnLarge(nTouchPos1, nTouchPos2, oTouchPos1, oTouchPos2))
                {
                    Vector3 nScale = transform.localScale * 1.01f;
                    transform.localScale = new Vector3(nScale.x, nScale.y, nScale.z);
                }
                else
                {
                    Vector3 nScale = transform.localScale * 0.99f;
                    transform.localScale = new Vector3(nScale.x, nScale.y, nScale.z);
                }

                oTouchPos1 = nTouchPos1;
                oTouchPos2 = nTouchPos2;
            }
        }
    }
}
