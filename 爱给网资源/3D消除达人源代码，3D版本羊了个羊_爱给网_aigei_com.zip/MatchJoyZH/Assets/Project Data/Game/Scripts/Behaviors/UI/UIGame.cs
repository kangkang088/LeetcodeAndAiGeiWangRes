﻿#pragma warning disable 0649

using UnityEngine;
using UnityEngine.UI;
using TMPro;

namespace PandaXGame
{
    public class UIGame : UIPage, IPanelOffset
    {
        private static UIGame instance;

        [Header("Canvases")]
        [SerializeField] Canvas gameCanvas;

        [Space]
        [SerializeField] CanvasGroup gameCanvasGroup;
        [SerializeField] CanvasGroup slotsCanvasGroup;

        [Space]
        [SerializeField] GraphicRaycaster raycaster;

        [Header("Game Panel")]
        [SerializeField] TMP_Text levelNumber;
        [SerializeField] RectTransform pauseButtonRect;
    
        [Header("Help Buttons")]
        [SerializeField] RectTransform buttonsTransform;

        [Space]
        [SerializeField] Button pauseButton;

        [Space]
        [SerializeField] PUUIController puUIController;
        
        
        
        
        public PUUIController PowerUpsUIController => puUIController;

        private static RectTransform ButtonsTransform => instance.buttonsTransform;
        private static RectTransform PauseButtonRect => instance.pauseButtonRect;
        private static RectTransform LevelNumberTransform => instance.levelNumber.rectTransform;

        private static Canvas GameCanvas => instance.gameCanvas;

        public static bool RaycasterEnabled { get => instance.raycaster.enabled; set => instance.raycaster.enabled = value; }

        private static CanvasGroup GameCanvasGroup => instance.gameCanvasGroup;
        private static CanvasGroup SlotsCanvasGroup => instance.slotsCanvasGroup;

        public static int LevelNumber { set => instance.levelNumber.text = "关卡 " + (value + 1); }

        private void Awake()
        {
            instance = this;
        }

        public override void Initialise()
        {
            pauseButton.onClick.AddListener(PauseButon);
        }

        public void RecalculateOffset()
        {
            canvas.transform.SetPanelZPosition(-1);
        }

        public override void PlayShowAnimation()
        {
            GameCanvas.enabled = true;

            GameCanvasGroup.alpha = 0;
            SlotsCanvasGroup.alpha = 0;

            GameCanvasGroup.DOFade(1, 0.4f);
            SlotsCanvasGroup.DOFade(1, 0.4f);


            ButtonsTransform.anchoredPosition = new Vector2(0, -300);
            PauseButtonRect.anchoredPosition = new Vector2(112, 100);
            LevelNumberTransform.anchoredPosition = new Vector2(0, 300);

            ButtonsTransform.DOAnchoredPosition(Vector2.zero, 0.4f).SetEasing(Ease.Type.SineOut);
            PauseButtonRect.DOAnchoredPosition(new Vector2(112, -110), 0.4f).SetEasing(Ease.Type.SineOut);
            LevelNumberTransform.DOAnchoredPosition(new Vector2(0, -100), 0.4f).SetEasing(Ease.Type.SineOut);

            puUIController.OnLevelStarted(GameController.CurrentLevelId);

            UIController.OnPageOpened(this);

        }

        public override void PlayHideAnimation()
        {
            GameCanvasGroup.alpha = 1;
            SlotsCanvasGroup.alpha = 1;

            GameCanvasGroup.DOFade(0, 0.4f);
            SlotsCanvasGroup.DOFade(0, 0.4f).OnComplete(() =>
            {
                UIController.OnPageClosed(this);
            });

            RaycasterEnabled = false;
        }

        public void PauseButon()
        {
            RaycasterEnabled = false;
            GamePauseCanvasBehavior.Show();
        }

      
    }

    public interface IPanelOffset
    {
        void RecalculateOffset();
    }

    public static class UIOverlayHelper
    {
        public static void SetPanelZPosition(this Transform panelTransform, float offset)
        {
            Vector3 cameraPosition = Camera.main.transform.position + new Vector3(0, offset, 0);
            Vector3 canvasPosition = UIController.MainCanvas.transform.InverseTransformPoint(cameraPosition);

            panelTransform.localPosition = new Vector3(panelTransform.localPosition.x, panelTransform.localPosition.y, canvasPosition.z);
        }
    }


}
