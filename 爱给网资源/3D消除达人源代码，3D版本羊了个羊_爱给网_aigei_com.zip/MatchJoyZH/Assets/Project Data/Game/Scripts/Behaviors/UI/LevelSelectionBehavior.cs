﻿#pragma warning disable 0649

using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;


namespace PandaXGame
{
    public class LevelSelectionBehavior : UIPage
    {
        private static readonly string LEVEL_CELL_POOL_NAME = "Level Cell";

        private static LevelSelectionBehavior instance;

        [Header("Canvas")]
        [SerializeField] Canvas levelSelectionCanvas;
        [SerializeField] CanvasGroup levelSelectionCanvasGroup;
        [SerializeField] GraphicRaycaster raycaster;
        
        [Header("Panel")]
        [SerializeField] RectTransform scrollViewRect;
        [SerializeField] RectTransform contentRect;
        [SerializeField] RectTransform gridRect;

        [Header("Buttons")]
        [SerializeField] Button backButton;

        private static Canvas LevelSelectionCanvas => instance.levelSelectionCanvas;
        private static CanvasGroup LevelSelectionCanvasGroup => instance.levelSelectionCanvasGroup;
        private static GraphicRaycaster Raycaster => instance.raycaster;

        private static RectTransform ContentRect => instance.contentRect;
        private static RectTransform GridRect => instance.gridRect;

        private static Pool levelCellPool;

        private void Awake()
        {
            instance = this;

            levelCellPool = PoolManager.GetPoolByName(LEVEL_CELL_POOL_NAME);
            backButton.onClick.AddListener(BackButton);
        }

        public override void Initialise()
        {

        }

        public override void PlayShowAnimation()
        {
            SpawnElements();

            LevelSelectionCanvas.enabled = true;

            LevelSelectionCanvasGroup.alpha = 0;

            LevelSelectionCanvasGroup.DOFade(1, 0.4f).OnComplete(() =>
            {
                Raycaster.enabled = true;
                UIController.OnPageOpened(this);
            });
        }

        public override void PlayHideAnimation()
        {
            LevelSelectionCanvasGroup.DOFade(0, 0.4f).OnComplete(() => 
            {
                LevelSelectionCanvas.enabled = false;
                UIController.OnPageClosed(this);
            });

            Raycaster.enabled = false;

        }

        public static void SpawnElements()
        {
            levelCellPool.ReturnToPoolEverything();
            
            for(int i = 0; i < GameController.LevelDatabase.AmountOfLevels; i++)
            {
                LevelCellBehavior level = levelCellPool.GetPooledObject().GetComponent<LevelCellBehavior>();

                level.transform.SetParent(GridRect.transform);
                level.transform.localScale = Vector3.one;
                level.transform.localRotation = Quaternion.identity;

                level.LevelNumber = i;
                level.IsSelected = i == GameController.CurrentLevelId;
                level.IsOpened = i <= GameController.MaxLevelReachedId;
            }

            ContentRect.sizeDelta = ContentRect.sizeDelta.SetY((GameController.LevelDatabase.AmountOfLevels / 4 + 1) * 240);
        }

        public void BackButton()
        {
            UIController.HidePage<LevelSelectionBehavior>();

            Tween.DelayedCall(0.4f, () =>
            {
                UIController.ShowPage<UIMainMenu>();
            });
        }

      
    }
}
