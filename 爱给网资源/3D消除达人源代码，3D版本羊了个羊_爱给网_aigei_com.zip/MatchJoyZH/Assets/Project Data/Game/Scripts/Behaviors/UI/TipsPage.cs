﻿#pragma warning disable 0649

using System;
using UnityEngine;
using UnityEngine.UI;


namespace PandaXGame
{
    public class TipsPage : UIPage, IPanelOffset
    {
        public static TipsPage instance;

        [SerializeField] GameObject OnPopPage;

        [Header("Canvas")]
        [SerializeField] GraphicRaycaster raycaster;


        [Header("Panel")]
        [SerializeField] Text titleText;
        [SerializeField] Text contentText;

        [Space]
        [SerializeField] TintedButton confirmButton; // 确定
        [SerializeField] TintedButton canelButton;   // 取消
        [SerializeField] AnimatedButton closeButton;   // 关闭

        public Action onConfirm;
        public Action onCancel;

        private static GraphicRaycaster Raycaster => instance.raycaster;

        public static Text TitleText => instance.titleText;
        public static Text ContentText => instance.contentText;


        private void Awake()
        {
            instance = this;

            confirmButton.onClick.AddListener(ClickConfirmButton);
            canelButton.onClick.AddListener(ClickCanelButton);
            closeButton.onClick.AddListener(ClickCloseButton);
        }

        public override void Initialise()
        {
        }

        public void RecalculateOffset()
        {
            gameObject.transform.localPosition = Vector3.zero;
            // canvas.transform.SetPanelZPosition(-0.5f);
        }

        public override void PlayShowAnimation()
        {
            EnableCanvas();
            Raycaster.enabled = true;
            OnPopPage.SetActive(false);
            OnPopPage.SetActive(true);
            UIController.OnPageOpened(this);
        }

        public override void PlayHideAnimation()
        {
            Raycaster.enabled = false;
            UIController.OnPageClosed(this);
            titleText.text = "";
            contentText.text = "";
        }

        public void ClickCanelButton()
        {
            PlayHideAnimation();
            if(onCancel != null)
            {
                onCancel();
                onCancel = null;
                onConfirm = null;
            }
        }

        public void ClickConfirmButton()
        {
            PlayHideAnimation();
            if(onConfirm != null)
            {
                onConfirm();
                onCancel = null;
                onConfirm = null;
            }
        }

        public void ClickCloseButton()
        {
           
            PlayHideAnimation();
            if(onCancel != null)
            {
                onCancel();
                onCancel = null;
                onConfirm = null;
            }
        }

     
    }
}