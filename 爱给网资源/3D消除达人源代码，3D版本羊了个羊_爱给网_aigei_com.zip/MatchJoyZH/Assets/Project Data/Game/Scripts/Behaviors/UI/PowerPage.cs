﻿#pragma warning disable 0649

using System;
using UnityEngine;
using UnityEngine.UI;


namespace PandaXGame
{
    public class PowerPage : UIPage, IPanelOffset
    {
        public static PowerPage instance;

        [SerializeField] GameObject OnPopPage;
        [Header("Canvas")]
        [SerializeField] GraphicRaycaster raycaster;
        [Space]
        [SerializeField] Button confirmButton; // 确定
        [SerializeField] Button closeButton;   // 关闭

        private static GraphicRaycaster Raycaster => instance.raycaster;

        public Action GetPowerCallback;
        private void Awake()
        {
            instance = this;
            confirmButton.onClick.AddListener(ClickConfirmButton);
            closeButton.onClick.AddListener(ClickCloseButton);
        }

        public override void Initialise()
        {
        }

        public void RecalculateOffset()
        {
            canvas.transform.SetPanelZPosition(-0.5f);
        }

        public override void PlayShowAnimation()
        {
            EnableCanvas();
            Raycaster.enabled = true;
            OnPopPage.SetActive(false);
            OnPopPage.SetActive(true);
            UIController.OnPageOpened(this);
        }

        public override void PlayHideAnimation()
        {
            Raycaster.enabled = false;
            UIController.OnPageClosed(this);
        }

        public void ClickConfirmButton()
        {
            AdsManager.Instance.ShowRewardedAd(() =>
            {
                UIController.HidePage<PowerPage>();
                PowerManager.Instance.AddRemoveHP(1);
                if (GetPowerCallback != null)
                {
                    GetPowerCallback();
                }
            });
        }

        public void ClickCloseButton()
        {
            PlayHideAnimation();
        }

    }
}