﻿#pragma warning disable 0649

using UnityEngine;
using UnityEngine.UI;
using TMPro;

namespace PandaXGame
{
    public class DailyReward : MonoBehaviour
    {
        [SerializeField] int reward;

        [Space]
        [SerializeField] GameObject uncollectedInfo;
        [SerializeField] GameObject collectedInfo;

        [Space]
        [SerializeField] TMP_Text rewardAmount;
        [SerializeField] Image currencyImage;

        public int Reward => reward;

        public void Init(bool collected)
        {
            uncollectedInfo.SetActive(!collected);
            collectedInfo.SetActive(collected);

            rewardAmount.text = reward.ToString();

            Currency currency = CurrenciesController.GetCurrency(CurrencyType.Coin);
            currencyImage.sprite = currency.Icon;
        }
    }
}