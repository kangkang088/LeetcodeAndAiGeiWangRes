﻿#pragma warning disable 0649

using System;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using PandaXGame.MatchJoy;

namespace PandaXGame
{

    public class DailyRewardController : MonoBehaviour
    {
        private static DailyRewardController instance;

        [Header("Canvas")]
        [SerializeField] Canvas dailyCanvas;
        [SerializeField] GraphicRaycaster raycaster;

        [Header("Panel")]

        [SerializeField] GameObject sameDayObject;
        [SerializeField] Image closeButtonImage;

        [Header("Rewards")]
        [SerializeField] List<DailyReward> rewards;

        [Header("Buttons")]
        [SerializeField] Button closeButton;
        [SerializeField] Button signInButton;
        [SerializeField] Button signInDoubleButton;

        private static Canvas DailyCanvas => instance.dailyCanvas;
        private static GraphicRaycaster Raycaster => instance.raycaster;

        private static GameObject SignInObject => instance.signInButton.gameObject;
        private static GameObject SignInDoubleObject => instance.signInDoubleButton.gameObject;
        private static GameObject SameDayObject => instance.sameDayObject;
        private static Image CloseButtonImage => instance.closeButtonImage;


        private static List<DailyReward> Rewards => instance.rewards;

        private static DailySave save;

        private void Awake()
        {
            instance = this;
        }

        public static bool Init()
        {
            save = SaveController.GetSaveObject<DailySave>("daily_save");

            DateTime now = DateTime.Now;
            DateTime last = DateTime.FromBinary(save.DailyLastDay);

            for (int i = 0; i < save.DailyDays; i++)
            {
                Rewards[i].Init(true);
            }

            for (int i = save.DailyDays; i < Rewards.Count; i++)
            {
                Rewards[i].Init(false);
            }

            instance.closeButton.onClick.AddListener(instance.CloseButton);
            instance.signInButton.onClick.AddListener(instance.SignInButton);
            instance.signInDoubleButton.onClick.AddListener(instance.SignInDoubleButton);

            bool watchedAlready = now.Day == last.Day;

            SignInObject.SetActive(!watchedAlready);
            SignInDoubleObject.SetActive(!watchedAlready);
            SameDayObject.SetActive(watchedAlready);

            return !watchedAlready;
        }

        public static void Show()
        {
            DailyCanvas.enabled = true;

            for (int i = 0; i < Rewards.Count; i++)
            {
                DailyReward reward = Rewards[i];

                reward.transform.localScale = Vector3.zero;
            }

            Rewards.DOAction((start, end, t) =>
            {
                float time = t;

                if (time > 1)
                {
                    time = 1 + (time - 1) / 2f;
                }

                Vector3 result = start + (end - start) * t;

                for (int i = 0; i < Rewards.Count; i++)
                {
                    Rewards[i].transform.localScale = result;
                }

                CloseButtonImage.transform.localScale = result;
                SignInObject.transform.localScale = result;
                SignInDoubleObject.transform.localScale = result;
                SameDayObject.transform.localScale = result;

            }, Vector3.zero, Vector3.one, 0.5f).SetEasing(Ease.Type.SineInOut).OnComplete(() => Raycaster.enabled = true);
        }

        public static void Hide()
        {
            Raycaster.enabled = false;

            Rewards.DOAction((start, end, t) =>
            {

                float time = t;

                if (time < 0)
                {
                    time /= 2f;
                }

                Vector3 result = start + (end - start) * t;

                for (int i = 0; i < Rewards.Count; i++)
                {
                    Rewards[i].transform.localScale = result;
                }

                CloseButtonImage.transform.localScale = result;
                SignInObject.transform.localScale = result;
                SignInDoubleObject.transform.localScale = result;
                SameDayObject.transform.localScale = result;

            }, Vector3.one, Vector3.zero, 0.5f).SetEasing(Ease.Type.SineInOut).OnComplete(() =>
            {
                DailyCanvas.enabled = false;
            });

            Tween.DelayedCall(0.5f, () =>
            {
                UIController.ShowPage<UIMainMenu>();
            });
        }

        public void SignInButton()
        {
            int reward = Rewards[save.DailyDays].Reward;

            SignIn(reward);
        }

        private void SignIn(int reward)
        {
            GameController.Coins += reward;

            save.DailyDays++;

            if (save.DailyDays == Rewards.Count)
            {
                save.DailyDays = 0;
            }

            save.DailyLastDay = DateTime.Now.ToBinary();

            Init();

            Hide();
        }

        public void SignInDoubleButton()
        {
            AdsManager.Instance.ShowRewardedAd(() =>
            {
                int reward = Rewards[save.DailyDays].Reward * 2;
                SignIn(reward);
            });
        }

        public void CloseButton()
        {
            Hide();
        }
    }
}