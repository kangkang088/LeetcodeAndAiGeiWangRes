using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using PandaXGame;

namespace PandaXGame.MatchJoy
{
    [System.Serializable]
    public class DailySave : ISaveObject
    {
        public int DailyDays;
        public long DailyLastDay;

        public DailySave()
        {
            DailyDays = 0;
            DailyLastDay = 0;
        }

        public void Flush()
        {
        }
    }
}