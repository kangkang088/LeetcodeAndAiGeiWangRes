//
//  VFSDK.h
//  Unity-iPhone
//  基础sdk，包括登录，支付，分享相关
//

#import <Foundation/Foundation.h>
#import <StoreKit/StoreKit.h>
NS_ASSUME_NONNULL_BEGIN

@interface VFSDK : NSObject

+(VFSDK *) getInstance;

/**
 apple登录
 */
-(void)AppleVibrate;

@end
NS_ASSUME_NONNULL_END
