//
//  VFSDK.m
//  Unity-iPhone
//

#import "VFSDK.h"
#import <AudioToolbox/AudioToolbox.h>

#define UnitySDKCallBackNNode @"SDKCallback"

@implementation VFSDK

static VFSDK* instance = nil;

//单例
+(VFSDK *) getInstance{
    if (instance == nil) {
        instance = [[VFSDK alloc] init];
    }
    return instance;
}

//相当于将构造函数设置为私有，类的实例只能初始化一次
+(id) allocWithZone:(struct _NSZone*)zone
{
    if (instance == nil) {
        instance = [super allocWithZone:zone];
    }
    return instance;
}

//重写copy方法中会调用的copyWithZone方法，确保单例实例复制时不会重新创建
-(id) copyWithZone:(struct _NSZone *)zone
{
    return instance;
}
#pragma mark -导出


- (void)AppleVibrate
{
     AudioServicesPlaySystemSound(1519);
}

-(void)StoreReview
{
    if (@available(iOS 10.3, *)) {
            [SKStoreReviewController requestReview];
    }
}


@end

extern "C"
{
    void appleVibrate()
    {
           [[VFSDK getInstance] AppleVibrate];
    }
    
    void _StoreReview()
    {
         [[VFSDK getInstance] StoreReview];
    }
          
}
