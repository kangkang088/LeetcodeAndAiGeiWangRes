#import "UnityAppController.h"

#import <AppTrackingTransparency/AppTrackingTransparency.h>
@interface VFUnityAppController : UnityAppController
@end

IMPL_APP_CONTROLLER_SUBCLASS (VFUnityAppController)

@implementation VFUnityAppController

- (BOOL)application:(UIApplication*)app openURL:(NSURL*)url options:(NSDictionary<NSString*, id>*)options
{
    [super application:app openURL:url options:options];
    return YES;
}

- (BOOL)application:(UIApplication*)application didFinishLaunchingWithOptions:(NSDictionary*)launchOptions
{
    [super application:application didFinishLaunchingWithOptions:launchOptions];

    return YES;
}

- (void)applicationWillEnterForeground:(UIApplication*)application
{
    [super applicationWillEnterForeground:application];
}

- (void)applicationDidBecomeActive:(UIApplication*)application
{
    [super applicationDidBecomeActive:application];
    
    if (@available(iOS 14.0, *))
    {
        // iOS14及以上版本请求权限
        [ATTrackingManager requestTrackingAuthorizationWithCompletionHandler:^(ATTrackingManagerAuthorizationStatus status)
         {
        }];
    }
}

- (void)applicationDidEnterBackground:(UIApplication*)application
{
    [super applicationDidEnterBackground:application];
}

@end
