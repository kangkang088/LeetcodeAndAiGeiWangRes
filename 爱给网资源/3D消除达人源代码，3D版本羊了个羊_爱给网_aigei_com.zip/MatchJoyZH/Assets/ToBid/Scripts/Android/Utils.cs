namespace WindMill.Advertisements
{

	using System;
    using System.Collections.Generic;
    using UnityEngine;

    public static class Utils {

		public static string ToStringAndroidObject(AndroidJavaObject adInfo){
			if(adInfo != null){
				return adInfo.Call<string>("toString");
			}
			return null;
		}

		public static Dictionary<string, object> GetDictFromNativeMap(AndroidJavaObject map)
		{
			if(map != null){
				var dict = new Dictionary<string, object>();

				var size = map.Call<int>("size");
				if (size > 0)
				{
						var keys = map.Call<AndroidJavaObject>("keySet");
						var iterator = keys.Call<AndroidJavaObject>("iterator");
						while (iterator.Call<bool>("hasNext"))
						{
							var next = iterator.Call<AndroidJavaObject>("next");
							var theKey = next.Call<string>("toString");
							var theValue = map.Call<AndroidJavaObject>("get", theKey);
							if (theValue != null)
							{
								var theValueString = theValue.Call<string>("toString");
								dict.Add(theKey, theValueString);
							}
							else
							{
								dict.Add(theKey, null);
							}
						}
				}
				return dict;

			}

			return null;
		}

		public static AndroidJavaObject DictionaryToAndroidHashMap(Dictionary<string,object> parameters){
			if (parameters != null) {
				int count = parameters.Count;
				AndroidJavaObject map = new AndroidJavaObject("java.util.HashMap", count);
				IntPtr method_Put = AndroidJNIHelper.GetMethodID(map.GetRawClass(), 
						"put", "(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;");
				object[] args = new object[2];
				foreach (KeyValuePair<string, object> kvp in parameters) {

					args[0] = new AndroidJavaObject("java.lang.String", kvp.Key);
					if (typeof(System.String).IsInstanceOfType(kvp.Value)) {
						args[1] = new AndroidJavaObject("java.lang.String", kvp.Value);
					} else {
						args[1] = new AndroidJavaObject("java.lang.Double", ""+kvp.Value);
					}
					AndroidJNI.CallObjectMethod(map.GetRawObject(), method_Put, AndroidJNIHelper.CreateJNIArgArray(args));
				}

				return map;

			} else {
				return null;	
			}
		}
    }

}

