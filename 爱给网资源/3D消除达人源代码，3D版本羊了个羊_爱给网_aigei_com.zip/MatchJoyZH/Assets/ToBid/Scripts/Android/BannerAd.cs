﻿namespace WindMill.Advertisements
{
#if !UNITY_EDITOR && UNITY_ANDROID

    using System;
    using System.Collections.Generic;
    using System.Runtime.InteropServices;
    using UnityEngine;

    public sealed class BannerAd : IDisposable
    {

        private readonly Request request;

        private readonly AndroidJavaClass unityPlayer = new AndroidJavaClass("com.unity3d.player.UnityPlayer");
        private AndroidJavaObject mActivity;

        private IBannerAdListener adInteractionListener;

        AndroidJavaObject mBannerAdSupport;
       AndroidJavaObject mBannerAdRequest;


        public BannerAd(Request request)
        {
            this.request = request;
        }

        public string PlacementId
        {
            get
            {
                return this.request?.PlacementId;
            }
        }

        private AdInfo adInfo;


        private AndroidJavaObject getBannerAdSupport()
        {
            if (mBannerAdSupport != null)
            {
                return mBannerAdSupport;
            }
            if (mActivity == null)
            {
                var unityPlayer = new AndroidJavaClass("com.unity3d.player.UnityPlayer");
                mActivity = unityPlayer.GetStatic<AndroidJavaObject>("currentActivity");
            }
            var jc = new AndroidJavaClass("com.windmill.sdk.BannerAdUnitySupport");
            mBannerAdSupport = jc.CallStatic<AndroidJavaObject>("getInstance");
            return mBannerAdSupport;
        }


        public AdInfo GetAdInfo() {
            return adInfo;
        }

        public void updateAdInfo(AndroidJavaObject obj) {
            string adInfoJson = Utils.ToStringAndroidObject(obj);
            Debug.Log("dll--updateAdInfo " + adInfoJson + " | "+ PlacementId);
            adInfo = AdInfo.CreateAdInfoFromJson(adInfoJson);
        }

        public List<AdInfo> GetCacheAdInfoList(){

            Debug.Log("dll--getCacheAdInfoList " );
            AndroidJavaObject bannerAdSupport = getBannerAdSupport(); 
            if(bannerAdSupport != null){
                AndroidJavaObject cacheAdInfoList = bannerAdSupport.Call<AndroidJavaObject>("getCacheAdInfoList");

                if(cacheAdInfoList != null){
                    AndroidJavaObject[] objList = cacheAdInfoList.Call<AndroidJavaObject[]>("toArray");

                    if(objList != null){
                        List<AdInfo> result = new List<AdInfo>();

                        foreach(AndroidJavaObject obj in objList){
                        
                            string cacheAdInfoListJson = Utils.ToStringAndroidObject(obj);
                            result.Add(AdInfo.CreateAdInfoFromJson(cacheAdInfoListJson));
                        }
                        return result;
                    }
                }
            }
            return null;
        } 

        public void Dispose()
        {
            HideAd();

            AndroidJavaObject bannerAdSupport = getBannerAdSupport();
            bannerAdSupport.Call("destroy");
            this.mBannerAdSupport = null;
            this.mBannerAdRequest = null;

        }

        public void LoadAd(int width, int height)
        {
            var androidListener = new BannerAdInteractionListener(this);

           
            AndroidJavaObject bannerAdSupport = getBannerAdSupport(); 
            if (mBannerAdRequest == null)
            {
                 mBannerAdRequest = new AndroidJavaObject("com.windmill.sdk.banner.WMBannerAdRequest", this.request.PlacementId, this.request.UserId, this.request.options);
            }

            bannerAdSupport.Call<bool>("loadAd",mActivity, mBannerAdRequest, width, height, androidListener);
        }

        /// <summary>
        /// Load reward video Ad.
        /// </summary>
        public void LoadAd()
        {
            var androidListener = new BannerAdInteractionListener(this);

           
            AndroidJavaObject bannerAdSupport = getBannerAdSupport(); 
            if (mBannerAdRequest == null)
            {
                 mBannerAdRequest = new AndroidJavaObject("com.windmill.sdk.banner.WMBannerAdRequest", this.request.PlacementId, this.request.UserId, this.request.options);
            }

            bannerAdSupport.Call<bool>("loadAd",mActivity, mBannerAdRequest, androidListener);

        }

        /// <summary>
        /// Sets the interaction listener for this Ad.
        /// </summary>
        public void SetBannerAdListener(IBannerAdListener listener)
        {
            this.adInteractionListener = listener;
        }

        public bool Ready()
        {
            AndroidJavaObject bannerAdSupport = getBannerAdSupport(); 
            return bannerAdSupport.Call<bool>("isReady");
        }

        public void HideAd()
        {
           
            AndroidJavaObject bannerAdSupport = getBannerAdSupport(); 

            bannerAdSupport.Call("hideAd",mActivity);
        }

        /// <summary>
        /// Show the reward video Ad.
        /// </summary>
        public void ShowAd(Rect rect)
        {
           
            AndroidJavaObject bannerAdSupport = getBannerAdSupport(); 

            bannerAdSupport.Call<bool>("showAd",mActivity,(int)rect.x,(int)rect.y, (int)rect.width,(int)rect.height);
        }

#pragma warning disable SA1300
#pragma warning disable IDE1006

        private sealed class BannerAdInteractionListener : AndroidJavaProxy
        {

            private readonly BannerAd bannerAd;

            public BannerAdInteractionListener(BannerAd bannerAd) : base("com.windmill.sdk.banner.WMBannerAdListener")
            {
                this.bannerAd = bannerAd;
            }

             public void onAdLoadSuccess(string placementId) {
                   Debug.Log("dll--onAdLoadSuccess " + this.bannerAd?.PlacementId);
                   this.bannerAd?.adInteractionListener.OnAdLoad(this.bannerAd);
             }

            public void onAdLoadError(AndroidJavaObject windMillError, string placementId) {
                        Debug.Log("dll--onAdLoadError " + this.bannerAd?.PlacementId);


                        string msg = windMillError.Call<string>("toString");
                        int code = windMillError.Call<int>("getErrorCode");
                        Debug.Log("dll--onBannerAdLoadError " + msg + ": code" + code + " :" + placementId);
                        Error error = new Error(code, msg);
                        this.bannerAd?.adInteractionListener.OnAdError(this.bannerAd, error);
            }

            public void onAdShown(AndroidJavaObject adInfo) {
                    Debug.Log("dll--onAdShown " + this.bannerAd?.PlacementId);
                
                    this.bannerAd?.updateAdInfo(adInfo);

                    this.bannerAd?.adInteractionListener?.OnAdShow(this.bannerAd);
            }

            public void onAdClicked(AndroidJavaObject adInfo) {

                    Debug.Log("dll--onAdClicked " + this.bannerAd?.PlacementId);
                    this.bannerAd?.adInteractionListener?.OnAdClick(this.bannerAd);

            }

            public void onAdClosed(AndroidJavaObject adInfo) {

                  Debug.Log("dll--onAdClosed " + this.bannerAd?.PlacementId);
                  this.bannerAd?.adInteractionListener?.OnAdClose(this.bannerAd);

            }

            public void onAdAutoRefreshed(AndroidJavaObject adInfo) {

                  Debug.Log("dll--onAdAutoRefreshed " + this.bannerAd?.PlacementId);
                  this.bannerAd?.adInteractionListener?.OnAdAutoRefreshed(this.bannerAd);

            }

            public void onAdAutoRefreshFail(AndroidJavaObject windMillError, string placementId) {
                  Debug.Log("dll--onAdAutoRefreshFail " + this.bannerAd?.PlacementId);
                  string msg = windMillError.Call<string>("toString");
                  int code = windMillError.Call<int>("getErrorCode");
                  Error error = new Error(code, msg);

                  this.bannerAd?.adInteractionListener?.OnAdAutoRefreshFail(this.bannerAd,error);

            }


         
        }


#pragma warning restore SA1300
#pragma warning restore IDE1006


    }
#endif

}