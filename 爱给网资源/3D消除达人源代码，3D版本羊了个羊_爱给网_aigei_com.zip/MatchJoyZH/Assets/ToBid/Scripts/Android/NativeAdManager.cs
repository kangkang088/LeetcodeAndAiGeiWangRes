﻿namespace WindMill.Advertisements
{

#if !UNITY_EDITOR && UNITY_ANDROID
    using System;
    using System.Collections.Generic;
    using System.Runtime.InteropServices;
    using UnityEngine;

    public class NativeAdManager : INativeAdClient
    {
        AndroidJavaObject mNativeAdRequest;
        private readonly AndroidJavaClass unityPlayer = new AndroidJavaClass("com.unity3d.player.UnityPlayer");

        AndroidJavaObject mActivity;
        AndroidJavaObject mNativeAdSupport;

        public string PlacementId
        {
            get
            {
                return this.request.PlacementId;
            }
        }

        private INativeAdDislikeListener dislikeListener = null;
        private INativeAdInteractionListener adInteractionListener = null;
        private INativeAdLoadListener loadListener = null;
        private Request request = null;

         private AdInfo adInfo;


        public AdInfo GetAdInfo() {
           return adInfo;
        }
        public void updateAdInfo(AndroidJavaObject obj) {
            string adInfoJson = Utils.ToStringAndroidObject(obj);

            Debug.Log("dll--updateAdInfo " + adInfoJson + " | "+ PlacementId);

            adInfo = AdInfo.CreateAdInfoFromJson(adInfoJson);
        }



        public List<AdInfo> GetCacheAdInfoList(){

            Debug.Log("dll--getCacheAdInfoList " );
            AndroidJavaObject nativeAdSupport = getNativeAdSupport(); 
            if(nativeAdSupport != null){
                AndroidJavaObject cacheAdInfoList = nativeAdSupport.Call<AndroidJavaObject>("getCacheAdInfoList");

                if(cacheAdInfoList != null){
                    AndroidJavaObject[] objList = cacheAdInfoList.Call<AndroidJavaObject[]>("toArray");

                    if(objList != null){
                        List<AdInfo> result = new List<AdInfo>();

                        foreach(AndroidJavaObject obj in objList){
                        
                            string cacheAdInfoListJson = Utils.ToStringAndroidObject(obj);
                            Debug.Log("dll--getCacheAdInfoList " + cacheAdInfoListJson);
                            result.Add(AdInfo.CreateAdInfoFromJson(cacheAdInfoListJson));
                        }
                        return result;
                    }
                }
            }
            return null;
        }

        public void Dispose()
        {
            AndroidJavaObject nativeAdSupport = getNativeAdSupport();
            nativeAdSupport.Call("destroyAd");
        }

        public NativeAdManager(Request request)
        {
            this.request = request;
        }

        public void SetDislikeListener(INativeAdDislikeListener listener)
        {
            this.dislikeListener = listener;
        }

        public void SetInteractionListener(INativeAdInteractionListener listener)
        {
            this.adInteractionListener = listener;
        }

        public void SetLoadListener(INativeAdLoadListener listener)
        {
            this.loadListener = listener;
        }

         /// <summary>
        /// Load reward video Ad.
        /// </summary>
        public void LoadAd(int width, int height)
        {
            if (mNativeAdRequest == null)
            {
                mNativeAdRequest = new AndroidJavaObject("com.windmill.sdk.natives.WMNativeAdRequest", this.request.PlacementId, this.request.UserId, 1, this.request.options);
            }
            if (mActivity == null)
            {
                mActivity = unityPlayer.GetStatic<AndroidJavaObject>("currentActivity");
            }
            

            NativeAdLoadListener androidListener = new NativeAdLoadListener(this);

            AndroidJavaObject nativeAdSupport = getNativeAdSupport();


            nativeAdSupport.Call<bool>("loadAd",mActivity, width,height, mNativeAdRequest, androidListener);
        }

        private AndroidJavaObject getNativeAdSupport()
        {
            if (mNativeAdSupport != null)
            {
                return mNativeAdSupport;
            }
            if (mActivity == null)
            {
                var unityPlayer = new AndroidJavaClass("com.unity3d.player.UnityPlayer");
                mActivity = unityPlayer.GetStatic<AndroidJavaObject>("currentActivity");
            }
            var jc = new AndroidJavaClass("com.windmill.sdk.NativeAdUnitySupport");
            mNativeAdSupport = jc.CallStatic<AndroidJavaObject>("getInstance");
            return mNativeAdSupport;
        }


        public AppInfo GetAppInfo(){

                AndroidJavaObject nativeAdSupport = getNativeAdSupport();

                if(nativeAdSupport != null){
                   AndroidJavaObject map = nativeAdSupport.Call<AndroidJavaObject>("getAppInfo");
                   Dictionary<string,object> dic = Utils.GetDictFromNativeMap(map);
                   return AppInfo.CreateAppInfoFromDic(dic);

                }
                return null;
 
        }

         public void ShowAd(NativeAdView nativeAdView)
        {

            AndroidJavaObject nativeAdSupport = getNativeAdSupport();

            string json =  nativeAdView.toJSON();
            Debug.Log("showAd nativeAdView toJSON = " + json);

            NativeAdNativeADEventListener adNativeADEventListener = new NativeAdNativeADEventListener(this);

            DislikeInteractionCallback dislikeInteractionCallback = new DislikeInteractionCallback(this);
            NativeAdNativeADMediaListener adNativeADMediaListener = new NativeAdNativeADMediaListener(this);


            nativeAdSupport.Call("showAd", mActivity, json, adNativeADEventListener, dislikeInteractionCallback,adNativeADMediaListener);
        }


        /// <summary>
        /// Show the reward video Ad.
        /// </summary>
        public void ShowAd(float x, float y)
        {

            AndroidJavaObject nativeAdSupport = getNativeAdSupport();


            NativeAdNativeADEventListener adNativeADEventListener = new NativeAdNativeADEventListener(this);

            DislikeInteractionCallback dislikeInteractionCallback = new DislikeInteractionCallback(this);
            NativeAdNativeADMediaListener adNativeADMediaListener = new NativeAdNativeADMediaListener(this);


            nativeAdSupport.Call("showAd", mActivity, x, y, adNativeADEventListener, dislikeInteractionCallback,adNativeADMediaListener);

        }


        private sealed class NativeAdLoadListener : AndroidJavaProxy
        {
            private readonly NativeAdManager mNativeAdClient;
            public NativeAdLoadListener(NativeAdManager nativeAdClient) : base("com.windmill.sdk.natives.WMNativeAd$NativeAdLoadListener")
            {
                this.mNativeAdClient = nativeAdClient;
            }

            public void onError(AndroidJavaObject windAdError, string placementId)
            {
                string msg = windAdError.Call<string>("toString");
                int code = windAdError.Call<int>("getErrorCode");
                Debug.Log("dll--onError " + msg + ": code" + code + " :" + placementId);
                Error error = new Error(code, msg);
                this.mNativeAdClient?.loadListener?.OnAdError(mNativeAdClient, error);
            }

            public void onFeedAdLoad(string placementId)
            {
                Debug.Log("dll--onFeedAdLoad " + placementId);
                this.mNativeAdClient?.loadListener?.OnAdLoad(mNativeAdClient);
            }

        }

        private sealed class NativeAdNativeADEventListener : AndroidJavaProxy
        {
            private readonly NativeAdManager mNativeAdClient;
            private readonly string placementId;
            public NativeAdNativeADEventListener(NativeAdManager nativeAdClient) : base("com.windmill.sdk.natives.WMNativeAdData$NativeAdInteractionListener")
            {
                this.mNativeAdClient = nativeAdClient;
                placementId = mNativeAdClient?.request?.PlacementId;

            }


            public void onADExposed(AndroidJavaObject adInfo)
            {
                Debug.Log("dll--onADExposed " + placementId);

                this.mNativeAdClient?.updateAdInfo(adInfo);

                this.mNativeAdClient?.adInteractionListener?.OnAdShow(mNativeAdClient);

            }
            public void onADRenderSuccess(AndroidJavaObject adInfo, AndroidJavaObject view, float width, float height){

                   Debug.Log("dll--onADRenderSuccess " + placementId);
            }

            public void onADClicked(AndroidJavaObject adInfo)
            {
                Debug.Log("dll--onADClicked " + placementId);

                this.mNativeAdClient?.adInteractionListener?.OnAdClick(mNativeAdClient);

            }

            public void onADError(AndroidJavaObject adInfo,AndroidJavaObject error)
            {
                Debug.Log("dll--onADError " + error + " | "+placementId);

            }
        
        }



        private sealed class NativeAdNativeADMediaListener : AndroidJavaProxy
        {
            private readonly NativeAdManager mNativeAdClient;
            private readonly string placementId;

            public NativeAdNativeADMediaListener(NativeAdManager nativeAdClient) : base("com.windmill.sdk.natives.WMNativeAdData$NativeADMediaListener")
            {
                this.mNativeAdClient = nativeAdClient;
                placementId = mNativeAdClient?.request?.PlacementId;
            }

            public void onVideoLoad()
            {
                Debug.Log("dll--onVideoLoad ");

                this.mNativeAdClient.adInteractionListener?.OnAdVideoPlayerStatusChanged(mNativeAdClient, MediaPlayerStatus.Loading);
            }

            public void onVideoError(AndroidJavaObject windAdError)
            {
                Debug.Log("dll--onVideoError " + windAdError);

                this.mNativeAdClient.adInteractionListener?.OnAdVideoPlayerStatusChanged(mNativeAdClient, MediaPlayerStatus.Error);
            }

            public void onVideoStart()
            {
                Debug.Log("dll--onVideoStart ");

                this.mNativeAdClient.adInteractionListener?.OnAdVideoPlayerStatusChanged(mNativeAdClient, MediaPlayerStatus.Started);
            }

            public void onVideoPause()
            {
                Debug.Log("dll--onVideoPause ");

                this.mNativeAdClient.adInteractionListener?.OnAdVideoPlayerStatusChanged(mNativeAdClient, MediaPlayerStatus.Paused);
            }

            public void onVideoResume()
            {
                Debug.Log("dll--onVideoResume ");

                this.mNativeAdClient.adInteractionListener?.OnAdVideoPlayerStatusChanged(mNativeAdClient, MediaPlayerStatus.Started);
            }

            public void onVideoCompleted()
            {
                Debug.Log("dll--onVideoCompleted ");

                this.mNativeAdClient.adInteractionListener?.OnAdVideoPlayerStatusChanged(mNativeAdClient, MediaPlayerStatus.Stoped);
            }





        }


        private sealed class DislikeInteractionCallback : AndroidJavaProxy
        {
            private readonly NativeAdManager mNativeAdClient;
            public DislikeInteractionCallback(NativeAdManager nativeAdClient) : base("com.windmill.sdk.natives.WMNativeAdData$DislikeInteractionCallback")
            {
                this.mNativeAdClient = nativeAdClient;
            }

            public void onShow()
            {
                Debug.Log("dll--onShow ");

                this.mNativeAdClient?.dislikeListener?.OnShow(mNativeAdClient);
            }

            public void onSelected(int position, string value, bool enforce)
            {

                Debug.Log("dll--onSelected " + value);
                this.mNativeAdClient?.dislikeListener?.OnSelected(mNativeAdClient,position, value, enforce);
            }
            public void onCancel()
            {
                Debug.Log("dll--onCancel ");
                this.mNativeAdClient?.dislikeListener?.OnCancel(mNativeAdClient);
            }

        }



    }
#endif

}