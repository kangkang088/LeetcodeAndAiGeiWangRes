package com.windmill.sdk;

import com.windmill.sdk.models.AdInfo;

import org.json.JSONObject;

import java.util.HashMap;
import java.util.Map;

public class AdInfoUtil {
    
    public static String getAdInfoJson(AdInfo adInfo) {
        if (adInfo != null){
            Map<String, Object> options = adInfo.getOptions();
            JSONObject jsonObject = new JSONObject(options);
            return jsonObject.toString();
        }
        return null;
    }
}
