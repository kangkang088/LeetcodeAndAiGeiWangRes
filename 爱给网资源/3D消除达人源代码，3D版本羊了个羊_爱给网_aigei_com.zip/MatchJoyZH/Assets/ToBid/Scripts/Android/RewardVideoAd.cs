﻿namespace WindMill.Advertisements
{
#if !UNITY_EDITOR&& UNITY_ANDROID

    using System;
    using System.Collections.Generic;
    using System.Runtime.InteropServices;
    using UnityEngine;

    public sealed class RewardVideoAd : IDisposable
    {
        private AndroidJavaObject windRewardedVideoAd;

        private readonly Request request;

        private readonly AndroidJavaClass unityPlayer = new AndroidJavaClass("com.unity3d.player.UnityPlayer");

        private IRewardVideoAdListener adInteractionListener;


        private AdInfo adInfo;

        public AdInfo GetAdInfo() {
            return adInfo;
        }
        public void updateAdInfo(AndroidJavaObject obj) {


            string adInfoJson = Utils.ToStringAndroidObject(obj);
            Debug.Log("dll--updateAdInfo " + adInfoJson + " | "+ PlacementId);
            this.adInfo = AdInfo.CreateAdInfoFromJson(adInfoJson);
        }

        public List<AdInfo> GetCacheAdInfoList(){

            Debug.Log("dll--GetCacheAdInfoList " );
            if(windRewardedVideoAd != null){
                AndroidJavaObject cacheAdInfoList = windRewardedVideoAd.Call<AndroidJavaObject>("checkValidAdCaches");

                if(cacheAdInfoList != null){
                    AndroidJavaObject[] objList = cacheAdInfoList.Call<AndroidJavaObject[]>("toArray");

                    if(objList != null){
                        List<AdInfo> result = new List<AdInfo>();

                        foreach(AndroidJavaObject obj in objList){
                        
                            string cacheAdInfoListJson = Utils.ToStringAndroidObject(obj);
                            result.Add(AdInfo.CreateAdInfoFromJson(cacheAdInfoListJson));
                        }
                        return result;
                    }
                }
            }
            return null;
        }    

        public RewardVideoAd(Request request)
        {
            this.request = request;
        }

        public string PlacementId
        {
            get
            {
                return this.request?.PlacementId;
            }
        }

        public void Dispose()
        {
            if (this.windRewardedVideoAd != null)
            {
                // this.windRewardedVideoAd?.Call("setRewardedAdListener", null);
                this.windRewardedVideoAd?.Call("destroy");
            }
            this.windRewardedVideoAd = null;
        }

        /// <summary>
        /// Load reward video Ad.
        /// </summary>
        public void LoadAd()
        {
            var androidListener = new RewardAdInteractionListener(this);
            string extra = Json.Serialize(request.options);
            Debug.Log("req.options.toJson = " + extra);

            AndroidJavaObject activity = unityPlayer.GetStatic<AndroidJavaObject>("currentActivity");

            AndroidJavaObject rewardAdRequest = new AndroidJavaObject("com.windmill.sdk.reward.WMRewardAdRequest", this.request.PlacementId, this.request.UserId, this.request.options);
            if (this.windRewardedVideoAd == null)
            {
                windRewardedVideoAd = new AndroidJavaObject("com.windmill.sdk.reward.WMRewardAd", activity, rewardAdRequest);
            }
            windRewardedVideoAd.Call("setRewardedAdListener", androidListener);
            windRewardedVideoAd.Call<bool>("loadAd");

        }

        /// <summary>
        /// Sets the interaction listener for this Ad.
        /// </summary>
        public void SetRewardAdListener(IRewardVideoAdListener listener)
        {
            this.adInteractionListener = listener;
        }

        /// <summary>
        /// Show the reward video Ad.
        /// </summary>
        public void ShowAd()
        {
            AndroidJavaObject activity = unityPlayer.GetStatic<AndroidJavaObject>("currentActivity");

            this.windRewardedVideoAd?.Call<bool>("show", activity, null);
        }

        public bool Ready()
        {
            if (this.windRewardedVideoAd == null)
            {
                return false;
            }
            return this.windRewardedVideoAd.Call<bool>("isReady");
        }

#pragma warning disable SA1300
#pragma warning disable IDE1006

        private sealed class RewardAdInteractionListener : AndroidJavaProxy
        {

            private readonly RewardVideoAd rewardVideoAd;

            public RewardAdInteractionListener(RewardVideoAd rewardVideoAd) : base("com.windmill.sdk.reward.WMRewardAdListener")
            {
                this.rewardVideoAd = rewardVideoAd;
            }

            public void onVideoAdLoadError(AndroidJavaObject windMillError, string placementId)
            {
                string msg = windMillError.Call<string>("toString");
                int code = windMillError.Call<int>("getErrorCode");
                Debug.Log("dll--onVideoAdLoadError " + msg + ": code" + code + " :" + placementId);
                this.rewardVideoAd?.adInteractionListener?.OnAdError(this.rewardVideoAd, new Error(code, msg));
            }

            public void onVideoAdLoadSuccess(string placementId)
            {
                Debug.Log("dll--onVideoAdLoadSuccess " + placementId);
                this.rewardVideoAd?.adInteractionListener?.OnAdLoad(this.rewardVideoAd);
            }

            public void onVideoAdPlayStart(AndroidJavaObject adInfo)
            {
                Debug.Log("dll--onVideoAdPlayStart " + this.rewardVideoAd.PlacementId);

                this.rewardVideoAd?.updateAdInfo(adInfo);

                this.rewardVideoAd?.adInteractionListener?.OnAdShow(this.rewardVideoAd);

            }

            public void onVideoAdPlayEnd(AndroidJavaObject adInfo)
            {
                Debug.Log("dll--onVideoAdPlayEnd " + this.rewardVideoAd.PlacementId);
                this.rewardVideoAd?.adInteractionListener?.OnVideoEnd(this.rewardVideoAd);

            }

            public void onVideoAdClicked(AndroidJavaObject adInfo)
            {
                Debug.Log("dll--onVideoAdClicked " + this.rewardVideoAd.PlacementId);
                this.rewardVideoAd?.adInteractionListener?.OnAdClick(this.rewardVideoAd);

            }

            public void onVideoRewarded(AndroidJavaObject adInfo,AndroidJavaObject windRewardInfo)
            {
                bool isReward = windRewardInfo.Call<bool>("isReward");
                string trans_id = windRewardInfo.Call<string>("getTrans_id");
                string user_id = windRewardInfo.Call<string>("getUser_id");
                AndroidJavaObject customData =  windRewardInfo.Call<AndroidJavaObject>("getCustomData");

                Debug.Log("dll--onVideoRewarded " + isReward + "｜" + this.rewardVideoAd.PlacementId);

                RewardInfo reward = new RewardInfo();
                reward.IsReward = isReward;
                reward.TransId = trans_id;
                reward.CustomData = Utils.GetDictFromNativeMap(customData);

                this.rewardVideoAd?.adInteractionListener?.OnAdReward(this.rewardVideoAd, reward);
            }

            public void onVideoAdClosed(AndroidJavaObject adInfo)
            {
                Debug.Log("dll--onVideoAdClosed " + this.rewardVideoAd.PlacementId);
       
                this.rewardVideoAd?.adInteractionListener?.OnAdClose(this.rewardVideoAd);
            }

            void onVideoAdPlayError(AndroidJavaObject windMillError, string placementId)
            {
                string msg = windMillError.Call<string>("toString");
                int code = windMillError.Call<int>("getErrorCode");
                Debug.Log("dll--onVideoAdPlayError " + msg + ": code" + code + " :" + placementId);
                this.rewardVideoAd?.adInteractionListener?.OnVideoError(this.rewardVideoAd, new Error(code, msg));
            }

        }

#pragma warning restore SA1300
#pragma warning restore IDE1006


    }
#endif

}