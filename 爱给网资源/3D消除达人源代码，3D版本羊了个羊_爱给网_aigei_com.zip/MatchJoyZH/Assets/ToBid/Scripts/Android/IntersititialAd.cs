﻿namespace WindMill.Advertisements
{
#if !UNITY_EDITOR && UNITY_ANDROID

    using System;
    using System.Collections.Generic;
    using System.Runtime.InteropServices;
    using UnityEngine;

    public sealed class IntersititialAd : IDisposable
    {
        private AndroidJavaObject interstitialVideoAd;

        private readonly Request request;

        private readonly AndroidJavaClass unityPlayer = new AndroidJavaClass("com.unity3d.player.UnityPlayer");

        private IIntersititialAdListener adInteractionListener;

        public IntersititialAd(Request request)
        {
            this.request = request;
        }

        public string PlacementId
        {
            get
            {
                return this.request?.PlacementId;
            }
        }

        private AdInfo adInfo;


        public AdInfo GetAdInfo() {
            return adInfo;
        }
        public void updateAdInfo(AndroidJavaObject obj) {
            string adInfoJson = Utils.ToStringAndroidObject(obj);
            Debug.Log("dll--updateAdInfo " + adInfoJson + " | "+ PlacementId);
            adInfo = AdInfo.CreateAdInfoFromJson(adInfoJson);
        }

        public List<AdInfo> GetCacheAdInfoList(){

            Debug.Log("dll--GetCacheAdInfoList " );
            if(interstitialVideoAd != null){
                AndroidJavaObject cacheAdInfoList = interstitialVideoAd.Call<AndroidJavaObject>("checkValidAdCaches");

                if(cacheAdInfoList != null){
                    AndroidJavaObject[] objList = cacheAdInfoList.Call<AndroidJavaObject[]>("toArray");

                    if(objList != null){
                        List<AdInfo> result = new List<AdInfo>();

                        foreach(AndroidJavaObject obj in objList){
                        
                            string cacheAdInfoListJson = Utils.ToStringAndroidObject(obj);
                            result.Add(AdInfo.CreateAdInfoFromJson(cacheAdInfoListJson));
                        }
                        return result;
                    }
                }
            }
            return null;
        }         

        public void Dispose()
        {
            // this.interstitialVideoAd?.Call("setInterstitialAdListener", null);
            this.interstitialVideoAd?.Call("destroy");
            this.interstitialVideoAd = null;

        }

        /// <summary>
        /// Load reward video Ad.
        /// </summary>
        public void LoadAd()
        {
            var androidListener = new InterstitialAdInteractionListener(this);

            AndroidJavaObject activity = unityPlayer.GetStatic<AndroidJavaObject>("currentActivity");

            AndroidJavaObject interstitialAdRequest = new AndroidJavaObject("com.windmill.sdk.interstitial.WMInterstitialAdRequest", this.request.PlacementId, this.request.UserId, this.request.options);
            if (this.interstitialVideoAd == null)
            {
                interstitialVideoAd = new AndroidJavaObject("com.windmill.sdk.interstitial.WMInterstitialAd", activity, interstitialAdRequest);
            }
            interstitialVideoAd.Call("setInterstitialAdListener", androidListener);
            interstitialVideoAd.Call<bool>("loadAd");
        }

        /// <summary>
        /// Sets the interaction listener for this Ad.
        /// </summary>
        public void SetIntersititialAdListener(IIntersititialAdListener listener)
        {
            this.adInteractionListener = listener;
        }

        public bool Ready()
        {
            if (this.interstitialVideoAd == null)
            {
                return false;
            }
            return this.interstitialVideoAd.Call<bool>("isReady");
        }


        /// <summary>
        /// Show the reward video Ad.
        /// </summary>
        public void ShowAd()
        {
            AndroidJavaObject activity = unityPlayer.GetStatic<AndroidJavaObject>("currentActivity");

            this.interstitialVideoAd?.Call<bool>("show", activity, null);
        }

#pragma warning disable SA1300
#pragma warning disable IDE1006

        private sealed class InterstitialAdInteractionListener : AndroidJavaProxy
        {

            private readonly IntersititialAd intersitialAd;

            public InterstitialAdInteractionListener(IntersititialAd intersitialAd) : base("com.windmill.sdk.interstitial.WMInterstitialAdListener")
            {
                this.intersitialAd = intersitialAd;
            }

            public void onInterstitialAdLoadError(AndroidJavaObject windMillError, string placementId)
            {
                string msg = windMillError.Call<string>("toString");
                int code = windMillError.Call<int>("getErrorCode");
                Debug.Log("dll--onInterstitialAdLoadError " + msg + ": code" + code + " :" + placementId);
                Error error = new Error(code, msg);
                this.intersitialAd?.adInteractionListener.OnAdError(this.intersitialAd, error);
            }

            public void onInterstitialAdLoadSuccess(string placementId)
            {
                Debug.Log("dll--onInterstitialAdLoadSuccess " + placementId);
                this.intersitialAd?.adInteractionListener.OnAdLoad(this.intersitialAd);
            }


            public void onInterstitialAdPlayStart(AndroidJavaObject adInfo)
            {
                
                Debug.Log("dll--onInterstitialAdPlayStart " + this.intersitialAd?.PlacementId);
                
                this.intersitialAd?.updateAdInfo(adInfo);

                this.intersitialAd?.adInteractionListener?.OnAdShow(this.intersitialAd);
            }

            public void onInterstitialAdPlayEnd(AndroidJavaObject adInfo)
            {
                Debug.Log("dll--onInterstitialAdPlayEnd " + this.intersitialAd?.PlacementId);
                this.intersitialAd?.adInteractionListener?.OnVideoEnd(this.intersitialAd);
            }

            public void onInterstitialAdClicked(AndroidJavaObject adInfo)
            {
                Debug.Log("dll--onInterstitialAdClicked " + this.intersitialAd?.PlacementId);
                this.intersitialAd?.adInteractionListener?.OnAdClick(this.intersitialAd);
            }

            public void onInterstitialAdClosed(AndroidJavaObject adInfo)
            {
                Debug.Log("dll--onInterstitialAdClosed " + this.intersitialAd?.PlacementId);
                this.intersitialAd?.adInteractionListener?.OnAdClose(this.intersitialAd);
            }

            public void onInterstitialAdPlayError(AndroidJavaObject windMillError, string placementId)
            {
                string msg = windMillError.Call<string>("toString");
                int code = windMillError.Call<int>("getErrorCode");
                Debug.Log("dll--onInterstitialAdPlayError " + msg + ": code" + code + " :" + placementId);
                this.intersitialAd?.adInteractionListener?.OnVideoError(this.intersitialAd, new Error(code, msg));
            }
        }


#pragma warning restore SA1300
#pragma warning restore IDE1006


    }
#endif

}