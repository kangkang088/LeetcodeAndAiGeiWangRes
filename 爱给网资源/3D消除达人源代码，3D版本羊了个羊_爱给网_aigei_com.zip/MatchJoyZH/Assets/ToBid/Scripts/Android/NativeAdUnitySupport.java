package com.windmill.sdk;

import android.app.Activity;
import android.graphics.Color;
import android.os.Handler;
import android.os.Looper;
import android.text.TextUtils;
import android.util.Log;
import android.view.View;
import android.view.ViewGroup;
import android.widget.FrameLayout;

import com.windmill.sdk.models.AdInfo;
import com.windmill.sdk.natives.WMNativeAdData;
import com.windmill.sdk.natives.WMNativeAdContainer;
import com.windmill.sdk.natives.WMNativeAd;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.windmill.sdk.natives.WMNativeAdRender;
import com.windmill.sdk.natives.WMNativeAdRequest;

import org.json.JSONException;
import org.json.JSONObject;

public class NativeAdUnitySupport {

    private static final String TAG = NativeAdUnitySupport.class.getSimpleName();
    private static volatile NativeAdUnitySupport sManager;

    private Activity mContext;
    private Handler mHandler;
    private WMNativeAdContainer wmNativeContainer;
    private WMNativeAd wmNativeAd;
    private static NativeAdUnitySupport mInstance = new NativeAdUnitySupport();

    public NativeAdUnitySupport() {
        if (mHandler == null) {
            mHandler = new Handler(Looper.getMainLooper());
        }
    }

    public static NativeAdUnitySupport getInstance() {
        return mInstance;
    }




    public ViewGroup getRootLayout(Activity context) {
        if (context == null) {
            return null;
        }
        ViewGroup rootGroup = context.findViewById(android.R.id.content);
        return rootGroup;
    }

    public void addAdView(Activity context, View adView, ViewGroup.LayoutParams layoutParams) {
        if (context == null || adView == null || layoutParams == null) {
            return;
        }
        ViewGroup group = getRootLayout(context);
        if (group == null) {
            return;
        }
        group.addView(adView, layoutParams);
    }

    public void removeAdView(Activity context, View adView) {
        if (context == null || adView == null) {
            return;
        }
        ViewGroup group = getRootLayout(context);
        if (group == null) {
            return;
        }
        group.removeView(adView);
    }

    public List<AdInfo> getCacheAdInfoList(){
        if (wmNativeAd == null){
            return null;
        }
        return wmNativeAd.checkValidAdCaches();
    }




    public boolean loadAd(Activity context,int width,int height,WMNativeAdRequest adRequest,WMNativeAd.NativeAdLoadListener nativeAdLoadListener){

        if (wmNativeAd == null){

            ResourceUtil.InitUtil(context);
            Map<String, Object> options = adRequest.getOptions();
            options.put(WMConstants.AD_WIDTH,ResourceUtil.Instace().px2dip(width));//针对于模版广告有效、单位dp
            options.put(WMConstants.AD_HEIGHT, ResourceUtil.Instace().px2dip(height));//自适应高度
            wmNativeAd = new WMNativeAd(context,adRequest);
        }

        return wmNativeAd.loadAd(nativeAdLoadListener);
    }

    public void destroyAd() {

        mHandler.post(new Runnable() {
            @Override
            public void run() {

                removeAdView(mContext, wmNativeContainer);

                if (wmNativeAd == null) {
                    return;
                }
                List<WMNativeAdData> nativeADDataList = wmNativeAd.getNativeADDataList();


                if (nativeADDataList == null || nativeADDataList.size() == 0) {
                    return;
                }

                for (WMNativeAdData nativeADData : nativeADDataList) {
                    nativeADData.destroy();

                }
                wmNativeAd.destroy();
                wmNativeAd = null;
            }
        });
    }


    public String getAppInfo(){


        WMNativeAdData wmNativeAdData = getNativeADData(wmNativeAd,0);

        if(wmNativeAdData != null){
            WMNativeAdData.AppInfo appInfo = wmNativeAdData.getAppInfo();

            if(appInfo != null){
                    HashMap map = new HashMap<>();

                    map.put("appName",appInfo.getAppName());
                    map.put("developerName",appInfo.getDeveloperName());
                    map.put("appVersion",appInfo.getAppVersion());
                    map.put("privacyUrl",appInfo.getPrivacyUrl());
                    map.put("permissionInfoUrl",appInfo.getPermissionInfoUrl());
                    map.put("permissionInfo",appInfo.getPermissionInfo());
                    map.put("functionDescUrl",appInfo.getFunctionDescUrl());

                    JSONObject jsonObject = new JSONObject(map);
                    return jsonObject.toString();
             }
        }
        return null;
    }

    public WMNativeAdData getNativeADData(final WMNativeAd nativeAd,int index) {


        List<WMNativeAdData> nativeADDataList = nativeAd.getNativeADDataList();
        if (nativeADDataList != null && nativeADDataList.size() > 0) {

            return nativeADDataList.get(index);
        }

        return null;
    }



        //相关调用注意放在主线程
    public void showAd(final Activity activity,  String json,
                       final WMNativeAdData.NativeAdInteractionListener nativeADEventListener,
                       final WMNativeAdData.DislikeInteractionCallback dislikeInteractionCallback,
                       final WMNativeAdData.NativeADMediaListener nativeADMediaListener) {

        Log.d(TAG, "showAd native custom view json: " + json );

        final WMNativeAdData nativeADData = getNativeADData(wmNativeAd,0);
        if (activity == null || nativeADData == null) {
            return;
        }
        JSONObject rootView = null;
        JSONObject customViewConfig = null;
        try {
            customViewConfig = new JSONObject(json);
             if(customViewConfig != null){
                 rootView = customViewConfig.getJSONObject("rootView");
             }

        } catch (JSONException e) {
            e.printStackTrace();
        }

        if(rootView == null){
            return;
        }

        mContext = activity;

        ViewConfigItem rootViewItem = new ViewConfigItem(rootView);
        JSONObject finalCustomViewConfig = customViewConfig;
        mHandler.post(new Runnable() {
            @Override
            public void run() {

                if(wmNativeContainer != null){
                    wmNativeContainer.removeAllViews();
                    removeAdView(activity, wmNativeContainer);
                }

                wmNativeContainer = new WMNativeAdContainer(activity);

                //设置dislike弹窗
                nativeADData.setDislikeInteractionCallback(activity, new WMNativeAdData.DislikeInteractionCallback() {
                    @Override
                    public void onShow() {
                        Log.d(TAG, "onShow: ");
                        if (dislikeInteractionCallback != null){
                            dislikeInteractionCallback.onShow();
                        }
                    }

                    @Override
                    public void onSelected(int position, String value, boolean enforce) {
                        Log.d(TAG, "onSelected: ");

                        removeAdView(activity, wmNativeContainer);
                        if (dislikeInteractionCallback != null){
                            dislikeInteractionCallback.onSelected(position,value,enforce);
                        }
                    }

                    @Override
                    public void onCancel() {
                        Log.d(TAG, "onCancel: ");
                        if (dislikeInteractionCallback != null){
                            dislikeInteractionCallback.onCancel();
                        }
                    }
                });

                if(!TextUtils.isEmpty(rootViewItem.getBackgroundColor())){
                    wmNativeContainer.setBackgroundColor(Color.parseColor(rootViewItem.getBackgroundColor()));
                }else {
                    wmNativeContainer.setBackgroundColor(Color.WHITE);
                }

                if (nativeADData.isExpressAd()){
                    nativeADData.render();
                    View expressAdView = nativeADData.getExpressAdView();
                    wmNativeContainer.addView(expressAdView,new ViewGroup.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT,ViewGroup.LayoutParams.WRAP_CONTENT));
                }else {
                    WMNativeAdRender adRender;
                    if (!finalCustomViewConfig.has("mainAdView")){
                        adRender = new NativeAdRender(nativeADEventListener,nativeADMediaListener);
                    }else{
                        adRender = new NativeAdRenderCustomView(finalCustomViewConfig,nativeADEventListener,nativeADMediaListener);
                    }

                    nativeADData.connectAdToView(activity, wmNativeContainer, adRender);
                }

                nativeADData.setInteractionListener(new WMNativeAdData.NativeAdInteractionListener() {
                    @Override
                    public void onADExposed(AdInfo adInfo) {
                        Log.d(TAG, "onADExposed: ");
                        if (nativeADEventListener != null){
                            nativeADEventListener.onADExposed(adInfo);
                        }
                    }

                    @Override
                    public void onADClicked(AdInfo adInfo) {
                        Log.d(TAG, "onADClicked: ");
                        if (nativeADEventListener != null){
                            nativeADEventListener.onADClicked(adInfo);
                        }
                    }

                    @Override
                    public void onADError(AdInfo adInfo,WindMillError error) {
                        Log.d(TAG, "onADError error code :" + error.toString());
                        if (nativeADEventListener != null){
                            nativeADEventListener.onADError(adInfo,error);
                        }
                    }

                    @Override
                    public void onADRenderSuccess(AdInfo adInfo,View view, float width, float height) {
                        Log.d(TAG, "----------onRenderSuccess----------:" + width + ":" + height);
                        if (nativeADEventListener != null){
                            nativeADEventListener.onADRenderSuccess(adInfo,view,width,height);
                        }
                    }
                });


                FrameLayout.LayoutParams layoutParams = new FrameLayout.LayoutParams(rootViewItem.getWidth(), rootViewItem.getHeight());
                layoutParams.setMargins( rootViewItem.getX(),  rootViewItem.getY(),0, 0);

                addAdView(activity, wmNativeContainer, layoutParams);
            }
        });



    }
    //相关调用注意放在主线程
    public void showAd(final Activity activity,  final float x, final float y,
                       final WMNativeAdData.NativeAdInteractionListener nativeADEventListener,
                       final WMNativeAdData.DislikeInteractionCallback dislikeInteractionCallback,
                       final WMNativeAdData.NativeADMediaListener nativeADMediaListener) {


        final WMNativeAdData nativeADData = getNativeADData(wmNativeAd,0);
        if (activity == null || nativeADData == null) {
            return;
        }


        mContext = activity;

        mHandler.post(new Runnable() {
            @Override
            public void run() {

                if(wmNativeContainer != null){
                    wmNativeContainer.removeAllViews();
                    removeAdView(activity, wmNativeContainer);
                }

                wmNativeContainer = new WMNativeAdContainer(activity);


                //设置dislike弹窗
                nativeADData.setDislikeInteractionCallback(activity, new WMNativeAdData.DislikeInteractionCallback() {
                    @Override
                    public void onShow() {
                        Log.d(TAG, "onShow: ");
                        if (dislikeInteractionCallback != null){
                            dislikeInteractionCallback.onShow();
                        }
                    }

                    @Override
                    public void onSelected(int position, String value, boolean enforce) {
                        Log.d(TAG, "onSelected: ");

                        removeAdView(activity, wmNativeContainer);
                        if (dislikeInteractionCallback != null){
                            dislikeInteractionCallback.onSelected(position,value,enforce);
                        }
                    }

                    @Override
                    public void onCancel() {
                        Log.d(TAG, "onCancel: ");
                        if (dislikeInteractionCallback != null){
                            dislikeInteractionCallback.onCancel();
                        }
                    }
                });

                
                if (nativeADData.isExpressAd()){
                    nativeADData.render();
                    View expressAdView = nativeADData.getExpressAdView();
                    wmNativeContainer.setBackgroundColor(Color.WHITE);
                    wmNativeContainer.addView(expressAdView,new ViewGroup.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT,ViewGroup.LayoutParams.WRAP_CONTENT));

                }else {
                    NativeAdRender adRender = new NativeAdRender(nativeADEventListener,nativeADMediaListener);
                    nativeADData.connectAdToView(activity, wmNativeContainer, adRender);
                }

                nativeADData.setInteractionListener(new WMNativeAdData.NativeAdInteractionListener() {
                    @Override
                    public void onADExposed(AdInfo adInfo) {
                        Log.d(TAG, "onADExposed: ");
                        if (nativeADEventListener != null){
                            nativeADEventListener.onADExposed(adInfo);
                        }
                    }

                    @Override
                    public void onADClicked(AdInfo adInfo) {
                        Log.d(TAG, "onADClicked: ");
                        if (nativeADEventListener != null){
                            nativeADEventListener.onADClicked(adInfo);
                        }
                    }

                    @Override
                    public void onADError(AdInfo adInfo,WindMillError error) {
                        Log.d(TAG, "onADError error code :" + error.toString());
                        if (nativeADEventListener != null){
                            nativeADEventListener.onADError(adInfo,error);
                        }
                    }

                    @Override
                    public void onADRenderSuccess(AdInfo adInfo,View view, float width, float height) {
                        Log.d(TAG, "----------onRenderSuccess----------:" + width + ":" + height);
                        if (nativeADEventListener != null){
                            nativeADEventListener.onADRenderSuccess(adInfo,view,width,height);
                        }
                    }
                });


                FrameLayout.LayoutParams layoutParams = new FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
                layoutParams.setMargins((int) x, (int) y, (int) x, 0);

                addAdView(activity, wmNativeContainer, layoutParams);
            }
        });

    }



}
