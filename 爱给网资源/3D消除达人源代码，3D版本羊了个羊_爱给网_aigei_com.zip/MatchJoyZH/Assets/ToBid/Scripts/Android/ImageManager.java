package com.windmill.sdk;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.Environment;
import android.os.Handler;
import android.text.TextUtils;
import android.util.LruCache;
import android.widget.ImageView;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.security.MessageDigest;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;


public class ImageManager {

    /**
     * 获取对象的单例模式
     */
    private static ImageManager instance;
    private Context mContext;
    /**
     * 构建出线程池，4条线程
     */
    private ExecutorService executorService = Executors.newFixedThreadPool(4);
    /**
     * 内存储存图片的集合 使用lrucache缓存图片,这里不能申明在方法里，不然会被覆盖掉 4兆的大小作为缓存 SoftReference
     * 为软引用、内存不足时，系统自动回收。
     */
    private LruCache<String, Bitmap> imageCache = new LruCache<String, Bitmap>(1024 * 1024 * 4);
    private Handler handler = new Handler();

    public ImageManager(Context context) {
        mContext = context.getApplicationContext();
    }

    private static ImageManager getInstance(Context context) {
        if (instance == null) {
            synchronized (ImageManager.class) {
                if (instance == null) {
                    instance = new ImageManager(context);
                }
            }
        }
        return instance;
    }

    /***
     * 初始化对象
     *
     * @param context
     * @return
     */
    public static ImageManager with(Context context) {
        ImageManager imageManager = getInstance(context);
        return imageManager;
    }

    /***
     * 加载图片的url地址，返回RequestCreator对象
     *
     * @param url
     * @return
     */
    public RequestCreatorRunnable load(String url) {
        return new RequestCreatorRunnable(url);
    }

    /***
     * 读取缓存路径目录
     *
     * @return
     */
    private File getCacheDir() {
        // 获取保存的文件夹路径
        File file;
        if (Environment.getExternalStorageState() == Environment.MEDIA_MOUNTED) {
            // 有SD卡就保存到SD卡
            file = mContext.getExternalCacheDir();
        } else {
            // 没有就保存到内部存储
            file = mContext.getCacheDir();
        }
        return file;
    }

    /**
     * 创建者
     */
    public class RequestCreatorRunnable implements Runnable {

        String url;
        int holderResId;
        int errorResId;
        ImageView imageView;

        // 初始化图片的url地址
        public RequestCreatorRunnable(String url) {
            this.url = url;
        }

        /***
         * 设置默认图片，占位图片
         *
         * @param holderResId
         * @return
         */
        public RequestCreatorRunnable placeholder(int holderResId) {
            this.holderResId = holderResId;
            return this;
        }

        /***
         * 发生错误加载的图片
         *
         * @param errorResId
         * @return
         */
        public RequestCreatorRunnable error(int errorResId) {

            this.errorResId = errorResId;
            return this;
        }

        public void into(ImageView imageView) {
            this.imageView = imageView;
            //设置占位图片
            if (holderResId != 0 && this.imageView != null) {
                this.imageView.setImageResource(holderResId);
            }
            if (TextUtils.isEmpty(url)) {
                return;
            }
            // 1.去内存之中在找
            Bitmap reference = imageCache.get(url);
            Bitmap cacheBitmap;
            if (reference != null) {
                cacheBitmap = reference;
                // 有图片就显示图片
                imageView.setImageBitmap(cacheBitmap);
                return;
            }

            // 2.去本地硬盘中找
            Bitmap diskBitmap = getBitmapFile();
            if (diskBitmap != null) {
                // 本地磁盘有就显示图片
                imageView.setImageBitmap(diskBitmap);
                // 保存到内存中去
                imageCache.put(url, diskBitmap);
                return;
            }
            // 3.连接网络请求数据
            executorService.submit(this);
            return;

        }

        @Override
        public void run() {
            // 子线程
            // 处理网络请求
            URL loadUrl;
            try {
                loadUrl = new URL(url);
                HttpURLConnection conn = (HttpURLConnection) loadUrl
                        .openConnection();
                // 设置请求方式
                conn.setRequestMethod("GET");
                // 设置请求时间
                conn.setConnectTimeout(2000);
                if (conn.getResponseCode() == 200) {
                    InputStream is = conn.getInputStream();
                    // 获取到图片进行显示
                    final Bitmap bm = BitmapFactory.decodeStream(is);
                    handler.post(new Runnable() {
                        @Override
                        public void run() {
                            // 主线程
                            imageView.setImageBitmap(bm);
                        }
                    });
                    // 3.1保存到内存中
                    imageCache.put(url, bm);
                    // 3.2保存到磁盘
                    // 从url中获取文件名字
                    String fileName = url.substring(url.lastIndexOf("/") + 1);
                    // 获取存储路径
                    File file = new File(getCacheDir(), md5(fileName));
                    FileOutputStream os = new FileOutputStream(file);
                    // 将图片转换为文件进行存储
                    bm.compress(Bitmap.CompressFormat.PNG, 100, os);
                } else {
                    // 联网失败，显示失败图片
                    showError();
                }
            } catch (FileNotFoundException e) {

            } catch (Exception e) {
                e.printStackTrace();
                // 显示错误的图片
                showError();
            }

        }

        /***
         * 获取文件中的图片
         *
         * @return
         */
        private Bitmap getBitmapFile() {
            // 从url中获取文件名字
            String fileName = url.substring(url.lastIndexOf("/") + 1);
            File file = new File(getCacheDir(), md5(fileName));
            // 确保路径没有问题
            if (file.exists() && file.length() > 0) {
                // 返回图片
                return BitmapFactory.decodeFile(file.getAbsolutePath());

            } else {

                return null;
            }
        }

        /***
         * 显示错误的图片
         */
        private void showError() {
            handler.post(new Runnable() {
                @Override
                public void run() {
                    if (errorResId != 0 && imageView != null) {
                        imageView.setImageResource(errorResId);
                    }
                }
            });
        }
    }


    /**
     * 对字符串做md5
     *
     * @param s 目标字符串
     */
    public static String md5(String s) {
        if (s == null) return null;
        char hexDigits[] = {'0', '1', '2', '3', '4', '5', '6', '7', '8', '9', 'a', 'b', 'c', 'd', 'e', 'f'};
        try {
            byte[] bytes = s.getBytes("UTF-8");
            // 获得MD5摘要算法的 MessageDigest 对象
            MessageDigest digest = MessageDigest.getInstance("md5");
            // 使用指定的字节更新摘要
            digest.update(bytes);
            //获得密文
            byte[] md = digest.digest();
            // 把密文转换成十六进制的字符串形式
            int j = md.length;
            char str[] = new char[j * 2];
            int k = 0;
            for (byte byte0 : md) {
                str[k++] = hexDigits[byte0 >>> 4 & 0xf];
                str[k++] = hexDigits[byte0 & 0xf];
            }
            return new String(str);
        } catch (Throwable e) {
            e.printStackTrace();
        }
        return null;
    }


}