package com.windmill.sdk;

import android.location.Location;
import android.text.TextUtils;

import java.sql.Time;
import java.util.Date;

public class CustomDeviceController extends WMCustomController {


    private boolean isCanUseAndroidId = true;
    private boolean isCanUsePhoneState = true;
    private boolean isCanUseLocation = true;
    private String androidId;
    private String devOaid;
    private String devImei;
    private Location location;

    public void setAndroidId(String androidId) {
        this.androidId = androidId;
    }


    public void setLocation(float latitude, float longitude) {
        Location location = new Location("");
        location.setLatitude(latitude);
        location.setLongitude(longitude);
        location.setTime(new Date().getTime());
        this.location = location;
    }

    public void setCanUseAndroidId(boolean canUseAndroidId) {
        isCanUseAndroidId = canUseAndroidId;
    }

    public void setCanUsePhoneState(boolean canUsePhoneState) {
        isCanUsePhoneState = canUsePhoneState;
    }

    public void setCanUseLocation(boolean canUseLocation) {
        isCanUseLocation = canUseLocation;
    }

    public void setDevImei(String devImei) {
        this.devImei = devImei;
    }

    public void setDevOaid(String devOaid) {
        this.devOaid = devOaid;
    }

    @Override
    public boolean isCanUseAndroidId() {
        return isCanUseAndroidId;
    }

    @Override
    public boolean isCanUsePhoneState() {
        return isCanUsePhoneState;

    }

    @Override
    public boolean isCanUseLocation() {
        return isCanUseLocation;
    }

    @Override
    public Location getLocation() {
        if(location != null){
            return location;
        }
        return super.getLocation();
    }

    @Override
    public String getAndroidId() {
        if(androidId != null){
            return androidId;
        }

        return super.getAndroidId();
    }

    @Override
    public String getDevOaid() {
        if(devOaid != null){
            return devOaid;
        }

        return super.getDevOaid();
    }

    @Override
    public String getDevImei() {
        if(devImei != null){
            return devImei;
        }
        return super.getDevImei();
    }
}
