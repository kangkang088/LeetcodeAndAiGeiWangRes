package com.windmill.sdk;

import android.util.Log;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class JsonUtils {

    private static final String TAG = "WindMillUnitySupport";

    public static JSONObject convertMapToJson(Map<String, Object> map) {
        JSONObject jsonObject = new JSONObject();
        try {
            for (Map.Entry<String, Object> entry : map.entrySet()) {
                String key = entry.getKey();
                Object value = entry.getValue();

                if (value instanceof Map) {
                    // If the value is a nested map, recursively convert it to JSON
                    jsonObject.put(key, convertMapToJson((Map<String, Object>) value));
                } else if (value instanceof List) {
                    // If the value is a list, recursively convert it to a JSON array
                    jsonObject.put(key, convertListToJsonArray((List<Object>) value));
                } else {
                    // Otherwise, add the key-value pair to the JSON object
                    jsonObject.put(key, value);
                }
            }
        } catch (Throwable e) {
            Log.e(TAG, e.getMessage());
        }
        return jsonObject;
    }

    public static JSONArray convertListToJsonArray(List<Object> list) {
        JSONArray jsonArray = new JSONArray();
        try {
            for (Object value : list) {
                if (value instanceof Map) {
                    // If the value is a nested map, recursively convert it to JSON
                    jsonArray.put(convertMapToJson((Map<String, Object>) value));
                } else if (value instanceof List) {
                    // If the value is a list, recursively convert it to a JSON array
                    jsonArray.put(convertListToJsonArray((List<Object>) value));
                } else {
                    // Otherwise, add the value to the JSON array
                    jsonArray.put(value);
                }
            }
        } catch (Throwable e) {
            Log.e(TAG, e.getMessage());
        }
        return jsonArray;
    }
}
