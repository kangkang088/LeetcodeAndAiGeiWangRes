﻿namespace WindMill.Advertisements
{
#if !UNITY_EDITOR && UNITY_ANDROID
    using System;
    using System.Collections.Generic;
    using UnityEngine;

    public static class Advertisement
    {
        private static AndroidJavaObject mSDK = null;
        private static AndroidJavaObject mUnityActivity = null;
        private static AndroidJavaObject wmAdConfig;
        public static string Version
        {
            get
            {
                AndroidJavaClass windmillAds = new AndroidJavaClass("com.windmill.sdk.WindMillAd");

                if (windmillAds != null)
                {
                    return windmillAds.CallStatic<string>("getVersion");
                }
                return null;
            }
        }

        public static void networkPreInit(List<WindmillNetworkInfo> list)
        {
             initSDK();
             if (mSDK != null)
             {

                String json = Json.Serialize(list);

                if(json != null ){

                    AndroidJavaClass javaClass = new AndroidJavaClass("com.windmill.sdk.WMNetworkConfigUtil");

                    AndroidJavaObject javaObject = javaClass.CallStatic<AndroidJavaObject>("fromJson", json);

                    if(javaObject != null)
                    {
                        mSDK.Call("setInitNetworkConfig", javaObject);
                    }
                }
             }

        }

        public static void setPresetLocalStrategyPath(string path)
        {
           initSDK();

           if (mSDK != null)
           {
              mSDK.Call("setLocalStrategyAssetPath", mUnityActivity , path);
           }
        }

        public static void SetExt(Dictionary<string, string> ext)
        {
            Debug.Log("该方法不支持当前平台");
            
        }

        public static void InitCustomGroupForPlacementId(Dictionary<string, object> customGroup, string placementId)
        {
            initSDK();
            if (mSDK != null)
            {

                AndroidJavaObject javaObject = Utils.DictionaryToAndroidHashMap(customGroup);

                mSDK.Call("initPlacementCustomMap",placementId, javaObject);

            }

        }


        public static void InitCustomGroup(Dictionary<string, object> customGroup)
        {
           initSDK();
           if (mSDK != null)
           {

               AndroidJavaObject javaObject = Utils.DictionaryToAndroidHashMap(customGroup);

               mSDK.Call("initCustomMap", javaObject);

           }
        }


         public static void SetCustomDeviceController(CustomDeviceController deviceController)
         {

            AndroidJavaObject wmAdConfigBuilder = new AndroidJavaObject("com.windmill.sdk.WMAdConfig$Builder");


            AndroidJavaObject javaObject = new AndroidJavaObject("com.windmill.sdk.CustomDeviceController");

            javaObject.Call("setAndroidId", deviceController.androidId);
            javaObject.Call("setDevImei", deviceController.devImei);
            javaObject.Call("setDevOaid", deviceController.devOaid);
            if(deviceController.devLocation != null)
            {
                javaObject.Call("setLocation", deviceController.devLocation.Latitude, deviceController.devLocation.Longitude);
            }

            javaObject.Call("setCanUseAndroidId", deviceController.isCanUseAndroidId);
            javaObject.Call("setCanUsePhoneState", deviceController.isCanUsePhoneState);
            javaObject.Call("setCanUseLocation", deviceController.isCanUseLocation);

            wmAdConfig = wmAdConfigBuilder.Call<AndroidJavaObject>("customController", javaObject).Call<AndroidJavaObject>("build");
        }

        public static void SetDebugEnable(bool enable)
        {
            initSDK();
            if (mSDK != null)
            {

                mSDK.Call("setDebugEnable", enable);
   
           }
        }

        public static void setSupportMultiProcess(bool enable)
        {
            initSDK();
            if (mSDK != null)
            {

                mSDK.Call("setSupportMultiProcess", enable);
   
           }
        }

        public static AgeRestrictedStatus GetAgeRestrictedStatus()
        {
            int value = 0;
            initSDK();
            if (mSDK != null)
            {
                AndroidJavaObject ageRestrictedStatus = mSDK.Call<AndroidJavaObject>("getAgeRestrictedStatus");
                if (ageRestrictedStatus != null)
                {
                    value = ageRestrictedStatus.Call<int>("getValue");
                }
            }
            if (value == 1)
            {
                return AgeRestrictedStatus.WindAgeRestrictedStatusYES;
            }
            else if (value == 2)
            {
                return AgeRestrictedStatus.WindAgeRestrictedStatusNO;
            }
            else
            {
                return AgeRestrictedStatus.WindAgeRestrictedStatusUnknow;
            }
        }

        public static void SetIsAgeRestrictedUser(AgeRestrictedStatus status)
        {
            initSDK();

            if (mSDK != null)
            {
                AndroidJavaClass ageRestrictedStatus = new AndroidJavaClass("com.windmill.sdk.WindMillUserAgeStatus");

                AndroidJavaObject consent;
                switch (status)
                {
                    case AgeRestrictedStatus.WindAgeRestrictedStatusNO:
                        {
                            consent = ageRestrictedStatus.GetStatic<AndroidJavaObject>("WindAgeRestrictedStatusNO");
                        }
                        break;
                    case AgeRestrictedStatus.WindAgeRestrictedStatusYES:
                        {
                            consent = ageRestrictedStatus.GetStatic<AndroidJavaObject>("WindAgeRestrictedStatusYES");
                        }
                        break;
                    default:
                        {
                            consent = ageRestrictedStatus.GetStatic<AndroidJavaObject>("WindAgeRestrictedStatusUnknown");
                        }
                        break;
                }

                mSDK.Call("setIsAgeRestrictedUser", consent);
                Debug.Log("dll--setIsAgeRestrictedUser " + consent);
            }
        }

        public static ConsentStatus GetUserGDPRConsentStatus()
        {
            int value = 0;
            initSDK();

            if (mSDK != null)
            {
                AndroidJavaObject ageRestrictedStatus = mSDK.Call<AndroidJavaObject>("getUserGDPRConsentStatus");
                if (ageRestrictedStatus != null)
                {
                    value = ageRestrictedStatus.Call<int>("getValue");
                }

            }
            if (value == 1)
            {
                return ConsentStatus.WindConsentAccepted;
            }
            else if (value == 2)
            {
                return ConsentStatus.WindConsentDenied;
            }
            else
            {
                return ConsentStatus.WindConsentUnknown;
            }
        }

        public static void SetUserGDPRConsentStatus(ConsentStatus status)
        {
            initSDK();

            if (mSDK != null)
            {
                AndroidJavaClass bitmapClass = new AndroidJavaClass("com.windmill.sdk.WindMillConsentStatus");

                AndroidJavaObject consent;
                switch (status)
                {
                    case ConsentStatus.WindConsentDenied:
                        {
                            consent = bitmapClass.GetStatic<AndroidJavaObject>("DENIED");
                        }
                        break;
                    case ConsentStatus.WindConsentAccepted:
                        {
                            consent = bitmapClass.GetStatic<AndroidJavaObject>("ACCEPT");
                        }
                        break;
                    default:
                        {
                            consent = bitmapClass.GetStatic<AndroidJavaObject>("UNKNOWN");
                        }
                        break;
                }

                mSDK.Call("setUserGDPRConsentStatus", consent);
                Debug.Log("dll--setUserGDPRConsentStatus " + consent);
            }
        }

        public static Int32 GetUserAge()
        {
            int age = 0;
            initSDK();

            if (mSDK != null)
            {
                age = mSDK.Call<int>("getUserAge");
            }
            return age;
        }

        public static void SetUserAge(Int32 age)
        {
            initSDK();
            if (mSDK != null)
            {
                mSDK.Call("setUserAge", age);
                Debug.Log("dll--setUserAge " + age);
            }
        }

        public static void init(string appId)
        {
            Debug.Log("Android init");
            if (mSDK == null)
            {
                AndroidJavaClass unityPlayer = new AndroidJavaClass("com.unity3d.player.UnityPlayer");
                mUnityActivity = unityPlayer.GetStatic<AndroidJavaObject>("currentActivity");

                AndroidJavaClass windMillAd = new AndroidJavaClass("com.windmill.sdk.WindMillAd");
                mSDK = windMillAd.CallStatic<AndroidJavaObject>("sharedAds");
            }

            if(wmAdConfig != null)
            {
                mSDK.Call<bool>("startWithAppId", mUnityActivity, appId, wmAdConfig);
            }
            else
            {
                mSDK.Call<bool>("startWithAppId", mUnityActivity, appId);
            }
        }

        private static void initSDK()
        {
            if (mSDK == null)
            {
                AndroidJavaClass unityPlayer = new AndroidJavaClass("com.unity3d.player.UnityPlayer");
                mUnityActivity = unityPlayer.GetStatic<AndroidJavaObject>("currentActivity");

                AndroidJavaClass windMillAd = new AndroidJavaClass("com.windmill.sdk.WindMillAd");
                mSDK = windMillAd.CallStatic<AndroidJavaObject>("sharedAds");
            }
        }

        public static void RequestPermissionIfNecessary()
        {
            AndroidJavaClass unityPlayer = new AndroidJavaClass("com.unity3d.player.UnityPlayer");
            mUnityActivity = unityPlayer.GetStatic<AndroidJavaObject>("currentActivity");

            AndroidJavaClass windmillAds = new AndroidJavaClass("com.windmill.sdk.WindMillAd");
            windmillAds.CallStatic("requestPermission", mUnityActivity);
        }

        public static void setUserAdultStatus(UserAdultStatus userAdultStatus)
        {
            initSDK();
            switch (userAdultStatus)
            {
                case UserAdultStatus.UserAdult:
                {
                        mSDK.Call("setAdult", true);
                        Debug.Log("dll--setAdult true ");


                 }break;

                case UserAdultStatus.UserChild:
                    {
                        mSDK.Call("setAdult", false);
                        Debug.Log("dll--setAdult false ");


                    }
                    break;
                default:
                    {

                    }break;
            }
        }

        public static void setPersonalizedAdvertisingStatus(PersonalizedAdvertisingStatus personalizedAdvertisingStatus)
        {
            initSDK();
            switch (personalizedAdvertisingStatus)
            {
                case PersonalizedAdvertisingStatus.PersonalizedAdvertisingON:
                    {
                        mSDK.Call("setPersonalizedAdvertisingOn", true);
                        Debug.Log("dll--setPersonalizedAdvertisingOn true ");
                    }
                    break;

                case PersonalizedAdvertisingStatus.PersonalizedAdvertisingOFF:
                    {
                        mSDK.Call("setPersonalizedAdvertisingOn", false);
                        Debug.Log("dll--setPersonalizedAdvertisingOn false ");


                    }
                    break;
                default:
                    {

                    }
                    break;
            }
        }

      
    }

    


#endif
}