package com.windmill.sdk;

import android.app.Activity;
import android.content.Context;
import android.graphics.Color;
import android.os.Handler;
import android.os.Looper;
import android.view.View;
import android.view.ViewGroup;
import android.view.ViewParent;
import android.widget.FrameLayout;

import com.windmill.sdk.banner.WMBannerAdListener;
import com.windmill.sdk.banner.WMBannerAdRequest;
import com.windmill.sdk.banner.WMBannerView;
import com.windmill.sdk.models.AdInfo;

import java.util.List;
import java.util.Map;


public class BannerAdUnitySupport {

    private static final String TAG = BannerAdUnitySupport.class.getSimpleName();

    private Handler mHandler;
    private WMBannerView mBannerView;
    private ViewGroup mBannerContainer;

    private static BannerAdUnitySupport mInstance = new BannerAdUnitySupport();

    public BannerAdUnitySupport() {
        if (mHandler == null) {
            mHandler = new Handler(Looper.getMainLooper());
        }

    }


    public boolean isReady(){
        if(mBannerView == null){
            return  false;
        }

        return mBannerView.isReady();
    }
    public static BannerAdUnitySupport getInstance() {
        return mInstance;
    }


    public List<AdInfo> getCacheAdInfoList(){
        if (mBannerView == null){
            return null;
        }
        return mBannerView.checkValidAdCaches();
    }

    public boolean loadAd(final Activity activity, final WMBannerAdRequest adRequest,int width,int height, final WMBannerAdListener bannerAdListener){

        mHandler.post(new Runnable() {
            @Override
            public void run() {
                if (mBannerView == null){

                    mBannerView = new WMBannerView(activity);
                    mBannerContainer = new FrameLayout(activity.getApplicationContext());
                    mBannerContainer.setBackgroundColor(Color.TRANSPARENT);
                    mBannerContainer.setVisibility(View.INVISIBLE);
                    activity.addContentView(mBannerContainer,new FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));

                }
                mBannerView.setAutoAnimation(true);
                mBannerView.setAdListener(bannerAdListener);

                Map<String, Object> options = adRequest.getOptions();
                options.put(WMConstants.AD_WIDTH,width);
                options.put(WMConstants.AD_HEIGHT,height);
                mBannerView.loadAd(adRequest);
            }
        });

        return true;
    }
    public boolean loadAd(final Activity activity, final WMBannerAdRequest adRequest, final WMBannerAdListener bannerAdListener){

        mHandler.post(new Runnable() {
            @Override
            public void run() {
                if (mBannerView == null){

                    mBannerView = new WMBannerView(activity);
                    mBannerContainer = new FrameLayout(activity.getApplicationContext());
                    mBannerContainer.setBackgroundColor(Color.TRANSPARENT);
                    mBannerContainer.setVisibility(View.INVISIBLE);
                    activity.addContentView(mBannerContainer,new FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));

                }
                mBannerView.setAutoAnimation(true);
                mBannerView.setAdListener(bannerAdListener);

                mBannerView.loadAd(adRequest);
            }
        });

        return true;
    }

    public void destroy() {
        mHandler.post(new Runnable() {

            @Override
            public void run() {


                if(mBannerView != null){
                    mBannerView.setAdListener(null);
                    mBannerView.destroy();
                    mBannerView.setVisibility(View.GONE);

                    if (mBannerContainer != null){
                        mBannerContainer.removeView(mBannerView);
                        ViewGroup parent = (ViewGroup) mBannerContainer.getParent();
                        if(parent != null){
                            parent.removeView(mBannerContainer);
                        }
                        mBannerContainer = null;
                    }
                    mBannerView = null;

                }

            }
        });
    }


    public ViewGroup getRootLayout(Activity activity) {
        if (activity == null) {
            return null;
        }
        ViewGroup rootGroup = activity.findViewById(android.R.id.content);
        return rootGroup;
    }


    public void hideAd(Activity activity){
                   mHandler.post(new Runnable() {
                          @Override
                          public void run() {

                            if (mBannerView != null && mBannerContainer != null){
                                mBannerContainer.setVisibility(View.INVISIBLE);
                            }
                        }
                   });
       
    }
    //相关调用注意放在主线程
    public boolean showAd(final Activity activity,  final int x, final int y, final int width,final int height) {

        if (mBannerView != null && mBannerContainer != null) {
            mHandler.post(new Runnable() {
                @Override
                public void run() {

                    int xwidth = width;
                    int xheight =height;

                    if (width == 0) {
                        xwidth = ViewGroup.LayoutParams.MATCH_PARENT;
                    }

                    if (height == 0) {
                        xheight = ViewGroup.LayoutParams.WRAP_CONTENT;
                    }


                    ViewParent parent = mBannerView.getParent();
                    if(parent == null){
                        FrameLayout.LayoutParams layoutParams = new FrameLayout.LayoutParams(xwidth, xheight);

                        layoutParams.leftMargin = x;
                        layoutParams.topMargin = y;
                        mBannerContainer.addView(mBannerView, layoutParams);
                    }else{
                        FrameLayout.LayoutParams layoutParams = (FrameLayout.LayoutParams) mBannerView.getLayoutParams();
                        layoutParams.leftMargin = x;
                        layoutParams.topMargin = y;
                    }
                    mBannerContainer.setVisibility(View.VISIBLE);

                }

            });
            return true;
        }

        return false;

    }

    private int dip2Px(Context context, int dipValue) {
        final float scale = context.getResources().getDisplayMetrics().density;
        return (int) (dipValue * scale + 0.5f);
    }

    private int px2dip(Context context, int pxValue) {
        if (pxValue != 0){
            final float scale = context.getResources().getDisplayMetrics().density;
            return (int) (pxValue / scale + 0.5f);
        }

        return pxValue;
    }

}
