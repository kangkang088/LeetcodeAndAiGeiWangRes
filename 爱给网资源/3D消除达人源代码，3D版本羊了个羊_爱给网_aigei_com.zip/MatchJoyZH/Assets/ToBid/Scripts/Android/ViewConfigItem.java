package com.windmill.sdk;

import android.graphics.Color;

import org.json.JSONException;
import org.json.JSONObject;

class ViewConfigItem {
    private JSONObject config;

    public ViewConfigItem(JSONObject item) {
        config = item;

    }

    public int getFontSize() {


        try {
            if(config.has("fontSize")) {
                return config.getInt("fontSize");
            }
        } catch (JSONException e) {
            e.printStackTrace();
        }
        return 0;
    }

    public int getX() {

        try {
            if(config.has("x")) {

                int x = config.getInt("x");
                if (!userPixel()) {
                    x = (int) ResourceUtil.Instace().dip2Px(x);
                }
                return x;
            }
        } catch (JSONException e) {
            e.printStackTrace();
        }
        return 0;
    }

    public int getY() {
        try {
            if(config.has("y")) {

                int y = config.getInt("y");
                if (!userPixel()) {
                    y = (int) ResourceUtil.Instace().dip2Px(y);
                }
                return y;
            }
        } catch (JSONException e) {
            e.printStackTrace();
        }
        return 0;

    }

    public int getWidth() {
        try {
            if(config.has("width")) {
                int width = config.getInt("width");
                if (!userPixel()) {
                    width = (int) ResourceUtil.Instace().dip2Px(width);
                }
                return width;
            }
        } catch (JSONException e) {
            e.printStackTrace();
        }
        return 0;
    }

    public int getHeight() {
        try {
            if(config.has("height")) {

                int height = config.getInt("height");
                if (!userPixel()) {
                    height = (int) ResourceUtil.Instace().dip2Px(height);
                }
                return height;
            }
        } catch (JSONException e) {
            e.printStackTrace();
        }
        return 0;
    }

    public int getTextAlign() {
        try {
            if(config.has("textAlignment")) {
                return config.getInt("textAlignment");
            }
        } catch (JSONException e) {
            e.printStackTrace();
        }
        return 0;
    }

    public boolean userPixel() {

        try {
            if(config.has("pixel")) {
                return config.getBoolean("pixel");
            }
        } catch (Throwable e) {
            e.printStackTrace();
        }
        return false;
    }

    public int getScaleType() {
        try {
            if(config.has("scaleType")) {
                return config.getInt("scaleType");
            }
        } catch (JSONException e) {
            e.printStackTrace();
        }
        return 0;
    }

    public boolean isCtaClick() {
        try {
            if(config.has("isCtaClick")) {
                return config.getBoolean("isCtaClick");
            }
        } catch (Throwable e) {
            e.printStackTrace();
        }
        return false;
    }

    public String getTextColor() {
        try {
            if(config.has("textColor")) {
                return config.getString("textColor");
            }
        } catch (Throwable e) {
            e.printStackTrace();
        }
        return null;
    }

    public String getBackgroundColor() {

        try {
            return config.getString("backgroundColor");
        } catch (Throwable e) {
            e.printStackTrace();
        }
        return null;
    }


}
