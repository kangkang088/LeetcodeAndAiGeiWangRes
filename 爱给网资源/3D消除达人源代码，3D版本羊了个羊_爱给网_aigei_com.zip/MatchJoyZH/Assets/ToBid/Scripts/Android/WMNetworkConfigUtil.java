package com.windmill.sdk;

import org.json.JSONArray;
import org.json.JSONObject;

public class WMNetworkConfigUtil {
    public static WMNetworkConfig fromJson(String json) {


        try {
            JSONArray list = new JSONArray(json);

            if(list != null){
                WMNetworkConfig.Builder builder = new  WMNetworkConfig.Builder();
                for (int i = 0; i < list.length(); i++) {
                    Object item = list.get(i);
                    int networkId = 0;
                    String appId = null;
                    String appKey = null;
                    if(item instanceof JSONObject){
                         networkId = ((JSONObject)item).optInt("networkId",0);
                         appId = ((JSONObject)item).optString("appId");
                         appKey = ((JSONObject)item).optString("appKey");
                    } else if (item instanceof JSONArray) {

                    }else if( item instanceof String){
                        JSONObject obj = new JSONObject((String)item);
                         networkId = obj.optInt("networkId",0);
                         appId = obj.optString("appId");
                         appKey = obj.optString("appKey");
                    }

                    if(networkId >0){
                        WMAdnInitConfig initConfig = new WMAdnInitConfig(networkId, appId, appKey);
                        builder.addInitConfig(initConfig);
                    }
                }

               return builder.build();
            }
        }catch (Throwable th){
            th.printStackTrace();
        }

        return null;
    }

}
