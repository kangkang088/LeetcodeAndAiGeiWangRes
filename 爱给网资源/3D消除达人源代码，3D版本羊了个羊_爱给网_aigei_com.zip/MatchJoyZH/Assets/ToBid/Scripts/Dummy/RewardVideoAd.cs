﻿namespace WindMill.Advertisements
{

#if UNITY_EDITOR
    using System;
    using System.Collections.Generic;

    public sealed class RewardVideoAd : IDisposable

    {

        public string PlacementId
        {
            get
            {
                return this.request.PlacementId;
            }
        }

        private IRewardVideoAdListener listener = null;
        private Request request = null;

        public void Dispose()
        {

        }

        public List<AdInfo> GetCacheAdInfoList(){
            return null;
        }
        public AdInfo GetAdInfo() {
            return null;
        }

        public RewardVideoAd(Request request)
        {
            this.request = request;
        }

        /// <summary>
        /// Load reward video Ad.
        /// </summary>
        public void LoadAd()
        {
            Error error = new Error(-600000, "not support platform");
            this.listener?.OnAdError(this, error);
        }

        /// <summary>
        /// Sets the interaction listener for this Ad.
        /// </summary>
        public void SetRewardAdListener(IRewardVideoAdListener listener)
        {
            this.listener = listener;
        }


        /// <summary>
        /// Show the reward video Ad.
        /// </summary>
        public void ShowAd()
        {

        }

        public bool Ready()
        {
            return false;
        }

    }
#endif

}