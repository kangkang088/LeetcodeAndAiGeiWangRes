﻿namespace WindMill.Advertisements
{
#if UNITY_EDITOR

    using System;
    using System.Collections;
    using System.Collections.Generic;
    using UnityEngine;

    public static class Advertisement
    {
        public static string Version
        {
            get
            {
                return "1.0.0";
            }
        }


        public static void SetDebugEnable(bool enable)
        {
            Debug.Log("不支持当前平台");

        }

        public static void setSupportMultiProcess(bool enable)
        {
            Debug.Log("不支持当前平台");

        }


        public static void setPresetLocalStrategyPath(string path) {
            Debug.Log("不支持当前平台");

        }

        public static void networkPreInit(List<WindmillNetworkInfo> list)
        {
            Debug.Log("不支持当前平台");

        }

        public static void InitCustomGroup(Dictionary<string, object> customGroup)
        {
            Debug.Log("不支持当前平台");
        }

        public static void InitCustomGroupForPlacementId(Dictionary<string, object> customGroup,string placementId)
        {
            Debug.Log("不支持当前平台");
        }
        public static void SetCustomDeviceController(CustomDeviceController deviceController)
        {
            Debug.Log("不支持当前平台");

        }

        public static void SetExt(Dictionary<string, string> ext)
        {
            Debug.Log("不支持当前平台");

        }

        public static AgeRestrictedStatus GetAgeRestrictedStatus()
        {
            return AgeRestrictedStatus.WindAgeRestrictedStatusUnknow;
        }

        public static void SetIsAgeRestrictedUser(AgeRestrictedStatus ageRestrictedStatus)
        {
            Debug.Log("不支持当前平台");
        }


        public static ConsentStatus GetUserGDPRConsentStatus()
        {
            return ConsentStatus.WindConsentUnknown;
        }

        public static void SetUserGDPRConsentStatus(ConsentStatus ageRestrictedStatus)
        {
            Debug.Log("不支持当前平台");
        }


        public static Int32 GetUserAge()
        {
            return 0;
        }

        public static void SetUserAge(Int32 age)
        {
            Debug.Log("不支持当前平台");
        }


        public static void init(string appId)
        {
            Debug.Log("不支持当前平台");
        }


        public static void RequestPermissionIfNecessary()
        {
            Debug.Log("不支持当前平台");
        }

        public static void setUserAdultStatus(UserAdultStatus userAdultStatus)
        {
            Debug.Log("不支持当前平台");
        }

        public static void setPersonalizedAdvertisingStatus(PersonalizedAdvertisingStatus personalizedAdvertisingStatus)
        {
            Debug.Log("不支持当前平台");
        }

        internal static void InitCustomGroupWithPlacementId(Dictionary<string, object> dic, string v)
        {
            throw new NotImplementedException();
        }
    }

#endif
}