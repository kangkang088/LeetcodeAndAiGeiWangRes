﻿namespace WindMill.Advertisements
{
#if UNITY_EDITOR || (!UNITY_ANDROID && !UNITY_IOS)
    using System;
    using System.Collections.Generic;
    using UnityEngine;

    public class NativeAdManager : INativeAdClient
    {
        private Request request = null;

        public NativeAdManager(Request request)
        {
        }
        public string PlacementId
        {
            get
            {
                return this.request.PlacementId;
            }
        }

        public void Dispose()
        {
            throw new NotImplementedException();
        }

        public AdInfo GetAdInfo() {
            return null;
        }

        public AppInfo GetAppInfo() {
            return null;
        }

        public List<AdInfo> GetCacheAdInfoList(){
            return null;
        }

        public void LoadAd(int width, int height)
        {
            throw new NotImplementedException();
        }


        public void ShowAd(float x, float y)
        {
            throw new NotImplementedException();
        }


        public void ShowAd(NativeAdView adView)
        {
            throw new NotImplementedException();

        }
        public void SetDislikeListener(INativeAdDislikeListener listener)
        {
            throw new NotImplementedException();
        }

        public void SetInteractionListener(INativeAdInteractionListener listener)
        {
            throw new NotImplementedException();
        }

        public void SetLoadListener(INativeAdLoadListener listener)
        {
            throw new NotImplementedException();
        }
    }
#endif
}
