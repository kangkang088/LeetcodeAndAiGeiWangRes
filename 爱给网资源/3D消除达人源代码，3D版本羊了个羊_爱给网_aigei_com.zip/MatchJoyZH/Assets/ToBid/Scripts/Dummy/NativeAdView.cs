﻿using System.Text;
using UnityEngine;

namespace WindMill.Advertisements
{
    public class NativeAdView
    {
        public NativeAdViewItem rootView;

        public NativeAdViewItem iconView;

        public NativeAdViewItem adLogoView;

        public NativeAdViewItem titleView;

        public NativeAdViewItem descriptView;

        public NativeAdViewItem mainAdView;

        public NativeAdViewItem dislikeButton;

        public NativeAdViewItem ctaButton;

        private string rootViewKey = "rootView";

        private string iconViewKey = "iconView";

        private string descriptViewKey = "descriptView";

        private string titleViewKey = "titleView";

        private string mainAdViewKey = "mainAdView";

        private string adLogoViewKey = "adLogoView";

        private string ctaButtonKey = "ctaButton";

        private string dislikeButtonKey = "dislikeButton";

        public string toJSON()
        {
            StringBuilder builder = new StringBuilder();

            builder.Append("{");

            if (rootView != null)
            {
                builder.Append("\"").Append(rootViewKey).Append("\"");
                builder.Append(":");
                builder.Append(JsonUtility.ToJson(rootView));
                builder.Append(",");
            }

            if (iconView != null)
            {
                builder.Append("\"").Append(iconViewKey).Append("\"");
                builder.Append(":");
                builder.Append(JsonUtility.ToJson(iconView));
                builder.Append(",");
            }

            if (titleView != null)
            {
                builder.Append("\"").Append(titleViewKey).Append("\"");
                builder.Append(":");
                builder.Append(JsonUtility.ToJson(titleView));
                builder.Append(",");
            }

            if (adLogoView != null)
            {
                builder.Append("\"").Append(adLogoViewKey).Append("\"");
                builder.Append(":");
                builder.Append(JsonUtility.ToJson(adLogoView));
                builder.Append(",");
            }

            if (descriptView != null)
            {
                builder.Append("\"").Append(descriptViewKey).Append("\"");
                builder.Append(":");
                builder.Append(JsonUtility.ToJson(descriptView));
                builder.Append(",");
            }

            if (mainAdView != null)
            {
                builder.Append("\"").Append(mainAdViewKey).Append("\"");
                builder.Append(":");
                builder.Append(JsonUtility.ToJson(mainAdView));
                builder.Append(",");
            }

            if (ctaButton != null)
            {
                builder.Append("\"").Append(ctaButtonKey).Append("\"");
                builder.Append(":");
                builder.Append(JsonUtility.ToJson(ctaButton));
                builder.Append(",");
            }

            if (dislikeButton != null)
            {
                builder.Append("\"").Append(dislikeButtonKey).Append("\"");
                builder.Append(":");
                builder.Append(JsonUtility.ToJson(dislikeButton));
            }


            string temp = builder.ToString();

            if (temp.EndsWith(","))
            {
                temp = temp.Substring(0, temp.Length - 1);
            }

            temp = temp + "}";
            
            return temp;
        }
    }
}
