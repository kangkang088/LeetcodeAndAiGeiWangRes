﻿namespace WindMill.Advertisements
{
    public class NativeAdViewItem
    {
        public int x;
        public int y;
        public int width;
        public int height;
        public bool pixel;
        public string backgroundColor;
        public string textColor;
        public int fontSize;
        public int scaleType;// 0: default  1:center, 2:fill
        public int textAlignment;
        public bool isFullScreen;

        public bool isCtaClick;


        public NativeAdViewItem()
        {

        }

        public NativeAdViewItem(int x, int y,int width,int height, bool pixel)
        {
            this.x = x;
            this.y = y;
            this.width = width;
            this.height = height;
            this.pixel = pixel;
        }

    }
}