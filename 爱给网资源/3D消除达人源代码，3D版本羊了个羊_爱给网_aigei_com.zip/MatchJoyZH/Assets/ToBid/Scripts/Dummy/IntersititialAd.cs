﻿namespace WindMill.Advertisements
{

#if UNITY_EDITOR
    using System;
    using System.Collections.Generic;

    public sealed class IntersititialAd : IDisposable
    {

        public string PlacementId
        {
            get
            {
                return this.request.PlacementId;
            }
        }

        private IIntersititialAdListener listener = null;
        private Request request = null;

        public void Dispose()
        {
        }

        public AdInfo GetAdInfo() {
            return null;
        }
        public List<AdInfo> GetCacheAdInfoList(){
            return null;
        }

        public IntersititialAd(Request request)
        {
            this.request = request;
        }

        /// <summary>
        /// Sets the interaction listener for this Ad.
        /// </summary>
        public void SetIntersititialAdListener(IIntersititialAdListener listener)
        {
            this.listener = listener;
        }


        /// <summary>
        /// Load reward video Ad.
        /// </summary>
        public void LoadAd()
        {
            Error error = new Error(-600000, "not support platform");
            this.listener?.OnAdError(this, error);

        }

     

        /// <summary>
        /// Show the reward video Ad.
        /// </summary>
        public void ShowAd()
        {

        }

        public bool Ready()
        {
            return false;
        }


    }
#endif

}