﻿using System;
namespace WindMill.Advertisements
{

    #if UNITY_EDITOR
    using System;
    using UnityEngine;
    using System.Collections.Generic;

    public sealed class BannerAd : IDisposable
    {

        public string PlacementId
        {
            get
            {
                return this.request.PlacementId;
            }
        }

        private IBannerAdListener listener = null;
        private Request request = null;

        public void Dispose()
        {
        }


        public List<AdInfo> GetCacheAdInfoList(){
            return null;
        }


        public AdInfo GetAdInfo()
        {
            return null;
        }


        public BannerAd(Request request)
        {
            this.request = request;
        }

        /// <summary>
        /// Sets the interaction listener for this Ad.
        /// </summary>
        public void SetBannerAdListener(IBannerAdListener listener)
        {
            this.listener = listener;
        }


        /// <summary>
        /// Load reward video Ad.
        /// </summary>
        public void LoadAd()
        {
            Error error = new Error(-600000, "not support platform");
            this.listener?.OnAdError(this, error);

        }

        public void LoadAd(int width, int height)
        {
            Error error = new Error(-600000, "not support platform");
            this.listener?.OnAdError(this, error);

        }
        public void HideAd(){
            
        }

        /// <summary>
        /// Show the reward video Ad.
        /// </summary>
        public void ShowAd(Rect rect)
        {

        }

        public bool Ready()
        {
            return false;
        }


    }
#endif

}
