﻿using System;

namespace WindMill.Advertisements
{
    public class Location
    {

        private float latitude;
        private float longitude;
        public float Longitude => longitude;
        public float Latitude => latitude;


        public Location(float longitude, float latitude)
        {

            this.longitude = longitude;
            this.latitude = latitude;
        }


    }
}
