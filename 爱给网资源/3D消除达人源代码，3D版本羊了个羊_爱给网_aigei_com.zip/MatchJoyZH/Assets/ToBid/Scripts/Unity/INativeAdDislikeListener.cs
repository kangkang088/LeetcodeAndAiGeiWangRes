﻿namespace WindMill.Advertisements
{
    using System;
    public interface INativeAdDislikeListener
    {
        void OnSelected(NativeAdManager ad,int index, string message, bool OnAdClose);

        void OnCancel(NativeAdManager ad);

        void OnShow(NativeAdManager ad);
    }

}
