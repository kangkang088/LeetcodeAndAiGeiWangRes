﻿using System;
using UnityEngine;
namespace WindMill.Advertisements
{
    public class CustomDeviceController
    {


        public bool isCanUseLocation = true;

        public Location devLocation = new Location(0,0);

        public bool isCanUsePhoneState = true;

        public string devImei = "";

        public bool isCanUseAndroidId = true;

        public string androidId = "";

        public string devOaid = "";

        public bool isCanUseIdfa = true;

        public string devIdfa = "";

    }

}
