﻿using System;
using System.Collections.Generic;
namespace WindMill.Advertisements
{
    public sealed class RewardInfo
    {

        public string TransId { get; set; }
        public string UserId { get; set; }
        public bool IsReward { get; set; }

        public Dictionary<string, object> CustomData {get;set;}

        public RewardInfo()
        {
        }
    }
}
