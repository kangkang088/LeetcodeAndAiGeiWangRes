namespace WindMill.Consents
{

    public static class Consent {
        public static string WindMillWXAppId = @"wx_app_id";
        public static string WindMillWXUniversalLink = @"wx_universalLink";
    }

}