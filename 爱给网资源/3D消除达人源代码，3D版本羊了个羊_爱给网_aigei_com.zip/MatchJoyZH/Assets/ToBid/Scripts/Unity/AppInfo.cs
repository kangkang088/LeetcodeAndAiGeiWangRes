using System;
using System.Collections.Generic;
using UnityEngine;
using System.Security.Cryptography;
using System.Text;

namespace WindMill.Advertisements
{
    [System.Serializable]
    public class AppInfo{

        // 应用名称
        public string appName;
        // 开发者名称
        public string developerName;
        // 应用版本
        public string appVersion;
        // 隐私协议
        public string privacyUrl;
        ///权限列表
        public string permissionInfoUrl;
        //权限列表文本
        public string permissionInfo;
	    // 应用功能介绍
	    public string functionDescUrl;



       private static string convertTobase64(string str)
        {
            if(str != null)
            {
                byte[] bytes = Encoding.GetEncoding("utf-8").GetBytes(str);
                return Convert.ToBase64String(bytes);
            }
          
            return null;
        }

        private static List<string> SplitString(string input, int chunkSize)
        {
            List <string> result = new List<string>();

            if (input == null || chunkSize <= 0)
            {
                return result;
            }

            int inputLength = input.Length;

            for (int i = 0; i < inputLength; i += chunkSize)
            {
                if (i + chunkSize > inputLength)
                {
                    chunkSize = inputLength - i;
                }

                result.Add(input.Substring(i, chunkSize));
            }

            return result;
        }


        public static AppInfo CreateAppInfoFromDic(Dictionary<string,object> dic)
       {

            if (dic != null)
            {
                AppInfo appInfo = new AppInfo
                {
                    appName = (string)dic["appName"],
                    appVersion = (string)dic["appVersion"],
                    developerName = (string)dic["developerName"],
                    privacyUrl = (string)dic["privacyUrl"],
                    permissionInfoUrl = (string)dic["permissionInfoUrl"],
                    permissionInfo = (string)dic["permissionInfo"],
                    functionDescUrl = (string)dic["functionDescUrl"]
                };

                Debug.Log("app name  " + appInfo.appName);
                Debug.Log("app appVersion  " + appInfo.appVersion);
                Debug.Log("app developerName  " + appInfo.developerName);
                Debug.Log("app privacyUrl  " + appInfo.privacyUrl);
                Debug.Log("app permissionInfoUrl  " + appInfo.permissionInfoUrl);
                Debug.Log("app functionDescUrl  " + appInfo.functionDescUrl);

                List<string> result = SplitString(appInfo.permissionInfo, 200);

                foreach (var item in result)
                {
                    Debug.Log("app permissionInfo  " + item + "  end");
                }

                return appInfo;
            }

            return null;

        }

        public string ToJson()
        {
            return JsonUtility.ToJson(this);
        }

    }


}