﻿namespace WindMill.Advertisements
{
    public interface IBannerAdListener
    {
        /// <summary>
        /// Invoke when load Ad error.
        /// </summary>
        void OnAdError(BannerAd ad, Error error);

        /// <summary>
        /// Invoke when the Ad load success.
        /// </summary>
        void OnAdLoad(BannerAd ad);

        // <summary>
        /// Invoke when the Ad is shown.
        /// </summary>
        void OnAdShow(BannerAd ad);

        /// <summary>
        /// Invoke when the Ad video var is clicked.
        /// </summary>
        void OnAdClick(BannerAd ad);

        /// <summary>
        /// Invoke when the Ad is closed.
        /// </summary>
        void OnAdClose(BannerAd ad);

        /// <summary>
        /// Invoke when the Ad is AutoRefreshed.
        /// </summary>
        void OnAdAutoRefreshed(BannerAd ad);

        /// <summary>
        /// Invoke when the Ad is AutoRefresh fail.
        /// </summary>
        void OnAdAutoRefreshFail(BannerAd ad, Error error);



    }
}