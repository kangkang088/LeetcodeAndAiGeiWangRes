﻿using System;
using System.Collections.Generic;

namespace WindMill.Advertisements
{
    [System.Serializable]
    public class WindmillNetworkInfo
    {

        public int networkId;
        public string appId;
        public string appKey;

        public WindmillNetworkInfo(int networkId, string appId = null, string appKey = null)
        {
            this.networkId = networkId;
            this.appId = appId;
            this.appKey = appKey;
        }


        override
        public string ToString()
        {

            Dictionary<string,object> dic = new Dictionary<string,object>();

            dic.Add("networkId", this.networkId);
            if(this.appId != null)
            {
                dic.Add("appId", this.appId);
            }

            if (this.appKey != null)
            {
                dic.Add("appKey", this.appKey);
            }

            string json = Json.Serialize(dic);
            return json;
        }

    }
}
