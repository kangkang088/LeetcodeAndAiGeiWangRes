﻿using System;
namespace WindMill.Advertisements
{
    public sealed class Error
    {
        public int Code { get; }
        public string Message { get; }

        public Error(int code, string message)
        {
            this.Code = code;
            this.Message = message;
        }

        public override string ToString()
        {
            return "{\"code\":" + this.Code + ",\"message\":" + this.Message + "}";

        }
    }
}
