﻿namespace WindMill.Advertisements
{
    
    public interface INativeAdClient
    {

        /***
		 * 请求广告  
		 */
        void LoadAd(int width, int height);

        /***
        * 获取广告信息
        */
        AdInfo GetAdInfo();

        /***
		 * 
		 * 设置监听回调接口
		 * 
		 * @param listener  
		 */
        void SetInteractionListener(INativeAdInteractionListener listener);

        void SetLoadListener(INativeAdLoadListener listener);

        void SetDislikeListener(INativeAdDislikeListener listener);

        void ShowAd(float x, float y);

        void Dispose();

    }
}