﻿
namespace WindMill.Advertisements
{
    public interface IRewardVideoAdListener
    {
        /// <summary>
        /// Invoke when load Ad error.
        /// </summary>
        void OnAdError(RewardVideoAd ad, Error error);

        /// <summary>
        /// Invoke when the Ad load success.
        /// </summary>
        void OnAdLoad(RewardVideoAd ad);

        // <summary>
        /// Invoke when the Ad is shown.
        /// </summary>
        void OnAdShow(RewardVideoAd ad);

        /// <summary>
        /// Invoke when the Ad video var is clicked.
        /// </summary>
        void OnAdClick(RewardVideoAd ad);

        /// <summary>
        /// Invoke when the Ad is closed.
        /// </summary>
        void OnAdReward(RewardVideoAd ad, RewardInfo info);

        /// <summary>
        /// Invoke when the Ad is closed.
        /// </summary>
        void OnAdClose(RewardVideoAd ad);

        /// <summary>
        /// Invoke when the video is complete.
        /// </summary>
        void OnVideoEnd(RewardVideoAd ad);

        /// <summary>
        /// Invoke when the video is skipped.
        /// </summary>
        void OnSkippedVideo(RewardVideoAd ad);

        /// <summary>
        /// Invoke when the video has an error.
        /// </summary>
        void OnVideoError(RewardVideoAd ad, Error error);

    }
}
