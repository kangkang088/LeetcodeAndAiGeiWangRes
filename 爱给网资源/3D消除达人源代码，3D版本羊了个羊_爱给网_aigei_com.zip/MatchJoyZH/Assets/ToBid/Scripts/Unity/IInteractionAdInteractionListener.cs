﻿namespace WindMill.Advertisements {
    /// <summary>
    /// The interaction listener for interaction Ad.
    /// </summary>
    public interface IInteractionAdInteractionListener
    {
        /// <summary>
        /// Invoke when the Ad is clicked.
        /// </summary>
        void OnAdClicked();

        /// <summary>
        /// Invoke when the Ad is shown.
        /// </summary>
        void OnAdShow();

        /// <summary>
        /// Invokw when the Ad is dissmissed.
        /// </summary>
        void OnAdDismiss();

        /// <summary>
        /// Invoke when the Ad become Hiddened.
        /// </summary>
        void onAdRemoved();
    }
}

