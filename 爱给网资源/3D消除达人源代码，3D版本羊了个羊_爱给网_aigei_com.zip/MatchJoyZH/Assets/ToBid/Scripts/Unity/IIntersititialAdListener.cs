﻿namespace WindMill.Advertisements
{
    public interface IIntersititialAdListener
    {
        /// <summary>
        /// Invoke when load Ad error.
        /// </summary>
        void OnAdError(IntersititialAd ad, Error error);

        /// <summary>
        /// Invoke when the Ad load success.
        /// </summary>
        void OnAdLoad(IntersititialAd ad);

        // <summary>
        /// Invoke when the Ad is shown.
        /// </summary>
        void OnAdShow(IntersititialAd ad);

        /// <summary>
        /// Invoke when the Ad video var is clicked.
        /// </summary>
        void OnAdClick(IntersititialAd ad);

        /// <summary>
        /// Invoke when the Ad is closed.
        /// </summary>
        void OnAdClose(IntersititialAd ad);

        /// <summary>
        /// Invoke when another controller has been closed.
        /// </summary>
        void OnAdCloseOtherVC(IntersititialAd ad );

        /// <summary>
        /// Invoke when the video is complete.
        /// </summary>
        void OnVideoEnd(IntersititialAd ad);

        /// <summary>
        /// Invoke when the video is skipped.
        /// </summary>
        void OnSkippedVideo(IntersititialAd ad);

        /// <summary>
        /// Invoke when the video has an error.
        /// </summary>
        void OnVideoError(IntersititialAd ad, Error error);



    }
}
