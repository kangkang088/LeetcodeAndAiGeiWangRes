﻿using System;
using System.Collections.Generic;

namespace WindMill.Advertisements
{
    public sealed class Request
    {

        public string PlacementId { get; set; }

        public string UserId { get; set; }

        public Dictionary<string, object> options { get; set; }
        public Request()
        {

        }
    }
}
