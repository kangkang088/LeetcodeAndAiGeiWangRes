﻿namespace WindMill.Advertisements {
    using System;
    public interface INativeAdInteractionListener
    {
        

		/***
		 * 广告展示
		 */
		void OnAdShow(NativeAdManager ad);
		/**
		 * 广告点击
		 */
		void OnAdClick(NativeAdManager ad);

		/***
		 * 视屏播放状态变化
		 */
		void OnAdVideoPlayerStatusChanged(NativeAdManager ad, MediaPlayerStatus status);

	}
}

