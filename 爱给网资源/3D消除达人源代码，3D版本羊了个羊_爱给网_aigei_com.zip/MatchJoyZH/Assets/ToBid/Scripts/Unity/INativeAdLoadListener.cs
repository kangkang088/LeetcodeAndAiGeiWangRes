﻿namespace WindMill.Advertisements
{
    using System;
    public interface INativeAdLoadListener
    {
        /***
		 * 广告请求成功
		 */
        void OnAdLoad(NativeAdManager ad);

        /***
		 * 广告请求失败
		 */
        void OnAdError(NativeAdManager ad, Error error);
    }
}
