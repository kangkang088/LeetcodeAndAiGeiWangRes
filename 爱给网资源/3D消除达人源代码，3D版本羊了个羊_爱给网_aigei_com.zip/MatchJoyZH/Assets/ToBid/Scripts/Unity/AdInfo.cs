﻿using System;
using System.Collections.Generic;
using UnityEngine;

namespace WindMill.Advertisements
{
    [System.Serializable]
    public class AdInfo{

        // 渠道id
        public WindMillAdn networkId;
        // 渠道名称
        public string networkName;
        // 渠道的广告位ID
        public string networkPlacementId;
        // 瀑布流id / 策略分组ID
        public string groupId;
        // ab分组
        public string abFlag;
        ///加载优先级
        public int loadPriority;
        // 播放优先级
        public int playPriority;
        // 单位分
        public int eCPM;
        // 货币单位
        public int currency;
        // 是否hb广告源      
        public bool isHeaderBidding;
        // 每次展示广告时生成的独立 ID，可用于排查问题
        public string loadId;
        // app自己的用户体系的id，开发者传入
        public string userId;
        // 当前广告类型
        public WindMillAdSlotType adType;
        // 广告场景id，由开发者传入
        public string scene;
        // 开发者在request中传入的options

        public string netWorkOptions;

        public Dictionary<string, object> options;

        private string jsonString;
        

        public string ToString()
        {
            return jsonString;
        }

        public static AdInfo CreateAdInfoFromJson(string jsonString)
        {
            string jsonStr = jsonString;

#if UNITY_ANDROID
            Dictionary<string, object> json = (Dictionary<string, object>)Json.Deserialize(jsonString);
            if (json != null)
            {
                object ecpm = json["eCPM"];
                if(ecpm is string)
                {
                    json["eCPM"] = 0;
                    Debug.Log("dll--ecpm " + ecpm);
                    try
                    {
                        json["eCPM"] = int.Parse(ecpm as string);
                    }
                    catch (FormatException)
                    {

                    }

                    // json["eCPM"] = int.Parse(ecpm as string);
                    jsonStr = Json.Serialize(json);
                }
            }
#endif

            AdInfo adInfo = JsonUtility.FromJson<AdInfo>(jsonStr);
            adInfo.jsonString = jsonString;
            return adInfo;

        }

        public static List<AdInfo> CreateAdInfoListFromeJson(string adInfoListString)
        {

            try
            {
                object json = Json.Deserialize(adInfoListString);
                if (json != null)
                {
                    Type type = json.GetType();
                    List<AdInfo> result = new List<AdInfo>();


                    if (type == typeof(List<object>))
                    {
                        List<object> list = (List<object>)json;
                        foreach (object item in list)
                        {

                            string adinfoJsonStr = "";
                            if (item.GetType() == typeof(string))
                            {
                                adinfoJsonStr = (string) item;
                            }
                            else
                            {
                                adinfoJsonStr = Json.Serialize(item);
                            }

                            AdInfo adInfo = AdInfo.CreateAdInfoFromJson(adinfoJsonStr);
                            if (adInfo != null)
                            {
                                result.Add(adInfo);
                            }

                        }
                    }
                    else
                    {
                        string adinfoJsonStr = Json.Serialize(json);
                        AdInfo adInfo = AdInfo.CreateAdInfoFromJson(adinfoJsonStr);
                        if (adInfo != null)
                        {
                            result.Add(adInfo);
                        }
                    }
                    return result;
                }
            }
            catch (Exception)
            {

            }
            
            return null;
        }
    }
}
