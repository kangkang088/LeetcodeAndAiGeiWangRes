﻿using System;
namespace WindMill.Advertisements
{
    public enum AgeRestrictedStatus { WindAgeRestrictedStatusUnknow = 0, WindAgeRestrictedStatusYES = 1, WindAgeRestrictedStatusNO = 2 };

    public enum ConsentStatus { WindConsentUnknown = 0, WindConsentAccepted = 1, WindConsentDenied = 2 };

    public enum MediaPlayerStatus { Initial = 0, Loading = 1, Started = 2, Paused = 3, Error = 4, Stoped = 5 };

    public enum UserAdultStatus { UserAdultUnknown = 0, UserAdult = 1, UserChild = 2 }
    public enum PersonalizedAdvertisingStatus { PersonalizedAdvertisingUnknown = 0, PersonalizedAdvertisingON = 1, PersonalizedAdvertisingOFF = 2}

    public enum WindMillAdn
    {
        WindMillAdnNoData = -2,       // 暂时无真实数据，未获取到最佳广告，一般在未展示之前提前调用
        WindMillAdnNone = 0,            // 未知adn
        WindMillAdnMTG = 1,             // Mintegral
        WindMillAdnVungle = 4,          // Vungle
        WindMillAdnApplovin = 5,        // applovin
        WindMillAdnUnityAds = 6,        // unityads
        WindMillAdnIronsource = 7,      // ironsource
        WindMillAdnSigmob = 9,          // Sigmob
        WindMillAdnAdmob = 11,          // 谷歌Admob
        WindMillAdnTapjoy = 12,         // Tapjoy
        WindMillAdnCSJ = 13,            // 穿山甲
        WindMillAdnGDT = 16,            // 腾讯广点通
        WindMillAdnKs = 19,             // 快手
        WindMillAdnKlevin = 20,         // 游可赢
        WindMillAdnBaidu = 21,          // 百度联盟
        WindMillAdnGroMore = 22,        // GroMore
        WindMillAdnBeiZi = 27,          // AdScope
        WindMillAdnPangle = 30,         // Pangle
        WindMillAdnMax = 31,            // Max
        WindMillAdnReklamup = 33,       // Reklamup
        WindMillAdnAdMate = 35,         // admate
        WindMillAdnInMobi = 37,         // InMobi
    }
    public enum WindMillAdSlotType {
        WindMillAdSlotTypeNone = 0,
        WindMillAdSlotTypeRewardVideo=1,
        WindMillAdSlotTypeSplash=2,
        WindMillAdSlotTypeIntersititial=4,
        WindMillAdSlotTypeNative=5,
        WindMillAdSlotTypeBanner=7
    } 



}
