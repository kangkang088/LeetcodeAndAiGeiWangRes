﻿using System;
namespace WindMill.Advertisements
{
    public class WindmillNetworkId
    {

        public const int Mintegral = 1;
        public const int Vungle = 4;
        public const int Applovin = 5;
        public const int UnityAds = 6;
        public const int Ironsource = 7;
        public const int Sigmob = 9;
        public const int Admob = 11;
        public const int CSJ = 13;
        public const int GDT = 16;
        public const int KuaiShou = 19;
        public const int Klevin = 20;
        public const int Baidu = 21;
        public const int GroMore = 22;
        public const int Oppo = 23;
        public const int Vivo = 24;
        public const int HuaWei = 25;
        public const int Mimo = 26;
        public const int Adscope = 27;
        public const int Qumeng = 28;
        public const int TapTap = 29;
        public const int Pangle = 30;
        public const int Max = 31;
    }

}