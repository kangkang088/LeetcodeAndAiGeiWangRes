//
//  WindMillUnityUtils.h
//  Unity-iPhone
//
//  Created by happyelements on 2022/3/31.
//

#ifndef WindMillUnityUtils_h
#define WindMillUnityUtils_h



#ifdef __cplusplus
extern "C"
{
#endif

char* ToChar(NSString *str);
id ToDictionary(const char *json);
id ToDictionaryWithString(NSString *json);
char* ToJsonString(NSObject *obj);

#ifdef __cplusplus
}
#endif
#endif /* WindMillUnityUtils_h */
