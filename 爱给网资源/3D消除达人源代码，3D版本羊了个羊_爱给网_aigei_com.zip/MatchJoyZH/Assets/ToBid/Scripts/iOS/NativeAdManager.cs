﻿namespace WindMill.Advertisements
{
#if !UNITY_EDITOR && UNITY_IOS
    using System;
    using System.Collections.Generic;
    using System.Runtime.InteropServices;
    using UnityEngine;

    public sealed class NativeAdManager : INativeAdClient
    {
        private IntPtr obj; //WindMillUnityNativeAd Instance

        private Request request;

        private INativeAdDislikeListener DislikeListener;

        private INativeAdInteractionListener InteractionListener;

        private INativeAdLoadListener LoadListener;

        private AdInfo adInfo;

        private static Dictionary<IntPtr, NativeAdManager>
            ads = new Dictionary<IntPtr, NativeAdManager>();

        private delegate void NativeAd_OnSuccessToLoad(IntPtr ptr);

        private delegate void
            NativeAd_OnErrorToLoad(int code, string message, IntPtr ptr);

        private delegate void
            NativeAd_Dislike_OnSelected


            (int index, string message, bool enforce, IntPtr ptr)
            ;

        private delegate void NativeAd_Dislike_OnCancel(IntPtr ptr);

        private delegate void NativeAd_Dislike_OnShow(IntPtr ptr);

        private delegate void NativeAd_OnImpression(IntPtr ptr);

        private delegate void NativeAd_OnClicked(IntPtr ptr);

        private delegate void
            NativeAd_OnVideoPlayerStatusChanged(int status, IntPtr ptr);

        public NativeAdManager(Request request)
        {
            this.request = request;
            this.obj = WindMillUnity_NewWindMillNativeAd();

            if (!ads.ContainsKey(this.obj))
            {
                ads.Add(this.obj, this);
            }
        }


    #region "Public Methord"

        public string PlacementId
        {
            get
            {
                return this.request.PlacementId;
            }
        }

        public void Dispose()
        {

            if (ads.ContainsKey(this.obj)) {
                ads.Remove(this.obj);
            }
            WindMillUnity_NativeAd_Dispose(this.obj);
            GC.SuppressFinalize(this);
        }

        public void LoadAd(int width, int height)
        {
            string extra = Json.Serialize(request.options);
            Debug.Log("req.options.toJson = " + extra);
            WindMillUnity_NativeAd_Load(request.PlacementId,
            request.UserId,
            width,
            height,
            extra,
            this.obj);
        }

        public AdInfo GetAdInfo()
        {
            return adInfo;
        }

        public AppInfo GetAppInfo() {
            
            return null;

        }

        public List<AdInfo> GetCacheAdInfoList(){


            string adInfoListString = WindMillUnity_NativeAd_CacheAdInfoList(this.obj);
            Debug.Log("GetCacheAdInfoList " + adInfoListString);

            return AdInfo.CreateAdInfoListFromeJson(adInfoListString);
        }
        
        private void updateAdInfo(IntPtr ptr)
        {
            if (ptr == null)
            {
                this.adInfo = null;
            }
            else
            {
                string adinfoString = WindMillUnity_NativeAd_AdInfo(ptr);
                this.adInfo = AdInfo.CreateAdInfoFromJson(adinfoString);
            }
        }

        public void ShowAd(float x, float y)
        {
            WindMillUnity_NativeAd_RenderAdToScene(this.obj, x, y);
        }

        public void ShowAd(NativeAdView nativeAdView)
        {

            string json =  nativeAdView.toJSON();
            Debug.Log("showAd nativeAdView toJSON = " + json);
 
            WindMillUnity_NativeAd_RenderNativeAdViewToScene(this.obj, nativeAdView.toJSON());
        }

        public void SetDislikeListener(INativeAdDislikeListener listener)
        {
            this.DislikeListener = listener;
            WindMillUnity_NativeAd_SetDislikeListener(this.obj,
            NativeAd_Dislike_OnSelectedMethord,
            NativeAd_Dislike_OnCancelMethord,
            NativeAd_Dislike_OnShowMethord);
        }

        public void SetInteractionListener(
            INativeAdInteractionListener listener
        )
        {
            this.InteractionListener = listener;
            WindMillUnity_NativeAd_SetAdInteractionListener(this.obj,
            NativeAd_OnImpressionMethord,
            NativeAd_OnClickedMethord,
            NativeAd_OnVideoPlayerStatusChangedMethord);
        }

        public void SetLoadListener(INativeAdLoadListener listener)
        {
            this.LoadListener = listener;
            WindMillUnity_NativeAd_SetLoadListener(this.obj,
            NativeAd_OnSuccessToLoadMethod,
            NativeAd_OnErrorToLoadMethod);
        }


    #endregion



    #region "DllImport"


        [DllImport("__Internal")]
        private static extern string WindMillUnity_NativeAd_CacheAdInfoList(IntPtr intersitialAd);

        [DllImport("__Internal")]
        private static extern string WindMillUnity_NativeAd_AdInfo(IntPtr ptr);

        [DllImport("__Internal")]
        private static extern IntPtr WindMillUnity_NewWindMillNativeAd();

        [DllImport("__Internal")]
        private static extern void WindMillUnity_NativeAd_Dispose(IntPtr ptr);

        [DllImport("__Internal")]
        private static extern void WindMillUnity_NativeAd_Load(
            string placementId,
            string userID,
            int width,
            int height,
            string extra,
            IntPtr ptr
        );

        [DllImport("__Internal")]
        private static extern void WindMillUnity_NativeAd_SetLoadListener(
            IntPtr ptr,
            NativeAd_OnSuccessToLoad OnSuccessToLoad,
            NativeAd_OnErrorToLoad OnErrorToLoad
        );

        [DllImport("__Internal")]
        private static extern void WindMillUnity_NativeAd_SetDislikeListener(
            IntPtr ptr,
            NativeAd_Dislike_OnSelected OnSelected,
            NativeAd_Dislike_OnCancel OnCancel,
            NativeAd_Dislike_OnShow OnShow
        );

        [DllImport("__Internal")]
        private
        static
        extern void WindMillUnity_NativeAd_SetAdInteractionListener(
            IntPtr ptr,
            NativeAd_OnImpression OnImpression,
            NativeAd_OnClicked OnClicked,
            NativeAd_OnVideoPlayerStatusChanged OnVideoPlayerStatusChanged
        );

        [DllImport("__Internal")]
        private static extern void WindMillUnity_NativeAd_RenderAdToScene(
            IntPtr ptr,
            float x,
            float y
        );

        [DllImport("__Internal")]
        private
        static
        extern void WindMillUnity_NativeAd_RenderNativeAdViewToScene(
            IntPtr ptr,
            string adviewJson
        );


    #endregion



    #region "Dislike Listener"
        [AOT.MonoPInvokeCallback(typeof (NativeAd_Dislike_OnSelected))]
        private static void NativeAd_Dislike_OnSelectedMethord(
            int index,
            string message,
            bool enforce,
            IntPtr ptr
        )
        {
            NativeAdManager client;
            if (ads.TryGetValue(ptr, out client))
            {
                client
                    .DislikeListener?
                    .OnSelected(client, index, message, enforce);
            }
            else
            {
                Debug.LogError("The OnAdError can not find the context");
            }
        }

        [AOT.MonoPInvokeCallback(typeof (NativeAd_Dislike_OnCancel))]
        private static void NativeAd_Dislike_OnCancelMethord(IntPtr ptr)
        {
            NativeAdManager client;
            if (ads.TryGetValue(ptr, out client))
            {
                client.DislikeListener?.OnCancel(client);
            }
            else
            {
                Debug.LogError("The OnAdError can not find the context");
            }
        }

        [AOT.MonoPInvokeCallback(typeof (NativeAd_Dislike_OnShow))]
        private static void NativeAd_Dislike_OnShowMethord(IntPtr ptr)
        {
            NativeAdManager client;
            if (ads.TryGetValue(ptr, out client))
            {
                client.DislikeListener?.OnShow(client);
            }
            else
            {
                Debug.LogError("The OnAdError can not find the context");
            }
        }
    #endregion



    #region "Interaction Listener"
        [AOT.MonoPInvokeCallback(typeof (NativeAd_OnImpression))]
        private static void NativeAd_OnImpressionMethord(IntPtr ptr)
        {
            NativeAdManager client;
            if (ads.TryGetValue(ptr, out client))
            {
                client.updateAdInfo (ptr);
                client.InteractionListener?.OnAdShow(client);
            }
            else
            {
                Debug.LogError("The OnAdError can not find the context");
            }
        }

        [AOT.MonoPInvokeCallback(typeof (NativeAd_OnClicked))]
        private static void NativeAd_OnClickedMethord(IntPtr ptr)
        {
            NativeAdManager client;
            if (ads.TryGetValue(ptr, out client))
            {
                client.InteractionListener?.OnAdClick(client);
            }
            else
            {
                Debug.LogError("The OnAdError can not find the context");
            }
        }

        [AOT.MonoPInvokeCallback(typeof (NativeAd_OnVideoPlayerStatusChanged))]
        private static void NativeAd_OnVideoPlayerStatusChangedMethord(
            int status,
            IntPtr ptr
        )
        {
            NativeAdManager client;
            if (ads.TryGetValue(ptr, out client))
            {
                MediaPlayerStatus v =
                    (MediaPlayerStatus)
                    Enum.ToObject(typeof (MediaPlayerStatus), status);
                client
                    .InteractionListener?
                    .OnAdVideoPlayerStatusChanged(client, v);
            }
            else
            {
                Debug.LogError("The OnAdError can not find the context");
            }
        }
    #endregion



    #region "Load Listener"
        [AOT.MonoPInvokeCallback(typeof (NativeAd_OnSuccessToLoad))]
        private static void NativeAd_OnSuccessToLoadMethod(IntPtr ptr)
        {
            NativeAdManager client;
            if (ads.TryGetValue(ptr, out client))
            {
                client.LoadListener?.OnAdLoad(client);
            }
            else
            {
                Debug.LogError("The OnAdError can not find the context");
            }
        }

        [AOT.MonoPInvokeCallback(typeof (NativeAd_OnErrorToLoad))]
        private static void NativeAd_OnErrorToLoadMethod(
            int code,
            string message,
            IntPtr ptr
        )
        {
            NativeAdManager client;
            if (ads.TryGetValue(ptr, out client))
            {
                Error error = new Error(code, message);
                client.LoadListener?.OnAdError(client, error);
            }
            else
            {
                Debug.LogError("The OnAdError can not find the context");
            }
        }


    #endregion

    }
#endif
}
