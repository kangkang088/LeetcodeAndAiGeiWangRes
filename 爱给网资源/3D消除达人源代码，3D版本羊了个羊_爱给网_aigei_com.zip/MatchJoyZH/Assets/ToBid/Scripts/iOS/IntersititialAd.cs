﻿namespace WindMill.Advertisements
{
#if !UNITY_EDITOR && UNITY_IOS

    using System;
    using System.Collections.Generic;
    using System.Runtime.InteropServices;
    using UnityEngine;

    public sealed class IntersititialAd : IDisposable
    {

        private static Dictionary<IntPtr, IntersititialAd> ads =
            new Dictionary<IntPtr, IntersititialAd>();

        private delegate void IntersititialAd_OnError(int code, string message, IntPtr IntersititialAd);
        private delegate void IntersititialAd_OnIntersititialAdLoad(IntPtr IntersititialAd);
        private delegate void IntersititialAd_OnAdShow(IntPtr IntersititialAd);
        private delegate void IntersititialAd_OnAdClick(IntPtr IntersititialAd);
        private delegate void IntersititialAd_OnAdSkippedVideo(IntPtr IntersititialAd);
        private delegate void IntersititialAd_OnAdClose(IntPtr IntersititialAd);
        private delegate void IntersititialAd_OnAdCloseOtherVC(IntPtr IntersititialAd);
        private delegate void IntersititialAd_OnVideoEnd(IntPtr IntersititialAd);
        private delegate void IntersititialAd_OnVideoError(int code, string message, IntPtr IntersititialAd);

       
        private IntPtr intersititialAd;
        private IIntersititialAdListener listener;
        private AdInfo adInfo;
        private Request request;
        


        public string PlacementId
        {
            get
            {
                return this.request?.PlacementId;
            }
        }

        public IntersititialAd(Request request)
        {
            this.request = request;
            this.intersititialAd = WindMillUnity_NewWindMillIntersititialAd();
            ads.Add(this.intersititialAd, this);
        }


        public void Dispose()
        {
            this.Dispose(true);
            GC.SuppressFinalize(this);
        }

        public void Dispose(bool disposing)
        {
            ads.Remove(this.intersititialAd);
            WindMillUnity_IntersititialAd_Dispose(this.intersititialAd);
        }


        public AdInfo GetAdInfo(){
           return this.adInfo; 
        }


        private void updateAdInfo(IntPtr intersitialAd){
             if(intersitialAd == null){
                 this.adInfo = null;
             }else{
                string adinfoString = WindMillUnity_IntersititialAd_AdInfo(intersitialAd);
                this.adInfo = AdInfo.CreateAdInfoFromJson(adinfoString);
             } 
        }
        /// <summary>
        /// Load reward video Ad.
        /// </summary>
        public void LoadAd()
        {
            string extra = Json.Serialize(request.options);
            Debug.Log("req.options.toJson = " + extra);
            WindMillUnity_IntersititialAd_Load(
                request.PlacementId,
                request.UserId,
                extra, this.intersititialAd);

        }

        public List<AdInfo> GetCacheAdInfoList(){
           
            string adinfoListString = WindMillUnity_IntersititialAd_CacheAdInfoList(this.intersititialAd);

            Debug.Log("GetCacheAdInfoList " + adinfoListString);

            return AdInfo.CreateAdInfoListFromeJson(adinfoListString);
        }

  
        /// <summary>
        /// Sets the interaction listener for this Ad.
        /// </summary>
        public void SetIntersititialAdListener(IIntersititialAdListener listener)
        {
            this.listener = listener;
            WindMillUnity_IntersititialAd_SetInteractionListener(
                this.intersititialAd,
                IntersititialAd_OnErrorMethod,
                IntersititialAd_OnIntersititialAdLoadMethod,
                IntersititialAd_OnAdShowMethod,
                IntersititialAd_OnAdrClickMethod,
                IntersititialAd_OnAdSkippedVideoMethod,
                IntersititialAd_OnAdCloseMethod,
                IntersititialAd_OnAdCloseOtherVCMethod,
                IntersititialAd_OnVideoEndMethod,
                IntersititialAd_OnVideoErrorMethod);
        }


        /// <summary>
        /// Show the reward video Ad.
        /// </summary>
        public void ShowAd()
        {
            WindMillUnity_IntersititialAd_ShowIntersititialAd(this.intersititialAd);
        }


        public bool Ready()
        {
            return WindMillUnity_IntersititialAd_Ready(this.intersititialAd);
        }


        [DllImport("__Internal")]
        private static extern string WindMillUnity_IntersititialAd_AdInfo(IntPtr intersitialAd);

        [DllImport("__Internal")]
        private static extern bool WindMillUnity_IntersititialAd_Ready(
            IntPtr intersitialAd);

        [DllImport("__Internal")]
        private static extern IntPtr WindMillUnity_NewWindMillIntersititialAd();

        [DllImport("__Internal")]
        private static extern string WindMillUnity_IntersititialAd_CacheAdInfoList(IntPtr intersitialAd);

        [DllImport("__Internal")]
        private static extern void WindMillUnity_IntersititialAd_Dispose(
            IntPtr intersitialAd);

        [DllImport("__Internal")]
        private static extern void WindMillUnity_IntersititialAd_Load(
            string placementId,
            string userID,
            string extra,
            IntPtr intersitialAd);


        [DllImport("__Internal")]
        private static extern void WindMillUnity_IntersititialAd_SetInteractionListener(
            IntPtr IntersititialAd,
            IntersititialAd_OnError onError,
            IntersititialAd_OnIntersititialAdLoad onIntersititialAdLoad,
            IntersititialAd_OnAdShow onAdShow,
            IntersititialAd_OnAdClick OnAdClick,
            IntersititialAd_OnAdSkippedVideo onAdSkippedVideo,
            IntersititialAd_OnAdClose onAdClose,
            IntersititialAd_OnAdCloseOtherVC OnAdCloseOtherVC,
            IntersititialAd_OnVideoEnd onVideoEnd,
            IntersititialAd_OnVideoError onVideoError);

        [DllImport("__Internal")]
        private static extern void WindMillUnity_IntersititialAd_ShowIntersititialAd(
            IntPtr intersitialAd);



        /***
         * Load Listener
         */
        [AOT.MonoPInvokeCallback(typeof(IntersititialAd_OnError))]
        private static void IntersititialAd_OnErrorMethod(int code, string message, IntPtr intersititialAd)
        {
            IntersititialAd obj;
            if (ads.TryGetValue(intersititialAd, out obj))
            {
                Error error = new Error(code, message);
                obj.listener?.OnAdError(obj, error);
            }
            else
            {
                Debug.LogError("The OnAdError can not find the context");
            }
        }


        [AOT.MonoPInvokeCallback(typeof(IntersititialAd_OnIntersititialAdLoad))]
        private static void IntersititialAd_OnIntersititialAdLoadMethod(IntPtr intersititialAd)
        {
            IntersititialAd obj;
            if (ads.TryGetValue(intersititialAd, out obj))
            {
                obj.listener?.OnAdLoad(obj);
            }
            else
            {
                Debug.LogError("The OnAdLoad can not find the context");
            }
        }


        /***
         * Interaction Listener
         */
        [AOT.MonoPInvokeCallback(typeof(IntersititialAd_OnAdShow))]
        private static void IntersititialAd_OnAdShowMethod(IntPtr intersititialAd)
        {
            IntersititialAd obj;
            if (ads.TryGetValue(intersititialAd, out obj))
            {
                obj.updateAdInfo(intersititialAd);
                obj.listener?.OnAdShow(obj);
            }
            else
            {
                Debug.LogError("The OnAdShow can not find the context.");
            }
        }

        [AOT.MonoPInvokeCallback(typeof(IntersititialAd_OnAdClick))]
        private static void IntersititialAd_OnAdrClickMethod(IntPtr intersititialAd)
        {
            IntersititialAd obj;
            if (ads.TryGetValue(intersititialAd, out obj))
            {
                obj.listener?.OnAdClick(obj);
            }
            else
            {
                Debug.LogError("The OnAdClick can not find the context.");
            }
        }

        [AOT.MonoPInvokeCallback(typeof(IntersititialAd_OnAdSkippedVideo))]
        private static void IntersititialAd_OnAdSkippedVideoMethod(IntPtr intersititialAd)
        {
            IntersititialAd obj;
            if (ads.TryGetValue(intersititialAd, out obj))
            {
                obj.listener?.OnSkippedVideo(obj);
            }
            else
            {
                Debug.LogError("The OnSkippedVideo can not find the context.");
            }
        }


        [AOT.MonoPInvokeCallback(typeof(IntersititialAd_OnAdClose))]
        private static void IntersititialAd_OnAdCloseMethod(IntPtr intersititialAd)
        {
            IntersititialAd obj;
            if (ads.TryGetValue(intersititialAd, out obj))
            {
                obj.listener?.OnAdClose(obj);
            }
            else
            {
                Debug.LogError("The OnAdClose can not find the context.");
            }
        }

        [AOT.MonoPInvokeCallback(typeof(IntersititialAd_OnAdCloseOtherVC))]
        private static void IntersititialAd_OnAdCloseOtherVCMethod(IntPtr intersititialAd)
        {
            IntersititialAd obj;
            if (ads.TryGetValue(intersititialAd, out obj))
            {
                obj.listener?.OnAdCloseOtherVC(obj);
            }
            else
            {
                Debug.LogError("The OnAdCloseOtherVC can not find the context.");
            }
        }

        [AOT.MonoPInvokeCallback(typeof(IntersititialAd_OnVideoEnd))]
        private static void IntersititialAd_OnVideoEndMethod(IntPtr intersititialAd)
        {
            IntersititialAd obj;
            if (ads.TryGetValue(intersititialAd, out obj))
            {
                obj.listener?.OnVideoEnd(obj);
            }
            else
            {
                Debug.LogError(
                    "The OnVideoEnd can not find the context.");
            }
        }


        [AOT.MonoPInvokeCallback(typeof(IntersititialAd_OnVideoError))]
        private static void IntersititialAd_OnVideoErrorMethod(int code, string message, IntPtr intersititialAd)
        {
            IntersititialAd obj;
            if (ads.TryGetValue(intersititialAd, out obj))
            {
                Error error = new Error(code, message);
                obj.listener?.OnVideoError(obj ,error);
            }
            else
            {
                Debug.LogError(
                    "The OnVideoError can not find the context.");
            }
        }
    }
#endif

}