//
//  WindMillUnityAdInfo.mm
//  WindMillSDK
//
//  Created by Codi on 2021/5/20.
//  Copyright © 2021 Codi. All rights reserved.
//

#import <WindMillSDK/WindMillSDK.h>

@interface WindMillUnityAdInfo : NSObject
@property (nonatomic, strong) WindMillAdInfo *adInfo;
@end

@implementation WindMillUnityAdInfo

- (void)dealloc {
    self.adInfo = nil;
}


@end


#if defined (__cplusplus)
extern "C" {
#endif

void* WindMillUnity_NewAdInfo(WindMillAdInfo *adInfo) {
    WindMillUnityAdInfo *instance = [[WindMillUnityAdInfo alloc] init];
    instance.adInfo = adInfo;
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Wunused-value"
    //retainCount +1
    (__bridge_retained void*)instance;
#pragma clang diagnostic pop
    return (__bridge void*)instance;
}


long WindMillUnity_AdInfo_NetWorkId(void* adInfoPtr) {
    WindMillUnityAdInfo* instance = (__bridge WindMillUnityAdInfo *)adInfoPtr;
    return instance.adInfo.networkId;
}

const char* WindMillUnity_AdInfo_NetWorkName(void* adInfoPtr) {
    WindMillUnityAdInfo* instance = (__bridge WindMillUnityAdInfo *)adInfoPtr;
    return [instance.adInfo.networkName UTF8String];
}
const char* WindMillUnity_AdInfo_NetWorkPlacementId(void* adInfoPtr) {
    WindMillUnityAdInfo* instance = (__bridge WindMillUnityAdInfo *)adInfoPtr;
    return [instance.adInfo.networkPlacementId UTF8String];
}

const char* WindMillUnity_AdInfo_GroupId(void* adInfoPtr) {
    WindMillUnityAdInfo* instance = (__bridge WindMillUnityAdInfo *)adInfoPtr;
    return [instance.adInfo.groupId UTF8String];
}

long WindMillUnity_AdInfo_ABFlag(void* adInfoPtr) {
    WindMillUnityAdInfo* instance = (__bridge WindMillUnityAdInfo *)adInfoPtr;
    return instance.adInfo.abFlag;
}

long WindMillUnity_AdInfo_LoadPriority(void* adInfoPtr) {
    WindMillUnityAdInfo* instance = (__bridge WindMillUnityAdInfo *)adInfoPtr;
    return instance.adInfo.loadPriority;
}

long WindMillUnity_AdInfo_PlayPriority(void* adInfoPtr) {
    WindMillUnityAdInfo* instance = (__bridge WindMillUnityAdInfo *)adInfoPtr;
    return instance.adInfo.playPriority;
}


long WindMillUnity_AdInfo_ECPM(void* adInfoPtr) {
    WindMillUnityAdInfo* instance = (__bridge WindMillUnityAdInfo *)adInfoPtr;
    return instance.adInfo.eCPM;
}

const char * WindMillUnity_AdInfo_Currency(void* adInfoPtr) {
    WindMillUnityAdInfo* instance = (__bridge WindMillUnityAdInfo *)adInfoPtr;
    return [instance.adInfo.currency UTF8String];
}


BOOL WindMillUnity_AdInfo_IsHeaderBidding(void* adInfoPtr) {
    WindMillUnityAdInfo* instance = (__bridge WindMillUnityAdInfo *)adInfoPtr;
    return instance.adInfo.isHeaderBidding;
}

const char * WindMillUnity_AdInfo_LoadId(void* adInfoPtr) {
    WindMillUnityAdInfo* instance = (__bridge WindMillUnityAdInfo *)adInfoPtr;
    return [instance.adInfo.loadId UTF8String];
}

const char * WindMillUnity_AdInfo_UserId(void* adInfoPtr) {
    WindMillUnityAdInfo* instance = (__bridge WindMillUnityAdInfo *)adInfoPtr;
    return [instance.adInfo.userId UTF8String];
}

const char * WindMillUnity_AdInfo_Scene(void* adInfoPtr) {
    WindMillUnityAdInfo* instance = (__bridge WindMillUnityAdInfo *)adInfoPtr;
    return [instance.adInfo.scene UTF8String];
}

const char * WindMillUnity_AdInfo_Options(void* adInfoPtr) {
    WindMillUnityAdInfo* instance = (__bridge WindMillUnityAdInfo *)adInfoPtr;
    NSData *jsonData = [NSJSONSerialization dataWithJSONObject:instance.adInfo.options options:0 error:0];
    NSString *dataStr = [[NSString alloc] initWithData:jsonData encoding:NSUTF8StringEncoding];
    
    return [dataStr UTF8String];
}
    
#if defined (__cplusplus)
}
#endif


