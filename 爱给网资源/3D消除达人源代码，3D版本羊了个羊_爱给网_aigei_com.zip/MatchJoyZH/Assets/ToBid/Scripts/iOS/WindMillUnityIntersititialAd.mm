//
//  WindMillUnityIntersititialAd.mm
//  WindMillSDK
//
//  Created by Codi on 2021/5/20.
//  Copyright © 2021 Codi. All rights reserved.
//

#import <WindMillSDK/WindMillSDK.h>
#include "WindMillUnityUtils.h"

// IIntersititialAdListener callbacks.
typedef void(*IntersititialAd_OnError)(int code, const char* message, void* intersititialAd);
typedef void(*IntersititialAd_OnIntersititialAdLoad)(void* intersititialAd);

// IRewardAdInteractionListener callbacks.
typedef void(*IntersititialAd_OnAdShow)(void* intersititialAd);
typedef void(*IntersititialAd_OnAdClick)(void* intersititialAd);
typedef void(*IntersititialAd_OnAdSkippedVideo)(void* intersititialAd);
typedef void(*IntersititialAd_OnAdClose)(void* intersititialAd);
typedef void(*IntersititialAd_OnAdCloseOtherVC)(void* intersititialAd);
typedef void(*IntersititialAd_OnVideoEnd)(void* intersititialAd);
typedef void(*IntersititialAd_OnVideoError)(int code, const char* message,void* intersititialAd);


@interface WindMillUnityIntersititialAd : NSObject<WindMillIntersititialAdDelegate>
@property (nonatomic, strong) WindMillIntersititialAd *intersititialAd;
@property (nonatomic, assign) IntersititialAd_OnError onError;
@property (nonatomic, assign) IntersititialAd_OnIntersititialAdLoad onIntersititialAdLoad;
@property (nonatomic, assign) IntersititialAd_OnAdShow onAdShow;
@property (nonatomic, assign) IntersititialAd_OnAdClick onAdClick;
@property (nonatomic, assign) IntersititialAd_OnAdSkippedVideo onAdSkippedVideo;
@property (nonatomic, assign) IntersititialAd_OnAdClose onAdClose;
@property (nonatomic, assign) IntersititialAd_OnAdCloseOtherVC onAdCloseOtherVC;
@property (nonatomic, assign) IntersititialAd_OnVideoEnd onVideoEnd;
@property (nonatomic, assign) IntersititialAd_OnVideoError onVideoError;
@end

@implementation WindMillUnityIntersititialAd

#pragma mark -  WindMillIntersititialAdDelegate

/**
 This method is called when video ad material loaded successfully.
 */
- (void)intersititialAdDidLoad:(WindMillIntersititialAd *)intersititialAd {
    if (self.onIntersititialAdLoad) {
        self.onIntersititialAdLoad((__bridge void*)self);
    }
}

/**
 This method is called when video ad materia failed to load.
 @param error : the reason of error
 */
- (void)intersititialAdDidLoad:(WindMillIntersititialAd *)intersititialAd didFailWithError:(NSError *)error {
    if (self.onError) {
        self.onError((int)error.code, [error.localizedDescription UTF8String], (__bridge void*)self);
    }
}

/**
 This method is called when video ad slot will be showing.
 */
- (void)intersititialAdWillVisible:(WindMillIntersititialAd *)intersititialAd {
    
}

/**
 This method is called when video ad slot has been shown.
 */
- (void)intersititialAdDidVisible:(WindMillIntersititialAd *)intersititialAd {
    if (self.onAdShow) {
        self.onAdShow((__bridge void*)self);
    }
}

/**
 This method is called when video ad is clicked.
 */
- (void)intersititialAdDidClick:(WindMillIntersititialAd *)intersititialAd {
    if (self.onAdClick) {
        self.onAdClick((__bridge void*)self);
    }
}

/**
 This method is called when video ad is clicked skip button.
 */
- (void)intersititialAdDidClickSkip:(WindMillIntersititialAd *)intersititialAd {
    if (self.onAdSkippedVideo) {
        self.onAdSkippedVideo((__bridge void*)self);
    }
}

/**
 This method is called when video ad is about to close.
 */
- (void)intersititialAdDidClose:(WindMillIntersititialAd *)intersititialAd {
    if (self.onAdClose) {
        self.onAdClose((__bridge void*)self);
    }
}

/**
 This method is called when another controller has been closed.
 @param interactionType : open appstore in app or open the webpage or view video ad details page.
 @Note :  Mediation dimension does not support this callBack.
 */
- (void)intersititialAdDidCloseOtherController:(WindMillIntersititialAd *)intersititialAd withInteractionType:(WindMillInteractionType)interactionType {
    if (self.onAdCloseOtherVC) {
        self.onAdCloseOtherVC((__bridge void*)self);
    }
}


/**
 This method is called when video ad play completed or an error occurred.
 @param error : the reason of error
 */
- (void)intersititialAdDidPlayFinish:(WindMillIntersititialAd *)intersititialAd didFailWithError:(NSError *)error {
    if (error) {
        self.onVideoError((int)error.code, [error.localizedDescription UTF8String], (__bridge void*)self);
    }else {
        self.onVideoEnd((__bridge void*)self);
    }
}

/**
 This method is called when return ads from sigmob ad server.
 */
- (void)intersititialAdServerResponse:(WindMillIntersititialAd *)intersititialAd isFillAd:(BOOL)isFillAd {
    //    NSLog(@"[WindMillDemo] %s -- isFillAd = %d, placementId = %@,", __func__, isFillAd, intersititialAd.placementId);
    
}

- (void)dealloc {
    self.intersititialAd.delegate = nil;
    self.intersititialAd = nil;
}


@end


#if defined (__cplusplus)
extern "C" {
#endif


extern UIViewController * UnityGetGLViewController(void);


void* WindMillUnity_NewWindMillIntersititialAd(){
    WindMillUnityIntersititialAd *instance = [[WindMillUnityIntersititialAd alloc] init];
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Wunused-value"
    //retainCount +1
    (__bridge_retained void*)instance;
#pragma clang diagnostic pop
    return (__bridge void*)instance;
}


void WindMillUnity_IntersititialAd_Load
(
 const char* placementId,
 const char* userID,
 const char* extra,
 void* intersititialAdPtr
 ) {
    WindMillAdRequest *request = [[WindMillAdRequest alloc] init];
    request.userId = [[NSString alloc] initWithUTF8String:userID?:"-2"];
    request.placementId = [[NSString alloc] initWithUTF8String:placementId?:""];
    NSDictionary *dic = ToDictionary(extra);
    if(dic != nil){
        request.options = dic;
    }
    WindMillUnityIntersititialAd* instance = (__bridge WindMillUnityIntersititialAd *)intersititialAdPtr;
    WindMillIntersititialAd *intersititialAd = instance.intersititialAd;
    if (intersititialAd == nil) {
        intersititialAd = [[WindMillIntersititialAd alloc] initWithRequest:request];
        instance.intersititialAd = intersititialAd;
    }
    instance.intersititialAd = intersititialAd;
    intersititialAd.delegate = instance;
    [intersititialAd loadAdData];
}


const char* WindMillUnity_IntersititialAd_CacheAdInfoList(void* ptr) {
    WindMillUnityIntersititialAd* instance = (__bridge WindMillUnityIntersititialAd *)ptr;
    WindMillIntersititialAd *intersititialAd = instance.intersititialAd;
    
    if(intersititialAd != nil){
        NSArray* adInfoList = [intersititialAd getCacheAdInfoList];
        if(adInfoList != NULL && adInfoList.count>0){
            NSMutableArray *list =  [[NSMutableArray alloc] initWithCapacity:adInfoList.count];

            for (WindMillAdInfo *item in adInfoList) {
                [list addObject:[item toJson]];                
            }
            return ToJsonString(list);
        }
    }
    
    return NULL;
    
}

void WindMillUnity_IntersititialAd_SetInteractionListener
 (
  void* intersititialAdPtr,
  IntersititialAd_OnError onError,
  IntersititialAd_OnIntersititialAdLoad onIntersititialAdLoad,
  IntersititialAd_OnAdShow onAdShow,
  IntersititialAd_OnAdClick onAdClick,
  IntersititialAd_OnAdSkippedVideo onAdSkippedVideo,
  IntersititialAd_OnAdClose onAdClose,
  IntersititialAd_OnAdCloseOtherVC onAdCloseOtherVC,
  IntersititialAd_OnVideoEnd onVideoEnd,
  IntersititialAd_OnVideoError onVideoError
  ) {
    WindMillUnityIntersititialAd* instance = (__bridge WindMillUnityIntersititialAd *)intersititialAdPtr;
    instance.onError = onError;
    instance.onIntersititialAdLoad = onIntersititialAdLoad;
    instance.onAdShow = onAdShow;
    instance.onAdClick = onAdClick;
    instance.onAdSkippedVideo = onAdSkippedVideo;
    instance.onAdClose = onAdClose;
    instance.onAdCloseOtherVC = onAdCloseOtherVC;
    instance.onVideoEnd = onVideoEnd;
    instance.onVideoError = onVideoError;
}


BOOL WindMillUnity_IntersititialAd_Ready(void* intersititialAdPtr) {
    WindMillUnityIntersititialAd* instance = (__bridge WindMillUnityIntersititialAd *)intersititialAdPtr;
    return [instance.intersititialAd isAdReady];
}

 const char* WindMillUnity_IntersititialAd_AdInfo(void* intersititialAdPtr) {
     WindMillUnityIntersititialAd* instance = (__bridge WindMillUnityIntersititialAd *)intersititialAdPtr;
    return ToChar([instance.intersititialAd.adInfo toJson]);
 }

void WindMillUnity_IntersititialAd_ShowIntersititialAd(void* intersititialAdPtr) {
    WindMillUnityIntersititialAd* instance = (__bridge WindMillUnityIntersititialAd *)intersititialAdPtr;
    [instance.intersititialAd showAdFromRootViewController:UnityGetGLViewController() options:nil];
}

void WindMillUnity_IntersititialAd_Dispose(void* intersititialAdPtr) {
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Wunused-value"
    (__bridge_transfer WindMillUnityIntersititialAd *)intersititialAdPtr;
#pragma clang diagnostic pop
}



#if defined (__cplusplus)
}
#endif


