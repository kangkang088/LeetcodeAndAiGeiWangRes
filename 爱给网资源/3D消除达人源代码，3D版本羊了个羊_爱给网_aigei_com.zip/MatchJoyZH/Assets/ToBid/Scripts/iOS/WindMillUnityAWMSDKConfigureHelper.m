//
//  WindMillUnityAWMSDKConfigureHelper.m
//  UnityFramework
//
//  Created by happyelements on 2023/7/24.
//

#import <Foundation/Foundation.h>
#import <WindMillSDK/WindMillSDK.h>


@implementation WindMillUnityAWMSDKConfigureHelper : NSObject


+ (AWMSDKConfigure *)getAWMSDKConfigureWithAdnId:(NSNumber *)adnId
                        appid:(NSString *)appId
                          appKey:(NSString *)appKey{
    
    
    AWMSDKConfigure *conf = [[AWMSDKConfigure alloc] initWithAdnId:[adnId intValue] appid:appId appKey:appKey];
    return conf;
    
}

@end
