//
//  WindMillUnityAds.m
//  WindMillSDK
//
//  Created by Codi on 2021/5/20.
//  Copyright © 2021 Codi. All rights reserved.
//

#import <WindMillSDK/WindMillSDK.h>
#import "WindMillUnityUtils.h"
#import "WindMillUnityCustomDevInfo.h"
#import "WindMillUnityAWMSDKConfigureHelper.h"


#if defined(__cplusplus)
extern "C"{
#endif
NSMutableArray * sdkConfigures;
void WindMillUnity_StartWithOptions(char *appId) {
    
    [WindMillAds setupSDKWithAppId:appId == nil?@"":[NSString stringWithUTF8String:appId] sdkConfigures:sdkConfigures];
}

void WindMillUnity_SetDebugEnable(bool enable) {
    [WindMillAds setDebugEnable:enable];
}


void WindMillUnity_InitCustomGroup(char *customGroup) {
    
    NSDictionary *dic = ToDictionary(customGroup);
    if(dic != nil){
       [WindMillAds initCustomGroup:dic];
    }
}

void WindMillUnity_InitCustomGroupForPlacementId(char* placementId,char *customGroup) {
    
    NSDictionary *dic = ToDictionary(customGroup);
    if(dic != nil){
       [WindMillAds initCustomGroup:dic forPlacementId: [NSString stringWithUTF8String:placementId]  ];
    }
}

void WindMillUnity_SetExt(char *ext) {
    NSDictionary *dic = ToDictionary(ext);
    if(dic != nil){
        [WindMillAds setExt:dic];
    }
}

void WindMillUnity_networkPreInit(char* json) {
    id item = ToDictionary(json);
    
    if(item != nil){
        if ([item isKindOfClass:[NSDictionary class]]) {
            
        }else if ([item isKindOfClass:[NSArray class]]){
            NSArray *list = (NSArray *)item;
            sdkConfigures = [[NSMutableArray alloc] init];

            for (NSObject *obj in list) {
                
                if([obj isKindOfClass:[NSString class]]){
                    id adnInitConfig = ToDictionaryWithString((NSString*)obj);
                    
                    if(adnInitConfig != nil){
                        
                        if ([adnInitConfig isKindOfClass:[NSDictionary class]]) {
                            
                            NSDictionary *dic = (NSDictionary *)adnInitConfig;
                            
                            NSNumber *networkId = dic[@"networkId"];
                            
                            NSString *appId = dic[@"appId"];
                            NSString *appKey = dic[@"appKey"];
                            
                            if(networkId != nil && networkId != [NSNull null]){
                                
                                NSLog(@"networkId %@ appId %@ appKey %@",networkId,appId,appKey);
                                AWMSDKConfigure * conf = [WindMillUnityAWMSDKConfigureHelper getAWMSDKConfigureWithAdnId:networkId appid:appId appKey:appKey];
                                [sdkConfigures addObject:conf];
                            }
                        }
                    }
                    
                }
            }
        }else {
            
        }
    }

}

void WindMillUnity_setPresetLocalStrategyPath(char* path){

    NSString* bundleName = [NSString stringWithUTF8String:path];
    
    if(bundleName != nil){
        
        NSBundle *bundle;
        NSString *bundlePath = [[NSBundle mainBundle] pathForResource:bundleName ofType:@"bundle"];
        
        if([[NSFileManager defaultManager] fileExistsAtPath:bundlePath]){
                       bundle = [NSBundle bundleWithPath:bundlePath];
        }else{
                       NSLog(@"error: bundle %@ not exist",bundleName);
        }
        if(bundle != nil){
            NSLog(@"setPresetPlacementConfigPathBundle bundle: %@ sccess",bundleName);
            [WindMillAds setPresetPlacementConfigPathBundle:bundle];
        }

    }
}

void WindMillUnity_SetCustomDeviceController(bool isCanUseLocation,float latitude, float longitude, bool isCanUseIdfa, char* devIdfa){
    
    WindMillUnityCustomDevInfo *devInfo =  [[WindMillUnityCustomDevInfo alloc] init];
    devInfo.canUseIdfa = isCanUseIdfa;
    if(devIdfa != NULL){
        devInfo.customIDFA = [NSString stringWithUTF8String:devIdfa];
    }
    
    AWMLocation *location = [[AWMLocation alloc] init];
    location.latitude = latitude;
    location.longitude = longitude;
    
    devInfo.customLocation = location;
    devInfo.canUseLocation = isCanUseLocation;

    [WindMillAds setCustomDeviceController:devInfo];
}


/**************************  Coppa *********************************/

WindMillAgeRestrictedStatus WindMillUnity_GetAgeRestrictedStatus() {
    return [WindMillAds getAgeRestrictedStatus];
}

void WindMillUnity_SetIsAgeRestrictedUser(NSUInteger status) {
    WindMillAgeRestrictedStatus ageStatus = (WindMillAgeRestrictedStatus)status;
    [WindMillAds setIsAgeRestrictedUser:ageStatus];
}

/**************************  GDPR  *********************************/
void WindMillUnity_SetUserGDPRConsentStatus(int32_t status) {
    WindMillConsentStatus consentStatus = (WindMillConsentStatus)status;
    [WindMillAds setUserGDPRConsentStatus:consentStatus];
}

WindMillConsentStatus WindMillUnity_GetUserGDPRConsentStatus() {
    return [WindMillAds getUserGDPRConsentStatus];
}

/**************************  Age *********************************/
NSUInteger WindMillUnity_GetUserAge() {
    return [WindMillAds getUserAge];
}

void WindMillUnity_SetUserAge(NSUInteger age) {
    [WindMillAds setUserAge:age];
}

void WindMillUnity_SetUserAdultStatus(int32_t status) {
    WindMillAdultState state = (WindMillAdultState)status;
    [WindMillAds setAdult:state];
}

void WindMillUnity_SetPersonalizedAdvertisingStatus(int32_t status) {
    if(status == 2){
        status = 1;
    } else {
        status = 0;
    }  
    WindMillPersonalizedAdvertisingState state = (WindMillPersonalizedAdvertisingState)status;
    [WindMillAds setPersonalizedAdvertising:state];
}

/**************************  sdk version *********************************/
char * WindMillUnity_SdkVersion() {
    return  ToChar([WindMillAds sdkVersion]);
}

#if defined(__cplusplus)
}
#endif



