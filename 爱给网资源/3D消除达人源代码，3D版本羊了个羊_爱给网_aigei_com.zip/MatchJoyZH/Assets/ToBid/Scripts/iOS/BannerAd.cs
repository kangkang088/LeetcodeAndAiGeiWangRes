﻿namespace WindMill.Advertisements
{
#if !UNITY_EDITOR &&  UNITY_IOS

    using System;
    using System.Collections.Generic;
    using System.Runtime.InteropServices;
    using UnityEngine;

    public sealed class BannerAd : IDisposable
    {

        private static Dictionary<IntPtr, BannerAd> ads =
            new Dictionary<IntPtr, BannerAd>();

        private delegate void BannerAd_OnError(int code, string message, IntPtr BannerAd);
        private delegate void BannerAd_OnAdLoad(IntPtr BannerAd);
        private delegate void BannerAd_OnAdShow(IntPtr BannerAd);
        private delegate void BannerAd_OnAdClick(IntPtr BannerAd);
        private delegate void BannerAd_OnAdClose(IntPtr BannerAd);
        private delegate void BannerAd_OnAdAutoRefreshed(IntPtr BannerAd);
        private delegate void BannerAd_OnAdAutoRefreshFail(int code, string message,IntPtr BannerAd);

       
        private IntPtr bannerAd;
        private IBannerAdListener listener;
        private AdInfo adInfo;
        private Request request;
        


        public string PlacementId
        {
            get
            {
                return this.request?.PlacementId;
            }
        }

        public BannerAd(Request request)
        {
            this.request = request;
            this.bannerAd  = WindMillUnity_NewWindMillBannerAdView();
            ads.Add(this.bannerAd , this);
        }


        public void Dispose()
        {
            HideAd();
            this.Dispose(true);
            GC.SuppressFinalize(this);
        }

        public void Dispose(bool disposing)
        {
            ads.Remove(this.bannerAd );
            WindMillUnity_BannerAd_Dispose(this.bannerAd );
        }


        public AdInfo GetAdInfo(){
           return this.adInfo; 
        }


        private void updateAdInfo(IntPtr bannerAd){
             if(bannerAd == null){
                 this.adInfo = null;
             }else{
                string adinfoString = WindMillUnity_BannerAd_AdInfo(bannerAd);
                this.adInfo = AdInfo.CreateAdInfoFromJson(adinfoString);
             } 
        }
        /// <summary>
        /// Load reward video Ad.
        /// </summary>
        public void LoadAd()
        {
            string extra =  Json.Serialize(request.options);
            Debug.Log("req.options.toJson = " + extra);
            WindMillUnity_BannerAd_Load(
                request.PlacementId,
                request.UserId,
                0,0,
                extra, this.bannerAd );

        }


        public void LoadAd(int width, int height)
        {
            string extra =  Json.Serialize(request.options);
            Debug.Log("req.options.toJson = " + extra);
            WindMillUnity_BannerAd_Load(
                request.PlacementId,
                request.UserId,
                width,
                height,
                extra, this.bannerAd );
        }

         public List<AdInfo> GetCacheAdInfoList(){

            string adInfoListString = WindMillUnity_BannerAd_CacheAdInfoList(bannerAd);


            Debug.Log("GetCacheAdInfoList "+ adInfoListString);

            return AdInfo.CreateAdInfoListFromeJson(adInfoListString);
        }



        public void HideAd(){
           WindMillUnity_BannerAd_HideAd(this.bannerAd ); 
        }



        /// <summary>
        /// Sets the interaction listener for this Ad.
        /// </summary>
        public void SetBannerAdListener(IBannerAdListener listener)
        {
            this.listener = listener;
            WindMillUnity_BannerAd_SetInteractionListener(
                this.bannerAd ,
                BannerAd_OnErrorMethod,
                BannerAd_OnAdLoadMethod,
                BannerAd_OnAdShowMethod,
                BannerAd_OnAdrClickMethod,
                BannerAd_OnAdCloseMethod,
                BannerAd_OnAdAutoRefreshedMethod,
                BannerAd_OnAdAutoRefreshFailMethod);
        }


        /// <summary>
        /// Show the reward video Ad.
        /// </summary>
        public void ShowAd(Rect rect)
        {
            WindMillUnity_BannerAd_ShowBannerAd(this.bannerAd ,(int)rect.x, (int)rect.y,(int)rect.width,(int)rect.height);
        }


        public bool Ready()
        {
            return WindMillUnity_BannerAd_Ready(this.bannerAd );
        }


        [DllImport("__Internal")]
        private static extern string WindMillUnity_BannerAd_AdInfo(IntPtr bannerAd);

        [DllImport("__Internal")]
        private static extern string WindMillUnity_BannerAd_CacheAdInfoList(IntPtr bannerAd);

        [DllImport("__Internal")]
        private static extern bool WindMillUnity_BannerAd_Ready(
            IntPtr bannerAd);

        [DllImport("__Internal")]
        private static extern IntPtr WindMillUnity_NewWindMillBannerAdView();
        
        [DllImport("__Internal")]
        private static extern IntPtr WindMillUnity_BannerAd_HideAd(IntPtr bannerAd);

        [DllImport("__Internal")]
        private static extern void WindMillUnity_BannerAd_Dispose(
            IntPtr bannerAd);

        [DllImport("__Internal")]
        private static extern void WindMillUnity_BannerAd_Load(
            string placementId,
            string userID,
            int width,
            int height,
            string extra,
            IntPtr bannerAd);

        [DllImport("__Internal")]
        private static extern void WindMillUnity_BannerAd_SetInteractionListener(
            IntPtr BannerAd,
            BannerAd_OnError onError,
            BannerAd_OnAdLoad onAdLoad,
            BannerAd_OnAdShow onAdShow,
            BannerAd_OnAdClick OnAdClick,
            BannerAd_OnAdClose onAdClose,
            BannerAd_OnAdAutoRefreshed onAdAutoRefreshed,
            BannerAd_OnAdAutoRefreshFail onAdAutoRefreshFail);

        [DllImport("__Internal")]
        private static extern void WindMillUnity_BannerAd_ShowBannerAd(
            IntPtr bannerAd,int x, int y, int width, int height);



        /***
         * Load Listener
         */
        [AOT.MonoPInvokeCallback(typeof(BannerAd_OnError))]
        private static void BannerAd_OnErrorMethod(int code, string message, IntPtr BannerAd)
        {
            BannerAd obj;
            if (ads.TryGetValue(BannerAd, out obj))
            {
                Error error = new Error(code, message);
                obj.listener?.OnAdError(obj, error);
            }
            else
            {
                Debug.LogError("The OnAdError can not find the context");
            }
        }


        [AOT.MonoPInvokeCallback(typeof(BannerAd_OnAdLoad))]
        private static void BannerAd_OnAdLoadMethod(IntPtr BannerAd)
        {
            BannerAd obj;
            if (ads.TryGetValue(BannerAd, out obj))
            {
                obj.listener?.OnAdLoad(obj);
            }
            else
            {
                Debug.LogError("The OnAdLoad can not find the context");
            }
        }


        /***
         * Interaction Listener
         */
        [AOT.MonoPInvokeCallback(typeof(BannerAd_OnAdShow))]
        private static void BannerAd_OnAdShowMethod(IntPtr BannerAd)
        {
            BannerAd obj;
            if (ads.TryGetValue(BannerAd, out obj))
            {
                obj.updateAdInfo(BannerAd);
                obj.listener?.OnAdShow(obj);
            }
            else
            {
                Debug.LogError("The OnAdShow can not find the context.");
            }
        }

        [AOT.MonoPInvokeCallback(typeof(BannerAd_OnAdClick))]
        private static void BannerAd_OnAdrClickMethod(IntPtr BannerAd)
        {
            BannerAd obj;
            if (ads.TryGetValue(BannerAd, out obj))
            {
                obj.listener?.OnAdClick(obj);
            }
            else
            {
                Debug.LogError("The OnAdClick can not find the context.");
            }
        }

        


        [AOT.MonoPInvokeCallback(typeof(BannerAd_OnAdClose))]
        private static void BannerAd_OnAdCloseMethod(IntPtr BannerAd)
        {
            BannerAd obj;
            if (ads.TryGetValue(BannerAd, out obj))
            {
                obj.listener?.OnAdClose(obj);
            }
            else
            {
                Debug.LogError("The OnAdClose can not find the context.");
            }
        }


        [AOT.MonoPInvokeCallback(typeof(BannerAd_OnAdAutoRefreshed))]
        private static void BannerAd_OnAdAutoRefreshedMethod(IntPtr BannerAd)
        {
            BannerAd obj;
            if (ads.TryGetValue(BannerAd, out obj))
            {
                obj.listener?.OnAdAutoRefreshed(obj);
            }
            else
            {
                Debug.LogError(
                    "The OnAdAutoRefreshed can not find the context.");
            }
        }


        [AOT.MonoPInvokeCallback(typeof(BannerAd_OnAdAutoRefreshFail))]
        private static void BannerAd_OnAdAutoRefreshFailMethod(int code, string message, IntPtr BannerAd)
        {
            BannerAd obj;
            if (ads.TryGetValue(BannerAd, out obj))
            {
                Error error = new Error(code, message);
                obj.listener?.OnAdAutoRefreshFail(obj ,error);
            }
            else
            {
                Debug.LogError(
                    "The onAdAutoRefreshFail can not find the context.");
            }
        }
    }
#endif

}