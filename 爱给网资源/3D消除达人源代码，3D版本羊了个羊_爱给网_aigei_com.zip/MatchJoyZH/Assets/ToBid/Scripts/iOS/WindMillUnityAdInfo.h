//
//  WindMillUnityAdInfo.h
//  Unity-iPhone
//
//  Created by happyelements on 2022/3/30.
//

#ifndef WindMillUnityAdInfo_h
#define WindMillUnityAdInfo_h

#ifdef __cplusplus
extern "C"
{
#endif

void* WindMillUnity_NewAdInfo(WindMillAdInfo *adInfo);

#ifdef __cplusplus
}
#endif /* PlatformInterface_h */

#endif /* WindMillUnityAdInfo_h */
