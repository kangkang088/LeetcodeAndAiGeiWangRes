//
//  WindMillUnityNativeAd.m
//  WindMillSDK
//
//  Created by Codi on 2021/10/12.
//  Copyright © 2021 Codi. All rights reserved.
//
#import <UIKit/UIKit.h>
#import <Foundation/Foundation.h>
#import <WindFoundation/WindFoundation.h>
#import <WindMillSDK/WindMillSDK.h>
#import <WindMillSDK/WindMillDislikeWords.h>
#include "WindMillUnityUtils.h"

typedef void(*NativeAd_SuccessToLoad)(void* ptr);
typedef void(*NativeAd_DidFailToLoad)(int code, const char* message, void* ptr);

typedef void(*NativeAd_OnImpression)(void* ptr);
typedef void(*NativeAd_OnClicked)(void* ptr);
typedef void(*NativeAd_OnVideoPlayerStatusChanged)(int status, void* ptr);

typedef void(*NativeAd_Dislike_OnSelected)(int index, const char *message, bool enforce, void* ptr);
typedef void(*NativeAd_Dislike_OnCancel)(void* ptr);
typedef void(*NativeAd_Dislike_OnShow)(void* ptr);

#if defined (__cplusplus)
extern "C" {
#endif

    extern UIViewController * UnityGetGLViewController(void);


#if defined (__cplusplus)
}
#endif


@interface  ViewConfigItem : NSObject
@property (nonatomic,strong) NSDictionary *viewConfigDic;

-(instancetype)initWithDic:(NSDictionary *) dic;


-(CGRect) getFrame;
-(int)getFontSize;
-(int)getScaleType;
-(int)getTextAlignment;
-(UIColor *)getTextColor;
-(UIColor *)getBackgroudColor;
-(bool)isCtaClick;
-(bool)userPixel;
@end

@implementation ViewConfigItem
 NSDictionary *dic = nil;

- (instancetype)initWithDic:(NSDictionary *)dic{
    self = [super init];
    if (self) {
        self.viewConfigDic = dic;
    }
    return self;
}

-(int)getIntValueWithKey:(NSString *)key{
    
    NSObject* object = [self.viewConfigDic objectForKey:key];
    if([object isKindOfClass:[NSNumber class]]){
        NSNumber* number = (NSNumber*)object;
        return number.intValue;
    }
    return 0;
}

-(NSString *)getStringValueWithKey:(NSString *)key{
    
    NSObject* object = [self.viewConfigDic objectForKey:key];
    if([object isKindOfClass:[NSString class]]){
        return (NSString*)object;
    }
    return nil;
}


-(CGRect) getFrame{
    
    if ([self isFullScreen]) {
        return [UIScreen mainScreen].bounds;
    }
    int x = [self getIntValueWithKey:@"x"];
    int y = [self getIntValueWithKey:@"y"];
    int width= [self getIntValueWithKey:@"width"];
    int height = [self getIntValueWithKey:@"height"];
    
    if([self userPixel]){
        x =x>0? x/[UIScreen mainScreen].scale:0;
        y =y>0? y/[UIScreen mainScreen].scale:0;
        width = width>0? width/[UIScreen mainScreen].scale:0;
        height =height>0? height/[UIScreen mainScreen].scale:0;
    }
   
    return CGRectMake(x, y, width, height);
}
+ (CGFloat) colorComponentFrom: (NSString *) string start: (NSUInteger) start length: (NSUInteger) length {
    NSString *substring = [string substringWithRange: NSMakeRange(start, length)];
    NSString *fullHex = length == 2 ? substring : [NSString stringWithFormat: @"%@%@", substring, substring];
    unsigned hexComponent;
    [[NSScanner scannerWithString: fullHex] scanHexInt: &hexComponent];
    return hexComponent / 255.0;
}

+ (UIColor *) colorWithHexString: (NSString *) hexString {
    NSString *colorString = [[hexString stringByReplacingOccurrencesOfString: @"#" withString: @""] uppercaseString];
    CGFloat alpha, red, blue, green;
    switch ([colorString length]) {
        case 3: // #RGB
            alpha = 1.0f;
            red   = [self colorComponentFrom: colorString start: 0 length: 1];
            green = [self colorComponentFrom: colorString start: 1 length: 1];
            blue  = [self colorComponentFrom: colorString start: 2 length: 1];
            break;
        case 4: // #ARGB
            alpha = [self colorComponentFrom: colorString start: 0 length: 1];
            red   = [self colorComponentFrom: colorString start: 1 length: 1];
            green = [self colorComponentFrom: colorString start: 2 length: 1];
            blue  = [self colorComponentFrom: colorString start: 3 length: 1];
            break;
        case 6: // #RRGGBB
            alpha = 1.0f;
            red   = [self colorComponentFrom: colorString start: 0 length: 2];
            green = [self colorComponentFrom: colorString start: 2 length: 2];
            blue  = [self colorComponentFrom: colorString start: 4 length: 2];
            break;
        case 8: // #AARRGGBB
            alpha = [self colorComponentFrom: colorString start: 0 length: 2];
            red   = [self colorComponentFrom: colorString start: 2 length: 2];
            green = [self colorComponentFrom: colorString start: 4 length: 2];
            blue  = [self colorComponentFrom: colorString start: 6 length: 2];
            break;
        default:
            return nil;
    }
    return [UIColor colorWithRed: red green: green blue: blue alpha: alpha];
}


-(int)getFontSize{
    return [self getIntValueWithKey:@"fontSize"];
}
-(int)getScaleType{
    return [self getIntValueWithKey:@"scaleType"];
}
-(int)getTextAlignment{
    return [self getIntValueWithKey:@"textAlignment"];

}


-(UIColor*)getTextColor{
    NSString *str = [self getStringValueWithKey:@"textColor"];
    
    return [ViewConfigItem colorWithHexString:str];

    
}
-(UIColor*)getBackgroudColor{
    NSString *str = [self getStringValueWithKey:@"backgroundColor"];
    
    return [ViewConfigItem colorWithHexString:str];
}
-(bool)isCtaClick{
    NSObject* object = [self.viewConfigDic objectForKey:@"isCtaClick"];
    if([object isKindOfClass:[NSNumber class]]){
        return [(NSNumber *)object boolValue];
    }
    return false;
}


-(bool) isFullScreen{
    NSObject* object = [self.viewConfigDic objectForKey:@"isFullScreen"];
    if([object isKindOfClass:[NSNumber class]]){
        return [(NSNumber *)object boolValue];
    }
    return false;
}

-(bool) userPixel{
    NSObject* object = [self.viewConfigDic objectForKey:@"pixel"];
    if([object isKindOfClass:[NSNumber class]]){
        return [(NSNumber *)object boolValue];
    }
    return false;
}
@end

@interface WindMillUnityNativeAdCustomView : WindMillNativeAdView
@property (nonatomic, strong) UILabel *titleLabel;
@property (nonatomic, strong) UILabel *descLabel;
@property (nonatomic, strong) UIImageView *iconImageView;
@property (nonatomic, strong) UIButton *CTAButton;
@property (nonatomic, strong) UIButton *customDislikeButton;

@end

@implementation WindMillUnityNativeAdCustomView
- (instancetype)init {
    self = [super init];
    if (self) {
       
    }
    return self;
}

- (void) setupCustomView {
    self.clipsToBounds = YES;
    self.backgroundColor = UIColor.whiteColor;
    [self addSubview:self.mainImageView];
    [self addSubview:self.titleLabel];
    [self addSubview:self.descLabel];
    [self addSubview:self.iconImageView];
    [self addSubview:self.CTAButton];
    [self addSubview:self.customDislikeButton];
}
#pragma mark - proerty getter
- (UILabel *)titleLabel
{
    if (!_titleLabel) {
        _titleLabel = [[UILabel alloc] init];
        _titleLabel.accessibilityIdentifier = @"titleLabel_id";
    }
    return _titleLabel;
}

-(UIButton *) customDislikeButton{
    if(!_customDislikeButton){
        _customDislikeButton = [[UIButton alloc] init];
        _customDislikeButton.accessibilityIdentifier = @"customDislikeButton_id";
        _customDislikeButton.backgroundColor = [UIColor whiteColor];
        [_customDislikeButton setTitleColor:UIColor.whiteColor forState:UIControlStateNormal];
        _customDislikeButton.layer.masksToBounds = YES;
        _customDislikeButton.layer.cornerRadius = 5;
    }
    return _customDislikeButton;
}

- (UILabel *)descLabel
{
    if (!_descLabel) {
        _descLabel = [[UILabel alloc] init];
        _descLabel.accessibilityIdentifier = @"descLabel_id";
    }
    return _descLabel;
}

- (UIImageView *)iconImageView {
    if (!_iconImageView) {
        _iconImageView = [[UIImageView alloc] init];
        _iconImageView.accessibilityIdentifier = @"iconImageView_id";
    }
    return _iconImageView;
}


- (UIButton *)CTAButton {
    if (!_CTAButton) {
        _CTAButton = [[UIButton alloc] init];
        _CTAButton.accessibilityIdentifier = @"CTAButton_id";
        _CTAButton.backgroundColor = [UIColor colorWithRed:24/255.0 green:129/255.0 blue:255/255.0 alpha:1.0];
        [_CTAButton setTitleColor:UIColor.whiteColor forState:UIControlStateNormal];
        _CTAButton.titleLabel.font = [UIFont systemFontOfSize:14];
        _CTAButton.layer.masksToBounds = YES;
        _CTAButton.layer.cornerRadius = 5;
    }
    return _CTAButton;
}
@end

@interface WindMillUnityNativeAd : NSObject<WindMillNativeAdsManagerDelegate, WindMillNativeAdViewDelegate>
@property (nonatomic, strong) WindMillNativeAdsManager *nativeAdManager;
@property (nonatomic, strong) WindMillUnityNativeAdCustomView *nativeAdView;
@property (nonatomic) NativeAd_SuccessToLoad successToLoadBlock;
@property (nonatomic) NativeAd_DidFailToLoad didFailToLoadBlock;
@property (nonatomic) NativeAd_OnImpression impressionBlock;
@property (nonatomic) NativeAd_OnClicked clickedBlock;
@property (nonatomic) NativeAd_OnVideoPlayerStatusChanged videoPlayerChangedBlock;
@property (nonatomic) NativeAd_Dislike_OnSelected dislikeSelectedBlock;
@property (nonatomic) NativeAd_Dislike_OnCancel dislikeCancelBlock;
@property (nonatomic) NativeAd_Dislike_OnShow dislikeShowBlock;

@end

extern  UIViewController * UnityGetGLViewController();

@implementation WindMillUnityNativeAd



- (void)renderNativeAdViewToScene:(const char*) nativeAdViewJson  {

    if (nativeAdViewJson == NULL) {
        
        return;
    }
    
    NSString *string_content = [[NSString alloc] initWithCString:(const char*)nativeAdViewJson   encoding:NSASCIIStringEncoding];

    if (string_content == nil) {

        return;
    }
   
    NSLog(@"string_content %@",string_content);

    NSData *data = [string_content dataUsingEncoding:NSUTF8StringEncoding];
    if (data == nil) {
        
        return;
    }
    NSDictionary * dictionary = [NSJSONSerialization JSONObjectWithData:data options:NSJSONReadingMutableContainers error:nil ];
    
    if (dictionary == nil){
        return;
    }
    
    NSLog(@"dic %@",dictionary);

    [self renderAdToScene:CGPointZero nativeViewConfig:dictionary];
        


}
- (void)renderAdToScene:(CGPoint )point nativeViewConfig:(NSDictionary *) dic {
    
    NSArray<WindMillNativeAd *> *adArray = [self.nativeAdManager getAllNativeAds];
    if (adArray.count == 0) return;
    

    CGRect frame = CGRectZero;
    
    WindMillNativeAd *nativeAd = adArray.firstObject;
    UIViewController *rootViewController = UnityGetGLViewController();

    CGFloat originX = point.x>0? point.x/[UIScreen mainScreen].scale:0;
    CGFloat originY = point.y>0? point.y/[UIScreen mainScreen].scale:0;

    if(dic != nil){
     
        NSDictionary *config = [dic objectForKey:@"rootView"];
        ViewConfigItem * rootView = [[ViewConfigItem alloc] initWithDic:config];
        frame = [rootView getFrame];
        
    }else {
        CGFloat width = [UIScreen mainScreen].bounds.size.width - originX * 2;
        CGFloat height = 0;//这里可以根据素材横竖处理
        frame = CGRectMake(originX, originY, width, height);
    }
    
    self.nativeAdView = [[WindMillUnityNativeAdCustomView alloc] init];
    [rootViewController.view addSubview:self.nativeAdView];
    self.nativeAdView.frame = frame;
    self.nativeAdView.delegate = self;
    CGSize viewSize = frame.size;
    if(viewSize.height == 0){
        viewSize.height = viewSize.width/16.0 *9;
    }
    [self.nativeAdView refreshData:nativeAd];
    [self.nativeAdView setupCustomView];
    self.nativeAdView.viewController = rootViewController;
    // 美数 原生自渲染 视频类广告需要设置
    [self.nativeAdView setMediaViewSize:viewSize];
    if (nativeAd.feedADMode != WindMillFeedADModeNativeExpress) {
        [self build_template_view:nativeAd frame:self.nativeAdView.frame nativeViewConfig:dic];
    }
  
}


-(void)updateViewProperty:(UIView *) view ViewConfig:(ViewConfigItem *) viewConfigItem {
    CGRect frame = [viewConfigItem getFrame];
    [view sms_remakeConstraints:^(SMSConstraintMaker *make) {
        make.left.sms_equalTo(frame.origin.x);
        make.top.sms_equalTo(frame.origin.y);
        make.size.sms_equalTo(frame.size );
    }];
    UIColor * bgColor = [viewConfigItem getBackgroudColor];
    if(bgColor != nil){
        [view setBackgroundColor:bgColor];
    }
    int scaleType = [viewConfigItem getScaleType];

    switch (scaleType) {
        case 0:
            [view setContentMode:UIViewContentModeScaleAspectFit];
            break;
        case 1:
            [view setContentMode:UIViewContentModeScaleToFill];
        case 2:
            [view setContentMode:UIViewContentModeCenter];
            break;
        default:
            break;
    }
    
    if([view isKindOfClass: [UIButton class]]){
        
        UIButton *button =(UIButton*) view;
        UIColor *color = [viewConfigItem getTextColor];
        if (color != nil) {
            [button setTitleColor:color forState:UIControlStateNormal];
            [button setTitleColor:color forState:UIControlStateHighlighted];
        }
        int fontSize = [viewConfigItem getFontSize];

        if(fontSize > 0){
            [button setFont:[UIFont systemFontOfSize:fontSize]];
        }
        
    }
    

    if([view isKindOfClass: [UITextView class]]){
        
        UITextView *textview =(UITextView*) view;
        UIColor *color = [viewConfigItem getTextColor];
        if (color != nil) {
            [textview setTextColor:color];
        }
        int fontSize = [viewConfigItem getFontSize];

        if(fontSize > 0){
            [textview setFont:[UIFont systemFontOfSize:fontSize]];
        }
        
        int alignment = [viewConfigItem getTextAlignment];
        switch (alignment) {
            case 0:
                [textview setTextAlignment:NSTextAlignmentLeft];

                break;
            case 1:
                [textview setTextAlignment:NSTextAlignmentCenter];

                break;
            case 2:
                [textview setTextAlignment:NSTextAlignmentRight];
                break;
            default:
                break;
        }
    }
   
    
}
/// 这里开发者可以安装自己的需求做对应的布局，其中使用自动布局效果可能会更好
- (void)build_template_view:(WindMillNativeAd *)nativeAd frame:(CGRect)frame nativeViewConfig:(NSDictionary *) dic {
    
    NSMutableSet *clickViewSet = [[NSMutableSet alloc] init];
    
    
    if(dic != nil){
        NSDictionary *config = [dic objectForKey:@"mainAdView"];
        if(config != nil){
            
            ViewConfigItem * rootView = [[ViewConfigItem alloc] initWithDic:config];
            frame = [rootView getFrame];
            
            if (nativeAd.feedADMode == WindMillFeedADModeLargeImage) {
               

                [self updateViewProperty:self.nativeAdView.mainImageView ViewConfig:rootView ];
                

                if(self.nativeAdView.mainImageView == nil){
                    NSLog(@"mainImageView is null ");
                }else{
                    [clickViewSet addObject:self.nativeAdView.mainImageView];
                }
            }else if (nativeAd.feedADMode == WindMillFeedADModeVideo ||
                      nativeAd.feedADMode == WindMillFeedADModeVideoPortrait ||
                      nativeAd.feedADMode == WindMillFeedADModeVideoLandSpace) {
                
                [self.nativeAdView.mediaView setBackgroundColor:[UIColor blackColor]];

                [self updateViewProperty:self.nativeAdView.mediaView ViewConfig:rootView];
                CGRect rect =  [self.nativeAdView.mediaView frame];

                [self.nativeAdView.mediaView setFrame:CGRectMake(rect.origin.x+0.5, rect.origin.y, rect.size.width-1, rect.size.height-1)];
                if(self.nativeAdView.mediaView == nil){
                    NSLog(@"mediaView is null ");
                }else{
                    [clickViewSet addObject:self.nativeAdView.mediaView];

                }
            
            }else if(nativeAd.feedADMode == WindMillFeedADModeGroupImage){
                
                int preWidth = frame.size.width/self.nativeAdView.imageViewList.count;
                
                for(int i = 0; i<self.nativeAdView.imageViewList.count; i++){
                   UIImageView* imageView = self.nativeAdView.imageViewList[i];
                imageView.frame =CGRectMake(frame.origin.x*(i+1), frame.origin.y*(i+1), preWidth, frame.size.height);
                    if(imageView == nil){
                        NSLog(@"imageView is null ");
                    }else{
                        [clickViewSet addObject:imageView];
                    }
                }
            }
            
        }
       

        config = [dic objectForKey:@"iconView"];
        if(config != nil){
            
            ViewConfigItem * iconView = [[ViewConfigItem alloc] initWithDic:config];
            [self updateViewProperty:self.nativeAdView.iconImageView ViewConfig:iconView];

            if(self.nativeAdView.iconImageView == nil){
                NSLog(@"iconImageView is null ");
            }else{
                if ([iconView isCtaClick]) {
                    [clickViewSet addObject:self.nativeAdView.iconImageView];
                }
            }
           
        }
        
        config = [dic objectForKey:@"titleView"];
        if(config != nil){
            
            ViewConfigItem * titleView = [[ViewConfigItem alloc] initWithDic:config];
            [self updateViewProperty:self.nativeAdView.titleLabel ViewConfig:titleView];
            if(self.nativeAdView.titleLabel == nil){
                NSLog(@"titleLabel is null ");
            }else{
                if ([titleView isCtaClick]) {
                    [clickViewSet addObject:self.nativeAdView.titleLabel];
                }
            }
           
        }
        config = [dic objectForKey:@"descriptView"];

        if(config != nil){
            ViewConfigItem * descriptView = [[ViewConfigItem alloc] initWithDic:config];
            [self updateViewProperty:self.nativeAdView.descLabel ViewConfig:descriptView];
            if(self.nativeAdView.descLabel == nil){
                NSLog(@"descLabel is null ");
            }else{
                if ([descriptView isCtaClick]) {
                    [clickViewSet addObject:self.nativeAdView.descLabel];
                }
            }
        }
       
        config = [dic objectForKey:@"adLogoView"];

        if(config != nil){
            ViewConfigItem * adLogoView = [[ViewConfigItem alloc] initWithDic:config];
            [self updateViewProperty:self.nativeAdView.logoView ViewConfig:adLogoView];
            [self.nativeAdView.logoView.superview bringSubviewToFront:self.nativeAdView.logoView];

            
            if(self.nativeAdView.logoView == nil){
                NSLog(@"logoView is null ");
            }else{
                if ([adLogoView isCtaClick]) {
                    [clickViewSet addObject:self.nativeAdView.logoView];
                }
            }
        }
       
        config = [dic objectForKey:@"ctaButton"];

        if(config != nil){
            ViewConfigItem * ctaButton = [[ViewConfigItem alloc] initWithDic:config];
            [self updateViewProperty:self.nativeAdView.CTAButton ViewConfig:ctaButton];

            if(self.nativeAdView.CTAButton == nil){
                NSLog(@"titleLabel is null ");
            }else{
                [clickViewSet addObject:self.nativeAdView.CTAButton];
            }
            
        }

        config = [dic objectForKey:@"dislikeButton"];

        if(config != nil){
            ViewConfigItem * dislikeButton = [[ViewConfigItem alloc] initWithDic:config];
            [self updateViewProperty:self.nativeAdView.dislikeButton ViewConfig:dislikeButton];
        }
    
        
    }else{
     
        
        CGFloat margin = 10;
        CGFloat contentWidth = CGRectGetWidth(frame);
        CGFloat offsetY = 0;
        if (nativeAd.feedADMode == WindMillFeedADModeLargeImage) {
            CGFloat imgHeight = contentWidth*9.0/16.0;
            self.nativeAdView.mainImageView.frame = CGRectMake(0, offsetY, contentWidth, imgHeight);
            offsetY += imgHeight;
            [clickViewSet addObject:self.nativeAdView.mainImageView];

        }else if (nativeAd.feedADMode == WindMillFeedADModeVideo || nativeAd.feedADMode == WindMillFeedADModeVideoLandSpace) {
            CGFloat mediaHeight = contentWidth*9.0/16.0-10;
            ///防止gdt视频渲染出问题,GDT暂时不设置frame
            if(nativeAd.networkId != 16){
                self.nativeAdView.mediaView.frame = CGRectMake(5, offsetY+5, contentWidth-10, mediaHeight);
            }
            offsetY += mediaHeight;
            
            [clickViewSet addObject:self.nativeAdView.mediaView];

        }else if (nativeAd.feedADMode == WindMillFeedADModeVideoPortrait) {
            CGFloat mediaHeight = contentWidth*16.0/9.0;
            mediaHeight = MIN(mediaHeight, contentWidth)-10;
            ///防止gdt视频渲染出问题,GDT暂时不设置frame
            if(nativeAd.networkId != 16){
                self.nativeAdView.mediaView.frame = CGRectMake(5, offsetY+5, contentWidth-10, mediaHeight);
            }
            offsetY += mediaHeight;
            [clickViewSet addObject:self.nativeAdView.mediaView];

        }else if(nativeAd.feedADMode == WindMillFeedADModeGroupImage){
            
            int preWidth = frame.size.width/self.nativeAdView.imageViewList.count;
            
            for(int i = 0; i<self.nativeAdView.imageViewList.count; i++){
               UIImageView* imageView = self.nativeAdView.imageViewList[i];
            imageView.frame =CGRectMake(frame.origin.x*(i+1)+preWidth*i, frame.origin.y, preWidth, frame.size.height);
                [clickViewSet addObject:imageView];

            }
        }
        offsetY += margin*2;
        CGSize iconSize = CGSizeMake(60, 60);

        self.nativeAdView.iconImageView.frame = CGRectMake(margin, offsetY, iconSize.width, iconSize.height);
        /// 设置标题和描述，在某些广告标题和描述可能位空
        CGFloat titleOffsetX = CGRectGetMaxX(self.nativeAdView.iconImageView.frame) + margin;
        CGFloat titleWidth = contentWidth - titleOffsetX - 50;
        self.nativeAdView.titleLabel.frame = CGRectMake(titleOffsetX, offsetY, titleWidth, iconSize.height * 0.5);
        self.nativeAdView.descLabel.frame = CGRectMake(titleOffsetX, CGRectGetMaxY(self.nativeAdView.titleLabel.frame) , titleWidth, iconSize.height * 0.5);
        
        self.nativeAdView.dislikeButton.frame = CGRectMake(CGRectGetMaxX(self.nativeAdView.titleLabel.frame) + margin, offsetY+22.5, 15, 15);
        
        offsetY += iconSize.height;
        offsetY += margin * 2;
        
        /// 设置cta按钮
        self.nativeAdView.CTAButton.frame = CGRectMake(margin*2, offsetY, contentWidth - margin*4, 45);

        offsetY += 45;
        
//        [self.nativeAdView.logoView setTranslatesAutoresizingMaskIntoConstraints:true];
//        self.nativeAdView.logoView.frame = CGRectMake(0, offsetY+5, 70, 15);
        [self.nativeAdView.logoView sms_remakeConstraints:^(SMSConstraintMaker *make) {
            make.left.sms_equalTo(self.nativeAdView).offset(0);
            make.bottom.sms_equalTo(self.nativeAdView).offset(0);
            make.size.sms_equalTo(CGSizeMake(70, 15));
        }];
        UIImageView *logoview =  self.nativeAdView.logoView;
        
        [logoview  setContentMode:UIViewContentModeScaleAspectFit];
        self.nativeAdView.frame = CGRectMake(frame.origin.x, frame.origin.y, frame.size.width, offsetY + margin*2);
        
    }
    
    self.nativeAdView.iconImageView.layer.masksToBounds = YES;
    self.nativeAdView.iconImageView.layer.cornerRadius = 10;
    
    [clickViewSet addObjectsFromArray:@[self.nativeAdView.CTAButton, self.nativeAdView.iconImageView]];
    
    [self.nativeAdView setClickableViews: [clickViewSet allObjects]];

        NSURL *iconUrl = [NSURL URLWithString:nativeAd.iconUrl];
       
        /// 设置icon的图片，这里也可以使用SDWebImage[self.nativeAdView.iconImageView sd_setImageWithURL:iconUrl];
        dispatch_async(dispatch_get_global_queue(0, 0), ^{
            NSData *imgData = [NSData dataWithContentsOfURL:iconUrl];
            UIImage *image = [UIImage imageWithData:imgData];
            dispatch_async(dispatch_get_main_queue(), ^{
                self.nativeAdView.iconImageView.image = image;
            });
        });

        self.nativeAdView.descLabel.text = nativeAd.desc;
        self.nativeAdView.titleLabel.text = nativeAd.title;
    
        [self.nativeAdView.CTAButton setTitle:nativeAd.callToAction forState:UIControlStateNormal];


        
       
            
}


- (NSAttributedString *)titleAttributeText:(NSString *)text {
    if (text == nil) {
        return nil;
    }
    NSMutableDictionary *attribute = @{}.mutableCopy;
    NSMutableParagraphStyle * titleStrStyle = [[NSMutableParagraphStyle alloc] init];
    titleStrStyle.lineSpacing = 5;
    titleStrStyle.alignment = NSTextAlignmentJustified;
    attribute[NSFontAttributeName] = [UIFont systemFontOfSize:17.f];
    attribute[NSParagraphStyleAttributeName] = titleStrStyle;
    return [[NSAttributedString alloc] initWithString:text attributes:attribute];
}


#pragma mark - WindMillNativeAdsManagerDelegate
- (void)nativeAdsManagerSuccessToLoad:(WindMillNativeAdsManager *)adsManager {
    if (self.successToLoadBlock) {
        self.successToLoadBlock((__bridge void*)self);
    }
}
- (void)nativeAdsManager:(WindMillNativeAdsManager *)adsManager didFailWithError:(NSError *)error {
    if (self.didFailToLoadBlock) {
        self.didFailToLoadBlock((int)error.code, [error.localizedDescription UTF8String], (__bridge void*)self);
    }
}

#pragma mark - WindMillNativeAdViewDelegate

/**
 * 原生模板广告渲染成功, 此时的 nativeExpressAdView.size.height 根据 size.width 完成了动态更新。
 * （只针对模版渲染）
 */
- (void)nativeExpressAdViewRenderSuccess:(WindMillNativeAdView *)nativeExpressAdView{
    CGRect rect =  nativeExpressAdView.frame;
    CGFloat x = ([UIScreen mainScreen].bounds.size.width-rect.size.width)/2;
    nativeExpressAdView.frame = CGRectMake(x, rect.origin.y, rect.size.width, rect.size.height);
    [nativeExpressAdView.superview layoutIfNeeded];
  
}

/**
 * 原生模板广告渲染失败
 * （只针对模版渲染）
 */
- (void)nativeExpressAdViewRenderFail:(WindMillNativeAdView *)nativeExpressAdView error:(NSError *)error{

}


/**
 广告曝光回调

 @param nativeAdView WindMillNativeAdView 实例
 */
- (void)nativeAdViewWillExpose:(WindMillNativeAdView *)nativeAdView {

    if (self.impressionBlock) {
        self.impressionBlock((__bridge void*)self);
    }
    
}


/**
 广告点击回调

 @param nativeAdView WindMillNativeAdView 实例
 */
- (void)nativeAdViewDidClick:(WindMillNativeAdView *)nativeAdView {
    if (self.clickedBlock) {
        self.clickedBlock((__bridge void*)self);
    }
}


/**
 广告详情页关闭回调

 @param nativeAdView WindMillNativeAdView 实例
 */
- (void)nativeAdDetailViewClosed:(WindMillNativeAdView *)nativeAdView {
    
}


/**
 当点击应用下载或者广告调用系统程序打开时调用
 
 @param nativeAdView WindMillNativeAdView 实例
 */
- (void)nativeAdViewApplicationWillEnterBackground:(WindMillNativeAdView *)nativeAdView {
    
}


/**
 广告详情页面即将展示回调

 @param nativeAdView WindMillNativeAdView 实例
 */
- (void)nativeAdDetailViewWillPresentScreen:(WindMillNativeAdView *)nativeAdView {
    
}


/**
 视频广告播放状态更改回调

 @param nativeAdView WindMillNativeAdView 实例
 @param status 视频广告播放状态
 @param userInfo 视频广告信息
 */
- (void)nativeAdView:(WindMillNativeAdView *)nativeAdView playerStatusChanged:(WindMillMediaPlayerStatus)status userInfo:(NSDictionary *)userInfo {
    if (self.videoPlayerChangedBlock) {
        self.videoPlayerChangedBlock((int)status, (__bridge void*)self);
    }
}


/**
 点击dislike回调
 开发者需要在这个回调中移除视图，否则，会出现用户点击叉无效的情况
 
 @param filterWords : 选择不喜欢的原因
 */
- (void)nativeAdView:(WindMillNativeAdView *)nativeAdView dislikeWithReason:(NSArray<WindMillDislikeWords *> *)filterWords {
    if (self.dislikeSelectedBlock) {
        NSString *content = @"Unknow";
        if (filterWords.count > 0) {
            WindMillDislikeWords *dislikeWord = [filterWords objectAtIndex:0];
            content = dislikeWord.name;
        }
        self.dislikeSelectedBlock(-1, [content UTF8String], true, (__bridge void*)self);
    }
    [nativeAdView unregisterDataObject];
    [nativeAdView removeFromSuperview];
    self.nativeAdView = nil;
}

- (void)dealloc {
    self.nativeAdManager.delegate = nil;
    self.nativeAdManager = nil;
    if(self.nativeAdView != nil && self.nativeAdView.superview != nil){
        [self.nativeAdView removeFromSuperview];
    }
    self.nativeAdView = nil;
}

@end



#if defined (__cplusplus)
extern "C" {
#endif
    
    void* WindMillUnity_NewWindMillNativeAd(){
        
        WindMillUnityNativeAd *instance = [[WindMillUnityNativeAd alloc] init];
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Wunused-value"
        (__bridge_retained void*)instance;
#pragma clang diagnostic pop
        return (__bridge void*)instance;
    }
    
    void WindMillUnity_NativeAd_Dispose(void* ptr) {
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Wunused-value"
        (__bridge_transfer WindMillUnityNativeAd *)ptr;
#pragma clang diagnostic pop
    }
    
    
    const char* WindMillUnity_NativeAd_CacheAdInfoList(void* ptr) {
        WindMillUnityNativeAd* instance = (__bridge WindMillUnityNativeAd *)ptr;
        WindMillNativeAdsManager *adManager = instance.nativeAdManager;
        if(adManager != nil){
            NSArray* adInfoList = [adManager getCacheAdInfoList];
            if(adInfoList != NULL && adInfoList.count>0){
                NSMutableArray *list =  [[NSMutableArray alloc] initWithCapacity:adInfoList.count];

                for (WindMillAdInfo *item in adInfoList) {
                    [list addObject:[item toJson]];
                }
                return ToJsonString(list);
            }
        }
        
        return NULL;
    }

    void WindMillUnity_NativeAd_Load
    (
     const char* placementId,
     const char* userID,
     int width,
     int height,
     const char* extra,
     void* ptr) {
//        SIGLogDebug(@"===== WindMillUnity_NativeAd_Load =====");
        WindMillAdRequest *request = [[WindMillAdRequest alloc] init];
        
        request.userId = [[NSString alloc] initWithUTF8String:userID?:"-2"];
        request.placementId = [[NSString alloc] initWithUTF8String:placementId];
        
        NSDictionary *dic = ToDictionary(extra);
        if(dic != nil){
            request.options = dic;
        }
        WindMillUnityNativeAd* instance = (__bridge WindMillUnityNativeAd *)ptr;
        WindMillNativeAdsManager *adManager = instance.nativeAdManager;
        CGFloat originWidth = width>0? width/[UIScreen mainScreen].scale:0;
        CGFloat originHeight = height>0?height/[UIScreen mainScreen].scale:0;

        if (adManager == nil) {
            adManager = [[WindMillNativeAdsManager alloc] initWithRequest:request];
            adManager.adSize = CGSizeMake(originWidth, originHeight);
            instance.nativeAdManager = adManager;
        }
        adManager.delegate = instance;
        [adManager loadAdDataWithCount:1];
    }
    
    void WindMillUnity_NativeAd_SetLoadListener(
                                            void* ptr,
                                            NativeAd_SuccessToLoad successToLoad,
                                            NativeAd_DidFailToLoad didFailToLoad) {
        WindMillUnityNativeAd* instance = (__bridge WindMillUnityNativeAd *)ptr;
        instance.successToLoadBlock = successToLoad;
        instance.didFailToLoadBlock =  didFailToLoad;
    }
    
    void WindMillUnity_NativeAd_SetDislikeListener(
                                               void* ptr,
                                               NativeAd_Dislike_OnSelected dislikeSelectedBlock,
                                               NativeAd_Dislike_OnCancel dislikeCancelBlock,
                                               NativeAd_Dislike_OnShow dislikeShowBlock
                                               ) {
        WindMillUnityNativeAd* instance = (__bridge WindMillUnityNativeAd *)ptr;
        instance.dislikeSelectedBlock = dislikeSelectedBlock;
        instance.dislikeCancelBlock = dislikeCancelBlock;
        instance.dislikeShowBlock = dislikeShowBlock;
        
    }
    
    void WindMillUnity_NativeAd_SetAdInteractionListener(
                                                     void* ptr,
                                                     NativeAd_OnImpression impressionBlock,
                                                     NativeAd_OnClicked clickedBlock,
                                                     NativeAd_OnVideoPlayerStatusChanged videoPlayerChangedBlock
                                                     ) {
        WindMillUnityNativeAd* instance = (__bridge WindMillUnityNativeAd *)ptr;
        instance.impressionBlock = impressionBlock;
        instance.clickedBlock = clickedBlock;
        instance.videoPlayerChangedBlock = videoPlayerChangedBlock;
    }

   const char* WindMillUnity_NativeAd_AdInfo(void* ptr) {
        WindMillUnityNativeAd* instance = (__bridge WindMillUnityNativeAd *)ptr;
        return ToChar([instance.nativeAdView.adInfo toJson]);
    }


    void WindMillUnity_NativeAd_RenderAdToScene(void *ptr, float x, float y) {
        WindMillUnityNativeAd* instance = (__bridge WindMillUnityNativeAd *)ptr;
        [instance renderAdToScene:CGPointMake(x, y) nativeViewConfig:nil];
    }

    void WindMillUnity_NativeAd_RenderNativeAdViewToScene(void *ptr, const char * nativeAdViewJson) {

        WindMillUnityNativeAd* instance = (__bridge WindMillUnityNativeAd *)ptr;
        [instance renderNativeAdViewToScene:nativeAdViewJson];
    }
    
    
#if defined (__cplusplus)
}
#endif


