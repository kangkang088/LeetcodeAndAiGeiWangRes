//
//  WindMillUnityAWMSDKConfigureHelper.h
//  UnityFramework
//
//  Created by happyelements on 2023/7/24.
//

#import <Foundation/Foundation.h>
#import <WindMillSDK/WindMillSDK.h>

@interface WindMillUnityAWMSDKConfigureHelper : NSObject
+ (AWMSDKConfigure *)getAWMSDKConfigureWithAdnId:(NSNumber *)adnId
                        appid:(NSString *)appId
                       appKey:(NSString *)appKey;
@end

