﻿namespace WindMill.Advertisements
{
#if !UNITY_EDITOR && UNITY_IOS

    using System;
    using System.Collections.Generic;
    using System.Runtime.InteropServices;
    using UnityEngine;

    public static class Advertisement
    {
        public static string Version
        {
            get
            {
                return WindMillUnity_SdkVersion();
            }
        }

        public static void networkPreInit(List<WindmillNetworkInfo> list)
        {
            string json = Json.Serialize(list);

            WindMillUnity_networkPreInit(json);
        }

        public static void setPresetLocalStrategyPath(string path)
        {
            WindMillUnity_setPresetLocalStrategyPath(path);
        }

        public static void SetDebugEnable(bool enable)
        {
            WindMillUnity_SetDebugEnable(enable);
        }

        public static void setSupportMultiProcess(bool enable)
        {
            Debug.Log("不支持当前平台");
        }

        public static AgeRestrictedStatus GetAgeRestrictedStatus()
        {
            return WindMillUnity_GetAgeRestrictedStatus();
        }

        public static void SetIsAgeRestrictedUser(AgeRestrictedStatus ageRestrictedStatus)
        {
            WindMillUnity_SetIsAgeRestrictedUser(ageRestrictedStatus);
        }

        public static void InitCustomGroup(Dictionary<string, object> customGroup)
        {

            string extra = Json.Serialize(customGroup);

            WindMillUnity_InitCustomGroup(extra);
        }

        public static void InitCustomGroupForPlacementId(Dictionary<string, object> customGroup, string placementId)
        {
            string extra = Json.Serialize(customGroup);
            WindMillUnity_InitCustomGroupForPlacementId(placementId,extra);

        }

        public static void SetExt(Dictionary<string, string> ext)
        {
            string extra = Json.Serialize(ext);
            WindMillUnity_SetExt(extra);

        }

        public static void SetCustomDeviceController(CustomDeviceController deviceController)
        {
            WindMillUnity_SetCustomDeviceController(deviceController.isCanUseLocation,deviceController.devLocation.Latitude,deviceController.devLocation.Longitude, deviceController.isCanUseIdfa, deviceController.devIdfa);
        }



        public static ConsentStatus GetUserGDPRConsentStatus()
        {
            return WindMillUnity_GetUserGDPRConsentStatus();
        }

        public static void SetUserGDPRConsentStatus(ConsentStatus ageRestrictedStatus)
        {
            WindMillUnity_SetUserGDPRConsentStatus(ageRestrictedStatus);
        }


        public static Int32 GetUserAge()
        {
            return WindMillUnity_GetUserAge();
        }

        public static void SetUserAge(Int32 age)
        {
            WindMillUnity_SetUserAge(age);
        }

           
        public static void init(string appId)
        {
            WindMillUnity_StartWithOptions(appId);
        }


        public static void RequestPermissionIfNecessary()
        {
            Debug.Log("不支持当前平台");
        }


        public static void setUserAdultStatus(UserAdultStatus userAdultStatus)
        {
            WindMillUnity_SetUserAdultStatus(userAdultStatus);
        }

        public static void setPersonalizedAdvertisingStatus(PersonalizedAdvertisingStatus personalizedAdvertisingStatus)
        {
            WindMillUnity_SetPersonalizedAdvertisingStatus(personalizedAdvertisingStatus);
        }


        [DllImport("__Internal")]
        private static extern void WindMillUnity_networkPreInit(string json);

        [DllImport("__Internal")]
        private static extern void WindMillUnity_setPresetLocalStrategyPath(string path);

        [DllImport("__Internal")]
        private static extern void WindMillUnity_StartWithOptions(string appId);

        [DllImport("__Internal")]
        private static extern void WindMillUnity_SetDebugEnable(bool enable);

        [DllImport("__Internal")]
        private static extern AgeRestrictedStatus WindMillUnity_GetAgeRestrictedStatus();

        [DllImport("__Internal")]
        private static extern void WindMillUnity_SetIsAgeRestrictedUser(AgeRestrictedStatus status);

        [DllImport("__Internal")]
        private static extern void WindMillUnity_SetCustomDeviceController(bool isCanUseLocation,float latitude, float longitude, bool isCanUseIdfa, string devIdfa);

        [DllImport("__Internal")]
        private static extern void WindMillUnity_SetExt(string ext);

        [DllImport("__Internal")]
        private static extern void WindMillUnity_InitCustomGroup(string customGroup);
        [DllImport("__Internal")]
        private static extern void WindMillUnity_InitCustomGroupForPlacementId(string placementId,string customGroup);

        [DllImport("__Internal")]
        private static extern void WindMillUnity_SetUserGDPRConsentStatus(ConsentStatus status);

        [DllImport("__Internal")]
        private static extern ConsentStatus WindMillUnity_GetUserGDPRConsentStatus();

        [DllImport("__Internal")]
        private static extern void WindMillUnity_SetUserAdultStatus(UserAdultStatus status);

        [DllImport("__Internal")]
        private static extern void WindMillUnity_SetPersonalizedAdvertisingStatus(PersonalizedAdvertisingStatus status);

        [DllImport("__Internal")]
        private static extern Int32 WindMillUnity_GetUserAge();

        [DllImport("__Internal")]
        private static extern void WindMillUnity_SetUserAge(Int32 age);

        [DllImport("__Internal")]
        private static extern string WindMillUnity_SdkVersion();

    }

#endif
}