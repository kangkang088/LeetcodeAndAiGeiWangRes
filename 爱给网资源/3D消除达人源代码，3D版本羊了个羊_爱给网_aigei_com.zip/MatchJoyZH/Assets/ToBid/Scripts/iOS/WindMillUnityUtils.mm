//
//  WindMillUnityUtils.mm
//  Unity-iPhone
//
//  Created by happyelements on 2022/3/31.
//

#include "WindMillUnityUtils.h"


#if defined (__cplusplus)
extern "C" {
#endif

char* ToChar(NSString *str){
    const char* tmp = [str UTF8String];
    char* ret = (char*)malloc(strlen(tmp) + 1);
    strcpy(ret, tmp);
    return ret;
}

id  ToDictionaryWithString(NSString *json){
    NSData *data = [json dataUsingEncoding:NSUTF8StringEncoding];
    
    NSError *error ;
    NSDictionary *dic = [NSJSONSerialization JSONObjectWithData:data options:NSJSONReadingMutableContainers error:&error];
    if (error != nil) {
        return nil;
    }
    return dic;
}
id  ToDictionary(const char *json){
    
    if(json == NULL) return nil;
    
    NSString *str = [NSString stringWithUTF8String:json];
  
    return ToDictionaryWithString(str);
}

char * ToJsonString(NSObject *obj){
    NSError *error = nil;

    NSData *data = [NSJSONSerialization dataWithJSONObject:obj options:NSJSONWritingPrettyPrinted error:&error];
    if(data != nil){
        
        NSString *jsonString = [[NSString alloc] initWithData:data encoding:NSUTF8StringEncoding];

        if(jsonString != nil){
            return ToChar(jsonString);
        }
    }else{
        NSLog(@"Error: %@", error.localizedDescription);
    }
    return  NULL;
}
#if defined (__cplusplus)
}
#endif
