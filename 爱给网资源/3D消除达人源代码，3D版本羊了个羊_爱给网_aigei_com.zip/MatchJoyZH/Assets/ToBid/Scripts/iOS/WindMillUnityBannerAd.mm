//
//  WindMillUnityBannerAd.mm
//  WindMillSDK
//
//  Created by Codi on 2021/5/20.
//  Copyright © 2021 Codi. All rights reserved.
//

#import <WindMillSDK/WindMillSDK.h>
#include "WindMillUnityUtils.h"

// IBannerAdListener callbacks.
typedef void(*BannerAd_OnError)(int code, const char* message, void* bannerAdPtr);
typedef void(*BannerAd_OnAdLoad)(void* bannerAdPtr);
typedef void(*BannerAd_OnAdShow)(void* bannerAdPtr);
typedef void(*BannerAd_OnAdClick)(void* bannerAdPtr);
typedef void(*BannerAd_OnAdClose)(void* bannerAdPtr);
typedef void(*BannerAd_OnAdAutoRefreshed)(void* bannerAdPtr);
typedef void(*BannerAd_OnAdAutoRefreshFail)(int code, const char* message,void* bannerAdPtr);




@interface WindMillUnityBannerAd : NSObject

@property (nonatomic, strong) NSString *name;
@property (nonatomic, strong) WindMillBannerView *bannerAdView;
@property (nonatomic, assign) BannerAd_OnError onError;
@property (nonatomic, assign) BannerAd_OnAdLoad onAdLoad;
@property (nonatomic, assign) BannerAd_OnAdShow onAdShow;
@property (nonatomic, assign) BannerAd_OnAdClick onAdClick;
@property (nonatomic, assign) BannerAd_OnAdClose onAdClose;
@property (nonatomic, assign) BannerAd_OnAdAutoRefreshed onAdAutoRefreshed;
@property (nonatomic, assign) BannerAd_OnAdAutoRefreshFail onAdAutoRefreshFail;

@end

@interface WindMillUnityBannerAd()<WindMillBannerViewDelegate>

@end

@implementation WindMillUnityBannerAd

#pragma mark -  WindMillBannerViewDelegate

/**
 This method is called when video ad material loaded successfully.
 */
 //bannerView自动刷新
- (void)bannerAdViewDidAutoRefresh:(WindMillBannerView *)bannerAdView {
    if (self.onAdAutoRefreshed) {
        self.onAdAutoRefreshed((__bridge void*)self);
    }
}
//bannerView自动刷新失败
- (void)bannerView:(WindMillBannerView *)bannerAdView failedToAutoRefreshWithError:(NSError *)error {
    if (self.onAdAutoRefreshFail) {
        self.onAdAutoRefreshFail((int)error.code, [error.localizedDescription UTF8String], (__bridge void*)self);
    }
}
//成功加载广告
- (void)bannerAdViewLoadSuccess:(WindMillBannerView *)bannerAdView {
    if (self.onAdLoad) {
        self.onAdLoad((__bridge void*)self);
    }
}
//广告加载失败
- (void)bannerAdViewFailedToLoad:(WindMillBannerView *)bannerAdView error:(NSError *)error {
    if (self.onError) {
        self.onError((int)error.code, [error.localizedDescription UTF8String], (__bridge void*)self);
    }
    
}
//广告将要展示
- (void)bannerAdViewWillExpose:(WindMillBannerView *)bannerAdView {
    
    if (self.onAdShow) {
        self.onAdShow((__bridge void*)self);
    }
}
//广告被点击
- (void)bannerAdViewDidClicked:(WindMillBannerView *)bannerAdView {
 if (self.onAdClick) {
        self.onAdClick((__bridge void*)self);
    }
}
//当用户由于点击要离开您的应用程序时触发该回调,您的应用程序将移至后台
- (void)bannerAdViewWillLeaveApplication:(WindMillBannerView *)bannerAdView {

}
//将打开全屏视图。在打开storekit或在应用程序中打开网页时触发
- (void)bannerAdViewWillOpenFullScreen:(WindMillBannerView *)bannerAdView {

}
//将关闭全屏视图。关闭storekit或关闭应用程序中的网页时发送
- (void)bannerAdViewCloseFullScreen:(WindMillBannerView *)bannerAdView {
   
}
//广告视图被移除
- (void)bannerAdViewDidRemoved:(WindMillBannerView *)bannerAdView {
    if (self.onAdClose) {
        self.onAdClose((__bridge void*)self);
    }
    if (self.bannerAdView != nil) {
        [self.bannerAdView removeFromSuperview];
        self.bannerAdView.delegate = nil;
        self.bannerAdView = nil;
    }

}

- (void)dealloc {
    if (self.bannerAdView != nil) {
        self.bannerAdView.delegate = nil;
        self.bannerAdView = nil;
    }
  
}



@end


#if defined (__cplusplus)
extern "C" {
#endif

    extern UIViewController * UnityGetGLViewController(void);

    void* WindMillUnity_NewWindMillBannerAdView(){
        WindMillUnityBannerAd *instance = [[WindMillUnityBannerAd alloc] init];
    #pragma clang diagnostic push
    #pragma clang diagnostic ignored "-Wunused-value"
        //retainCount +1
        (__bridge_retained void*)instance;
    #pragma clang diagnostic pop
        return (__bridge void*)instance;
    }

    void WindMillUnity_BannerAd_HideAd(void *bannerAdPtr) {
        WindMillUnityBannerAd *instance = (__bridge WindMillUnityBannerAd*)bannerAdPtr;
        WindMillBannerView *bannerAdView = instance.bannerAdView;
        if(bannerAdView != nil){
            [bannerAdView removeFromSuperview];
        }
    }

     void WindMillUnity_BannerAd_Load
     (
      const char* placementId,
      const char* userID,
      int width,
      int height,
      const char* extra,
      void* bannerAdPtr) {
        WindMillAdRequest *request = [[WindMillAdRequest alloc] init];
        request.userId = [[NSString alloc] initWithUTF8String:userID?:"-2"];
        request.placementId = [[NSString alloc] initWithUTF8String:placementId?:""];
        
        NSDictionary *dic = ToDictionary(extra);
        if(dic != nil){
            request.options = dic;
        }
        
        WindMillUnityBannerAd* instance = (__bridge WindMillUnityBannerAd *)bannerAdPtr;
        WindMillBannerView *bannerAdView = instance.bannerAdView;
        if (bannerAdView == nil) {
            if(width>0 && height>0){
                bannerAdView = [[WindMillBannerView alloc] initWithRequest :request expectSize:CGSizeMake(width, height)];
            }else{
                bannerAdView = [[WindMillBannerView alloc] initWithRequest :request];
            }
            instance.bannerAdView = bannerAdView;
        }
        UIViewController *rootViewController = UnityGetGLViewController();

        bannerAdView.viewController = rootViewController;
        bannerAdView.delegate = instance;
        [bannerAdView loadAdData];
    }
    

    void WindMillUnity_BannerAd_SetInteractionListener
    (
     void* bannerAdPtr,
     BannerAd_OnError onError,
     BannerAd_OnAdLoad onAdLoad,
     BannerAd_OnAdShow onAdShow,
     BannerAd_OnAdClick onAdClick,
     BannerAd_OnAdClose onAdClose,
     BannerAd_OnAdAutoRefreshed onAdAutoRefreshed,
     BannerAd_OnAdAutoRefreshFail onAdAutoRefreshFail
     ) {
        WindMillUnityBannerAd* instance = (__bridge WindMillUnityBannerAd *)bannerAdPtr;
        instance.onError = onError;
        instance.onAdLoad = onAdLoad;
        instance.onAdShow = onAdShow;
        instance.onAdClick = onAdClick;
        instance.onAdClose = onAdClose;
        instance.onAdAutoRefreshed = onAdAutoRefreshed;
        instance.onAdAutoRefreshFail = onAdAutoRefreshFail;
    }

    BOOL WindMillUnity_BannerAd_Ready(void* bannerAdPtr) {
        WindMillUnityBannerAd* instance = (__bridge WindMillUnityBannerAd *)bannerAdPtr;

        WindMillBannerView* bannerAdView = instance.bannerAdView;
        if (bannerAdView != nil) {
            return bannerAdView.isAdValid;
        }
        return NO;
    
    }
    const char* WindMillUnity_BannerAd_AdInfo(void* bannerAdPtr) {
        WindMillUnityBannerAd* instance = (__bridge WindMillUnityBannerAd *)bannerAdPtr;
        return ToChar([instance.bannerAdView.adInfo toJson]);
    }

    const char* WindMillUnity_BannerAd_CacheAdInfoList(void* ptr) {
        WindMillUnityBannerAd* instance = (__bridge WindMillUnityBannerAd *)ptr;
        WindMillBannerView *bannerView = instance.bannerAdView;
    
        if(bannerView != nil){
            NSArray* adInfoList = [bannerView getCacheAdInfoList];
            if(adInfoList != NULL && adInfoList.count>0){
                NSMutableArray *list =  [[NSMutableArray alloc] initWithCapacity:adInfoList.count];

                for (WindMillAdInfo *item in adInfoList) {
                    [list addObject:[item toJson]];
                }
                return ToJsonString(list);
            }
        }
        
        return NULL;
    }


    void WindMillUnity_BannerAd_ShowBannerAd(void* bannerAdPtr, int x, int y, int width, int height) {
        WindMillUnityBannerAd* instance = (__bridge WindMillUnityBannerAd *)bannerAdPtr;
        WindMillBannerView *bannerAdView = instance.bannerAdView;

        UIViewController *rootViewController = UnityGetGLViewController();

        CGFloat originX = x>0? x/[UIScreen mainScreen].scale:0;
        CGFloat originY = y>0? y/[UIScreen mainScreen].scale:0;
        CGFloat originWidth = width>0? width/[UIScreen mainScreen].scale+0.5:0;
        CGFloat originHeight = height>0?height/[UIScreen mainScreen].scale+0.5:0;

        if (originX == 0) {
            originX = ([UIScreen mainScreen].bounds.size.width-originWidth)/2;
        }
        
        NSArray* list =  [bannerAdView getCacheAdInfoList];
        if(list != nil){
            WindMillAdInfo *adInfo = list.firstObject;
            if (adInfo.networkId == 33) {
                CGSize adsize = bannerAdView.adSize;
                originWidth = adsize.width;
                originHeight = adsize.height;
            }
        }
        //部分渠道需要使用广告返回的size

#pragma mark- 根据广告内容调整UI,可选操作
        //根据广告内容调整UI

//        CGSize adsize = bannerAdView.adSize;
//        originWidth = adsize.width;
//        originHeight = adsize.height;
//         originX = ([UIScreen mainScreen].bounds.size.width-adsize.width)/2;
//         if ([UIScreen mainScreen].bounds.size.height<originY+adsize.height) {
//             originY = [UIScreen mainScreen].bounds.size.height- adsize.height-5;
//         }
//

        CGRect frame = CGRectMake(originX, originY, originWidth, originHeight);
        if(bannerAdView != nil){
            [bannerAdView removeFromSuperview];
            bannerAdView.frame=frame;
            [rootViewController.view addSubview:bannerAdView];
        }
    }

    void WindMillUnity_BannerAd_Dispose(void* bannerAdPtr) {
    #pragma clang diagnostic push
    #pragma clang diagnostic ignored "-Wunused-value"
        (__bridge_transfer WindMillUnityBannerAd *)bannerAdPtr;
    #pragma clang diagnostic pop
    }

#if defined (__cplusplus)
}
#endif


