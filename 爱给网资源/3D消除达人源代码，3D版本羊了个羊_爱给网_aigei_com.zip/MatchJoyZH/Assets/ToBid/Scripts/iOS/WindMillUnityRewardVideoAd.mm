//
//  WindMillUnityRewardVideoAd.mm
//  WindMillSDK
//
//  Created by Codi on 2021/5/20.
//  Copyright © 2021 Codi. All rights reserved.
//

#import <WindMillSDK/WindMillSDK.h>
#import "WindMillUnityUtils.h"

// IRewardVideoAdListener callbacks.
typedef void(*RewardVideoAd_OnError)(int code, const char* message, void* rewardedVideoAdPtr);
typedef void(*RewardVideoAd_OnRewardVideoAdLoad)(void* rewardVideoAd);

// IRewardAdInteractionListener callbacks.
typedef void(*RewardVideoAd_OnAdShow)(void* rewardedVideoAdPtr);
typedef void(*RewardVideoAd_OnAdClick)(void* rewardedVideoAdPtr);
typedef void(*RewardVideoAd_OnAdSkippedVideo)(void* rewardedVideoAdPtr);
typedef void(*RewardVideoAd_OnAdReward)(bool isCompletedView, char* trans_id, char* user_id, void* rewardedVideoAdPtr);
typedef void(*RewardVideoAd_OnAdClose)(void* rewardedVideoAdPtr);
typedef void(*RewardVideoAd_OnVideoEnd)(void* rewardedVideoAdPtr);
typedef void(*RewardVideoAd_OnVideoError)(int code, const char* message, void* rewardedVideoAdPtr);





@interface WindMillUnityRewardVideoAd : NSObject
@property (nonatomic, strong) NSString *name;
@property (nonatomic, strong) WindMillRewardVideoAd *rewardedVideoAd;
@property (nonatomic, assign) RewardVideoAd_OnError onError;
@property (nonatomic, assign) RewardVideoAd_OnRewardVideoAdLoad onRewardVideoAdLoad;
@property (nonatomic, assign) RewardVideoAd_OnAdShow onAdShow;
@property (nonatomic, assign) RewardVideoAd_OnAdClick onAdClick;
@property (nonatomic, assign) RewardVideoAd_OnAdSkippedVideo onAdSkippedVideo;
@property (nonatomic, assign) RewardVideoAd_OnAdClose onAdClose;
@property (nonatomic, assign) RewardVideoAd_OnAdReward onAdReward;
@property (nonatomic, assign) RewardVideoAd_OnVideoEnd onVideoEnd;
@property (nonatomic, assign) RewardVideoAd_OnVideoError onVideoError;
@end

@interface WindMillUnityRewardVideoAd()<WindMillRewardVideoAdDelegate>

@end

@implementation WindMillUnityRewardVideoAd

#pragma mark -  WindMillRewardVideoAdDelegate

/**
 This method is called when video ad material loaded successfully.
 */
- (void)rewardVideoAdDidLoad:(WindMillRewardVideoAd *)rewardVideoAd {
    if (self.onRewardVideoAdLoad) {
        self.onRewardVideoAdLoad((__bridge void*)self);
    }
}

/**
 This method is called when video ad materia failed to load.
 @param error : the reason of error
 */
- (void)rewardVideoAdDidLoad:(WindMillRewardVideoAd *)rewardVideoAd didFailWithError:(NSError *)error {
    if (self.onError) {
        self.onError((int)error.code, [error.localizedDescription UTF8String], (__bridge void*)self);
    }
}

/**
 This method is called when video ad slot will be showing.
 */
- (void)rewardVideoAdWillVisible:(WindMillRewardVideoAd *)rewardVideoAd {
//    SIGLogDebug(@"[WindMillDemo] %s -- placementId = %@", __func__, rewardVideoAd.placementId);
}

/**
 This method is called when video ad slot has been shown.
 */
- (void)rewardVideoAdDidVisible:(WindMillRewardVideoAd *)rewardVideoAd {
    if (self.onAdShow) {
        self.onAdShow((__bridge void*)self);
    }
}

/**
 This method is called when video ad is clicked.
 */
- (void)rewardVideoAdDidClick:(WindMillRewardVideoAd *)rewardVideoAd {
    if (self.onAdClick) {
        self.onAdClick((__bridge void*)self);
    }
}

/**
 This method is called when video ad is clicked skip button.
 */
- (void)rewardVideoAdDidClickSkip:(WindMillRewardVideoAd *)rewardVideoAd {
    if (self.onAdSkippedVideo) {
        self.onAdSkippedVideo((__bridge void*)self);
    }
}

/**
 This method is called when video ad is about to close.
 */
- (void)rewardVideoAd:(WindMillRewardVideoAd *)rewardVideoAd reward:(WindMillRewardInfo *)reward  {
    if (self.onAdReward) {
        self.onAdReward(reward.isCompeltedView,ToChar(reward.transId),ToChar(reward.userId) ,(__bridge void*)self);
    }
}


/**
 This method is called when video ad is about to close.
 */
- (void)rewardVideoAdDidClose:(WindMillRewardVideoAd *)rewardVideoAd {
    if (self.onAdClose) {
        self.onAdClose((__bridge void*)self);
    }
}

/**
 This method is called when video ad play completed or an error occurred.
 @param error : the reason of error
 */
- (void)rewardVideoAdDidPlayFinish:(WindMillRewardVideoAd *)rewardVideoAd didFailWithError:(NSError *)error {
    if (error) {
        if (self.onVideoError) {
            self.onVideoError((int)error.code, [error.localizedDescription UTF8String], (__bridge void*)self);
        }
    }else {
        if (self.onVideoEnd) {
            self.onVideoEnd((__bridge void*)self);
        }
    }
}

/**
 This method is called when return ads from sigmob ad server.
 */
- (void)rewardVideoAdServerResponse:(WindMillRewardVideoAd *)rewardVideoAd isFillAd:(BOOL)isFillAd {
//    SIGLogDebug(@"[WindMillDemo] %s -- isFillAd = %d, placementId = %@,", __func__, isFillAd, rewardVideoAd.placementId);
}


- (void)dealloc {
    self.rewardedVideoAd.delegate = nil;
    self.rewardedVideoAd = nil;
}



@end


#if defined (__cplusplus)
extern "C" {
#endif

    extern UIViewController * UnityGetGLViewController(void);

    void* WindMillUnity_NewWindMillRewardVideoAd(){
        WindMillUnityRewardVideoAd *instance = [[WindMillUnityRewardVideoAd alloc] init];
    #pragma clang diagnostic push
    #pragma clang diagnostic ignored "-Wunused-value"
        //retainCount +1
        (__bridge_retained void*)instance;
    #pragma clang diagnostic pop
        return (__bridge void*)instance;
    }

    void WindMillUnity_RewardVideoAd_Load
     (
      const char* placementId,
      const char* userID,
      const char* extra,
      void* rewardedVideoAdPtr) {
        WindMillAdRequest *request = [[WindMillAdRequest alloc] init];
        request.userId = [[NSString alloc] initWithUTF8String:userID?:"-2"];
        request.placementId = [[NSString alloc] initWithUTF8String:placementId?:""];
        
        id dic = ToDictionary(extra);
        
        if(dic != nil){
            if ([dic isKindOfClass: [NSDictionary class]]) {
                request.options = dic;
            }
        }
        
        WindMillUnityRewardVideoAd* instance = (__bridge WindMillUnityRewardVideoAd *)rewardedVideoAdPtr;
        WindMillRewardVideoAd *rewardedVideoAd = instance.rewardedVideoAd;
        if (rewardedVideoAd == nil) {
            rewardedVideoAd = [[WindMillRewardVideoAd alloc] initWithRequest :request];
            instance.rewardedVideoAd = rewardedVideoAd;
        }
        rewardedVideoAd.delegate = instance;
        [rewardedVideoAd loadAdData];
    }


    void WindMillUnity_RewardVideoAd_SetInteractionListener
    (
     void* rewardedVideoAdPtr,
     RewardVideoAd_OnError onError,
     RewardVideoAd_OnRewardVideoAdLoad onRewardVideoAdLoad,
     RewardVideoAd_OnAdShow onAdShow,
     RewardVideoAd_OnAdClick onAdClick,
     RewardVideoAd_OnAdSkippedVideo onAdSkippedVideo,
     RewardVideoAd_OnAdReward onAdReward,
     RewardVideoAd_OnAdClose onAdClose,
     RewardVideoAd_OnVideoEnd onVideoEnd,
     RewardVideoAd_OnVideoError onVideoError
     ) {
        WindMillUnityRewardVideoAd* instance = (__bridge WindMillUnityRewardVideoAd *)rewardedVideoAdPtr;
        instance.onError = onError;
        instance.onRewardVideoAdLoad = onRewardVideoAdLoad;
        instance.onAdShow = onAdShow;
        instance.onAdClick = onAdClick;
        instance.onAdSkippedVideo = onAdSkippedVideo;
        instance.onAdReward = onAdReward;
        instance.onAdClose = onAdClose;
        instance.onVideoEnd = onVideoEnd;
        instance.onVideoError = onVideoError;
    }

    BOOL WindMillUnity_RewardVideoAd_Ready(void* rewardedVideoAdPtr) {
        WindMillUnityRewardVideoAd* instance = (__bridge WindMillUnityRewardVideoAd *)rewardedVideoAdPtr;
        return [instance.rewardedVideoAd isAdReady];
        
    }


    const char* WindMillUnity_RewardVideoAd_CacheAdInfoList(void* ptr) {
        WindMillUnityRewardVideoAd* instance = (__bridge WindMillUnityRewardVideoAd *)ptr;
        WindMillRewardVideoAd *rewardAd = instance.rewardedVideoAd;
        if(rewardAd != nil){
            NSArray* adInfoList = [rewardAd getCacheAdInfoList];
            if(adInfoList != NULL && adInfoList.count>0){
                NSMutableArray *list =  [[NSMutableArray alloc] initWithCapacity:adInfoList.count];

                for (WindMillAdInfo *item in adInfoList) {
                    [list addObject:[item toJson]];
                }
                return ToJsonString(list);
            }
        }
        
        return NULL;
    }

    const char* WindMillUnity_RewardVideoAd_AdInfo(void* rewardedVideoAdPtr) {
        WindMillUnityRewardVideoAd* instance = (__bridge WindMillUnityRewardVideoAd *)rewardedVideoAdPtr;
        return ToChar([instance.rewardedVideoAd.adInfo toJson]);
    }


    void WindMillUnity_RewardVideoAd_ShowRewardVideoAd(void* rewardedVideoAdPtr) {
        WindMillUnityRewardVideoAd* instance = (__bridge WindMillUnityRewardVideoAd *)rewardedVideoAdPtr;
        [instance.rewardedVideoAd showAdFromRootViewController:UnityGetGLViewController() options:nil];
    }

    void WindMillUnity_RewardVideoAd_Dispose(void* rewardedVideoAdPtr) {
    #pragma clang diagnostic push
    #pragma clang diagnostic ignored "-Wunused-value"
        (__bridge_transfer WindMillUnityRewardVideoAd *)rewardedVideoAdPtr;
    #pragma clang diagnostic pop
    }

#if defined (__cplusplus)
}
#endif


