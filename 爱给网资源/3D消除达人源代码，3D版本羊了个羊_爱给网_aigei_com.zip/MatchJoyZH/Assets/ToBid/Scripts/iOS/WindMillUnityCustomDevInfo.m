//
//  WindMillUnityCustomDevInfo.m
//
//  Created by Codi on 2022/11/22.
//

#import "WindMillUnityCustomDevInfo.h"
#import <WindMillSDK/WindMillSDK.h>

@interface WindMillUnityCustomDevInfo ()

@end

@implementation WindMillUnityCustomDevInfo

- (NSString *)getDevIdfa {
    return self.customIDFA;
}

- (BOOL)isCanUseIdfa {
    return self.canUseIdfa;
}

- (BOOL)isCanUseLocation {
    return self.canUseLocation;
}

- (AWMLocation *)getAWMLocation {
    
    return self.customLocation;
}

@end
