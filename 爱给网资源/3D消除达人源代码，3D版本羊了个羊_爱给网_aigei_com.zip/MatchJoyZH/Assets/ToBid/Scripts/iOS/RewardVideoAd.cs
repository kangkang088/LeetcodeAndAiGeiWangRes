﻿namespace WindMill.Advertisements
{
#if  !UNITY_EDITOR && UNITY_IOS

    using System;
    using System.Collections.Generic;
    using System.Runtime.InteropServices;
    using UnityEngine;

    public sealed class RewardVideoAd : IDisposable
    {
        private static Dictionary<IntPtr, RewardVideoAd> ads =
            new Dictionary<IntPtr, RewardVideoAd>();

        private delegate void RewardVideoAd_OnError(int code, string message, IntPtr rewardVideoAd);
        private delegate void RewardVideoAd_OnRewardVideoAdLoad(IntPtr rewardVideoAd);
        private delegate void RewardVideoAd_OnAdShow(IntPtr rewardVideoAd);
        private delegate void RewardVideoAd_OnAdClick(IntPtr rewardVideoAd);
        private delegate void RewardVideoAd_OnAdSkippedVideo(IntPtr rewardVideoAd);
        private delegate void RewardVideoAd_OnAdReward(bool isCompletedView, string trans_id, string user_id, IntPtr rewardVideoAd);
        private delegate void RewardVideoAd_OnAdClose(IntPtr rewardVideoAd);
        private delegate void RewardVideoAd_OnVideoEnd(IntPtr rewardVideoAd);
        private delegate void RewardVideoAd_OnVideoError(int code, string message, IntPtr rewardVideoAd);

        
        private IntPtr rewardVideoAd;
        private IRewardVideoAdListener listener;
        private AdInfo adInfo;
        private Request request;


        public string PlacementId {
            get
            {
                return this.request.PlacementId;
            }
        }


        public RewardVideoAd(Request request)
        {
            this.request = request;
            this.rewardVideoAd = WindMillUnity_NewWindMillRewardVideoAd();
            ads.Add(this.rewardVideoAd, this);

        }

        public void Dispose()
        {
            this.Dispose(true);
            GC.SuppressFinalize(this);
        }

        public void Dispose(bool disposing)
        {
            ads.Remove(this.rewardVideoAd);
            WindMillUnity_RewardVideoAd_Dispose(this.rewardVideoAd);
        }
        
        public AdInfo GetAdInfo(){
           return this.adInfo; 
        }




        public List<AdInfo> GetCacheAdInfoList()
        {

            string adInfoListString = WindMillUnity_RewardVideoAd_CacheAdInfoList(this.rewardVideoAd);
            Debug.Log("GetCacheAdInfoList " + adInfoListString);

            return AdInfo.CreateAdInfoListFromeJson(adInfoListString);
        }

        private void updateAdInfo(IntPtr intersitialAd){
             if(intersitialAd == null){
                 this.adInfo = null;
             }else{
                string adinfoPtr = WindMillUnity_RewardVideoAd_AdInfo(intersitialAd);
                this.adInfo = AdInfo.CreateAdInfoFromJson(adinfoPtr);
             }
       
        }
        /// <summary>
        /// Load reward video Ad.
        /// </summary>
        public void LoadAd()
        {
            string extra = Json.Serialize(request.options);
            Debug.Log("req.options.toJson = " + extra);
            WindMillUnity_RewardVideoAd_Load(
                request.PlacementId,
                request.UserId,
                extra, this.rewardVideoAd);
        
        }

        /// <summary>
        /// Sets the interaction listener for this Ad.
        /// </summary>
        public void SetRewardAdListener(IRewardVideoAdListener listener)
        {
            this.listener = listener;
            WindMillUnity_RewardVideoAd_SetInteractionListener(
                this.rewardVideoAd,
                RewardVideoAd_OnErrorMethod,
                RewardVideoAd_OnRewardVideoAdLoadMethod,
                RewardVideoAd_OnAdShowMethod,
                RewardVideoAd_OnAdrClickMethod,
                RewardVideoAd_OnAdSkippedVideoMethod,
                RewardVideoAd_OnAdRewardMethod,
                RewardVideoAd_OnAdCloseMethod,
                RewardVideoAd_OnVideoEndMethod,
                RewardVideoAd_OnVideoErrorMethod
                );
        }


        /// <summary>
        /// Show the reward video Ad.
        /// </summary>
        public void ShowAd()
        {
            WindMillUnity_RewardVideoAd_ShowRewardVideoAd(this.rewardVideoAd);
        }

        public bool Ready()
        {
            return WindMillUnity_RewardVideoAd_Ready(this.rewardVideoAd);
        }


        [DllImport("__Internal")]
        private static extern IntPtr WindMillUnity_NewWindMillRewardVideoAd();

        [DllImport("__Internal")]
        private static extern string WindMillUnity_RewardVideoAd_AdInfo(IntPtr rewardVideoAd);

        [DllImport("__Internal")]
        private static extern string WindMillUnity_RewardVideoAd_CacheAdInfoList(IntPtr rewardVideoAd);

        [DllImport("__Internal")]
        private static extern bool WindMillUnity_RewardVideoAd_Ready(
            IntPtr rewardVideoAd);


        [DllImport("__Internal")]
        private static extern void WindMillUnity_RewardVideoAd_Dispose(
            IntPtr rewardVideoAd);

        [DllImport("__Internal")]
        private static extern void WindMillUnity_RewardVideoAd_Load(
            string placementId,
            string userID,
            string extra,
            IntPtr rewardVideoAd);

        [DllImport("__Internal")]
        private static extern void WindMillUnity_RewardVideoAd_SetInteractionListener(
            IntPtr rewardVideoAd,
            RewardVideoAd_OnError onError,
            RewardVideoAd_OnRewardVideoAdLoad onRewardVideoAdLoad,
            RewardVideoAd_OnAdShow onAdShow,
            RewardVideoAd_OnAdClick OnAdClick,
            RewardVideoAd_OnAdSkippedVideo onAdSkippedVideo,
            RewardVideoAd_OnAdReward onAdReward,
            RewardVideoAd_OnAdClose onAdClose,
            RewardVideoAd_OnVideoEnd onVideoEnd,
            RewardVideoAd_OnVideoError onVideoError
            );

        [DllImport("__Internal")]
        private static extern void WindMillUnity_RewardVideoAd_ShowRewardVideoAd(
            IntPtr rewardVideoAd);

        /***
         * Load Listener
         */
        [AOT.MonoPInvokeCallback(typeof(RewardVideoAd_OnError))]
        private static void RewardVideoAd_OnErrorMethod(int code, string message, IntPtr rewardVideoAd)
        {
            RewardVideoAd rewardVideoObj;
            if (ads.TryGetValue(rewardVideoAd, out rewardVideoObj))
            {
                Error error = new Error(code, message);
                rewardVideoObj.listener?.OnAdError(rewardVideoObj, error);
            }
            else
            {
                Debug.LogError("The OnAdError can not find the context");
            }
        }


        [AOT.MonoPInvokeCallback(typeof(RewardVideoAd_OnRewardVideoAdLoad))]
        private static void RewardVideoAd_OnRewardVideoAdLoadMethod(IntPtr rewardVideoAd)
        {
            RewardVideoAd rewardVideoObj;
            if (ads.TryGetValue(rewardVideoAd, out rewardVideoObj))
            {
                rewardVideoObj.listener?.OnAdLoad(rewardVideoObj);
            }
            else
            {
                Debug.LogError("The OnAdLoad can not find the context");
            }
        }


        /***
         * Interaction Listener
         */
        [AOT.MonoPInvokeCallback(typeof(RewardVideoAd_OnAdShow))]
        private static void RewardVideoAd_OnAdShowMethod(IntPtr rewardVideoAd)
        {
            RewardVideoAd rewardVideoObj;
            if (ads.TryGetValue(rewardVideoAd, out rewardVideoObj))
            {
                rewardVideoObj.updateAdInfo(rewardVideoAd);

                rewardVideoObj.listener?.OnAdShow(rewardVideoObj);
            }
            else
            {
                Debug.LogError("The OnAdShow can not find the context.");
            }
        }

        [AOT.MonoPInvokeCallback(typeof(RewardVideoAd_OnAdClick))]
        private static void RewardVideoAd_OnAdrClickMethod(IntPtr rewardVideoAd)
        {
            RewardVideoAd rewardVideoObj;
            if (ads.TryGetValue(rewardVideoAd, out rewardVideoObj))
            {
                rewardVideoObj.listener?.OnAdClick(rewardVideoObj);
            }
            else
            {
                Debug.LogError("The OnAdClick can not find the context.");
            }
        }

        [AOT.MonoPInvokeCallback(typeof(RewardVideoAd_OnAdSkippedVideo))]
        private static void RewardVideoAd_OnAdSkippedVideoMethod(IntPtr rewardVideoAd)
        {
            RewardVideoAd rewardVideoObj;
            if (ads.TryGetValue(rewardVideoAd, out rewardVideoObj))
            {
                rewardVideoObj.listener?.OnSkippedVideo(rewardVideoObj);
            }
            else
            {
                Debug.LogError("The OnSkippedVideo can not find the context.");
            }
        }

        [AOT.MonoPInvokeCallback(typeof(RewardVideoAd_OnAdReward))]
        private static void RewardVideoAd_OnAdRewardMethod(bool isCompletedView, string trans_id, string user_id, IntPtr rewardVideoAd)
        {
            RewardVideoAd rewardVideoObj;
            if (ads.TryGetValue(rewardVideoAd, out rewardVideoObj))
            {
                RewardInfo info = new RewardInfo();
                info.IsReward = isCompletedView;
                info.TransId = trans_id;
                info.UserId = user_id;

                rewardVideoObj.listener?.OnAdReward(rewardVideoObj, info);
               
            }
            else
            {
                Debug.LogError("The OnAdReward can not find the context.");
            }
        }


        [AOT.MonoPInvokeCallback(typeof(RewardVideoAd_OnAdClose))]
        private static void RewardVideoAd_OnAdCloseMethod( IntPtr rewardVideoAd)
        {
            RewardVideoAd rewardVideoObj;
            if (ads.TryGetValue(rewardVideoAd, out rewardVideoObj))
            {
             
                rewardVideoObj.listener?.OnAdClose(rewardVideoObj);
               
            }
            else
            {
                Debug.LogError("The OnAdClose can not find the context.");
            }
        }


        [AOT.MonoPInvokeCallback(typeof(RewardVideoAd_OnVideoEnd))]
        private static void RewardVideoAd_OnVideoEndMethod(IntPtr rewardVideoAd)
        {
            RewardVideoAd rewardVideoObj;
            if (ads.TryGetValue(rewardVideoAd, out rewardVideoObj))
            {
                rewardVideoObj.listener?.OnVideoEnd(rewardVideoObj);
            }
            else
            {
                Debug.LogError(
                    "The OnVideoEnd can not find the context.");
            }
        }


        [AOT.MonoPInvokeCallback(typeof(RewardVideoAd_OnVideoError))]
        private static void RewardVideoAd_OnVideoErrorMethod(int code, string message, IntPtr rewardVideoAd)
        {
            RewardVideoAd rewardVideoObj;
            if (ads.TryGetValue(rewardVideoAd, out rewardVideoObj))
            {
                Error error = new Error(code, message);
                rewardVideoObj.listener?.OnVideoError(rewardVideoObj, error);
            }
            else
            {
                Debug.LogError(
                    "The OnVideoError can not find the context.");
            }
        }
    }
#endif

}