﻿#if UNITY_IOS
#if UNITY_EDITOR
using UnityEditor;
using UnityEditor.Callbacks;
#endif
using System.IO;

using UnityEditor.iOS.Xcode;


public static class XCodePostProcess
{

    [PostProcessBuild(1)]
    public static void OnPostprocessBuild(BuildTarget BuildTarget, string path)
    {
        if (BuildTarget == BuildTarget.iOS)
        {

            string projPath = PBXProject.GetPBXProjectPath(path);

            // 项目设置
            PBXProject pbxProject = new PBXProject();
            pbxProject.ReadFromString(File.ReadAllText(projPath));
            string targetGuid = pbxProject.GetUnityFrameworkTargetGuid();
            // 关闭Bitcode
            pbxProject.SetBuildProperty(targetGuid, "ENABLE_BITCODE", "NO");
            
            // 添加framwrok
            pbxProject.AddFrameworkToProject(targetGuid, "SafariServices.framework", false);

            pbxProject.AddFrameworkToProject(targetGuid, "CFNetwork.framework", false);

            pbxProject.AddFrameworkToProject(targetGuid, "AVFoundation.framework", false);

            pbxProject.AddFrameworkToProject(targetGuid, "WebKit.framework", false);

            pbxProject.AddFrameworkToProject(targetGuid, "StoreKit.framework", false);

            pbxProject.AddFrameworkToProject(targetGuid, "Security.framework", false);

            pbxProject.AddFrameworkToProject(targetGuid, "CoreTelephony.framework", false);

            pbxProject.AddFrameworkToProject(targetGuid, "SystemConfiguration.framework", false);

            pbxProject.AddFrameworkToProject(targetGuid, "QuartzCore.framework", false);

            pbxProject.AddFrameworkToProject(targetGuid, "CoreLocation.framework", false);

            pbxProject.AddFrameworkToProject(targetGuid, "AdSupport.framework", false);

            pbxProject.AddFrameworkToProject(targetGuid, "Accelerate.framework", false);

            pbxProject.AddFrameworkToProject(targetGuid, "ImageIO.framework", false);

            pbxProject.AddFrameworkToProject(targetGuid, "CoreMotion.framework", false);

            pbxProject.AddFrameworkToProject(targetGuid, "CoreMedia.framework", false);

            pbxProject.AddFrameworkToProject(targetGuid, "MediaPlayer.framework", false);

            pbxProject.AddFrameworkToProject(targetGuid, "MobileCoreServices.framework", false);

            pbxProject.AddFrameworkToProject(targetGuid, "MessageUI.framework", false);

            pbxProject.AddFrameworkToProject(targetGuid, "AudioToolbox.framework", false);

            pbxProject.AddFrameworkToProject(targetGuid, "CoreGraphics.framework", false);

            pbxProject.AddFrameworkToProject(targetGuid, "DeviceCheck.framework", false);



            //添加lib
            AddLibToProject(pbxProject, targetGuid, "libxml2.tbd");

            AddLibToProject(pbxProject, targetGuid, "libz.tbd");

            AddLibToProject(pbxProject, targetGuid, "libsqlite3.tbd");

            AddLibToProject(pbxProject, targetGuid, "libc++.tbd");

            AddLibToProject(pbxProject, targetGuid, "libresolv.9.tbd");

            AddLibToProject(pbxProject, targetGuid, "libxml2.2.tbd");

            AddLibToProject(pbxProject, targetGuid, "libiconv.tbd");

            AddLibToProject(pbxProject, targetGuid, "libbz2.1.0.tbd");

            AddLibToProject(pbxProject, targetGuid, "libz.1.2.5.tbd");

            AddLibToProject(pbxProject, targetGuid, "libc++abi.tbd");
            
            
            // OTHER_LDFLAGS
            pbxProject.AddBuildProperty(targetGuid, "OTHER_LDFLAGS", "-ObjC");
            pbxProject.AddBuildProperty(targetGuid, "OTHER_LDFLAGS", "-l\"c++\"");
            pbxProject.AddBuildProperty(targetGuid, "OTHER_LDFLAGS", "-l\"c++abi\"");
            pbxProject.AddBuildProperty(targetGuid, "OTHER_LDFLAGS", "-l\"sqlite3\"");
            pbxProject.AddBuildProperty(targetGuid, "OTHER_LDFLAGS", "-l\"z\"");

            
            
            File.WriteAllText(projPath, pbxProject.WriteToString());
            

            string plistPath = path + "/Info.plist";
            PlistDocument plist = new PlistDocument();
            plist.ReadFromString(File.ReadAllText(plistPath));
            // idfa 说明
            plist.root.SetString("NSUserTrackingUsageDescription", "该标识符将用于向提供更好的广告体验。");
            // 网络设置
            plist.root.CreateDict("NSAppTransportSecurity").SetBoolean("NSAllowsArbitraryLoads",true);
              // google广告设置
            plist.root.SetString("GADApplicationIdentifier","ca-app-pub-1184860168464753~3235066910");

             var skaditems = plist.root.CreateArray("SKAdNetworkItems");
            skaditems.AddDict().SetString("SKAdNetworkIdentifier","cstr6suwn9.skadnetwork");
            skaditems.AddDict().SetString("SKAdNetworkIdentifier","2u9pt9hc89.skadnetwork");
            skaditems.AddDict().SetString("SKAdNetworkIdentifier","4468km3ulz.skadnetwork");
            skaditems.AddDict().SetString("SKAdNetworkIdentifier","4fzdc2evr5.skadnetwork");
            skaditems.AddDict().SetString("SKAdNetworkIdentifier","7ug5zh24hu.skadnetwork");
            skaditems.AddDict().SetString("SKAdNetworkIdentifier","8s468mfl3y.skadnetwork");
            skaditems.AddDict().SetString("SKAdNetworkIdentifier","9rd848q2bz.skadnetwork");
            skaditems.AddDict().SetString("SKAdNetworkIdentifier","9t245vhmpl.skadnetwork");
            skaditems.AddDict().SetString("SKAdNetworkIdentifier","av6w8kgt66.skadnetwork");
            skaditems.AddDict().SetString("SKAdNetworkIdentifier","f38h382jlk.skadnetwork");
            skaditems.AddDict().SetString("SKAdNetworkIdentifier","hs6bdukanm.skadnetwork");
            skaditems.AddDict().SetString("SKAdNetworkIdentifier","kbd757ywx3.skadnetwork");
            skaditems.AddDict().SetString("SKAdNetworkIdentifier","ludvb6z3bs.skadnetwork");
            skaditems.AddDict().SetString("SKAdNetworkIdentifier","m8dbw4sv7c.skadnetwork");
            skaditems.AddDict().SetString("SKAdNetworkIdentifier","mlmmfzh3r3.skadnetwork");
            skaditems.AddDict().SetString("SKAdNetworkIdentifier","prcb7njmu6.skadnetwork");
            skaditems.AddDict().SetString("SKAdNetworkIdentifier","t38b2kh725.skadnetwork");
            skaditems.AddDict().SetString("SKAdNetworkIdentifier","tl55sbb4fm.skadnetwork");
            skaditems.AddDict().SetString("SKAdNetworkIdentifier","wzmmz9fp6w.skadnetwork");
            skaditems.AddDict().SetString("SKAdNetworkIdentifier","yclnxrl5pm.skadnetwork");
            skaditems.AddDict().SetString("SKAdNetworkIdentifier","ydx93a7ass.skadnetwork");
            skaditems.AddDict().SetString("SKAdNetworkIdentifier","KBD757YWX3.skadnetwork");
            skaditems.AddDict().SetString("SKAdNetworkIdentifier","wg4vff78zm.skadnetwork");
            skaditems.AddDict().SetString("SKAdNetworkIdentifier","737z793b9f.skadnetwork");
            skaditems.AddDict().SetString("SKAdNetworkIdentifier","ydx93a7ass.skadnetwork");
            skaditems.AddDict().SetString("SKAdNetworkIdentifier","prcb7njmu6.skadnetwork");
            skaditems.AddDict().SetString("SKAdNetworkIdentifier","7UG5ZH24HU.skadnetwork");
            skaditems.AddDict().SetString("SKAdNetworkIdentifier","44jx6755aq.skadnetwork");
            skaditems.AddDict().SetString("SKAdNetworkIdentifier","2U9PT9HC89.skadnetwork");
            skaditems.AddDict().SetString("SKAdNetworkIdentifier","W9Q455WK68.skadnetwork");
            skaditems.AddDict().SetString("SKAdNetworkIdentifier","YCLNXRL5PM.skadnetwork");
            skaditems.AddDict().SetString("SKAdNetworkIdentifier","TL55SBB4FM.skadnetwork");
            skaditems.AddDict().SetString("SKAdNetworkIdentifier","8s468mfl3y.skadnetwork");
            skaditems.AddDict().SetString("SKAdNetworkIdentifier","GLQZH8VGBY.skadnetwork");
            skaditems.AddDict().SetString("SKAdNetworkIdentifier","c6k4g5qg8m.skadnetwork");
            skaditems.AddDict().SetString("SKAdNetworkIdentifier","mlmmfzh3r3.skadnetwork");
            skaditems.AddDict().SetString("SKAdNetworkIdentifier","4PFYVQ9L8R.skadnetwork");
            skaditems.AddDict().SetString("SKAdNetworkIdentifier","av6w8kgt66.skadnetwork");
            skaditems.AddDict().SetString("SKAdNetworkIdentifier","6xzpu9s2p8.skadnetwork");
            skaditems.AddDict().SetString("SKAdNetworkIdentifier","hs6bdukanm.skadnetwork");
            skaditems.AddDict().SetString("SKAdNetworkIdentifier","gta9lk7p23.skadnetwork");
            skaditems.AddDict().SetString("SKAdNetworkIdentifier","4fzdc2evr5.skadnetwork");
            skaditems.AddDict().SetString("SKAdNetworkIdentifier","c6k4g5qg8m.skadnetwork");
            skaditems.AddDict().SetString("SKAdNetworkIdentifier","f38h382jlk.skadnetwork");
            skaditems.AddDict().SetString("SKAdNetworkIdentifier","ydx93a7ass.skadnetwork");
            skaditems.AddDict().SetString("SKAdNetworkIdentifier","4468km3ulz.skadnetwork");
            skaditems.AddDict().SetString("SKAdNetworkIdentifier","bvpn9ufa9b.skadnetwork");
            skaditems.AddDict().SetString("SKAdNetworkIdentifier","glqzh8vgby.skadnetwork");
            skaditems.AddDict().SetString("SKAdNetworkIdentifier","yclnxrl5pm.skadnetwork");
            skaditems.AddDict().SetString("SKAdNetworkIdentifier","cstr6suwn9.skadnetwork");
            skaditems.AddDict().SetString("SKAdNetworkIdentifier","2u9pt9hc89.skadnetwork");
            skaditems.AddDict().SetString("SKAdNetworkIdentifier","prcb7njmu6.skadnetwork");
            skaditems.AddDict().SetString("SKAdNetworkIdentifier","lr83yxwka7.skadnetwork");
            skaditems.AddDict().SetString("SKAdNetworkIdentifier","5a6flpkh64.skadnetwork");
            skaditems.AddDict().SetString("SKAdNetworkIdentifier","24t9a8vw3c.skadnetwork");
            skaditems.AddDict().SetString("SKAdNetworkIdentifier","238da6jt44.skadnetwork");
            skaditems.AddDict().SetString("SKAdNetworkIdentifier","22mmun2rn5.skadnetwork");
            skaditems.AddDict().SetString("SKAdNetworkIdentifier","tl55sbb4fm.skadnetwork");
            skaditems.AddDict().SetString("SKAdNetworkIdentifier","m8dbw4sv7c.skadnetwork");
            skaditems.AddDict().SetString("SKAdNetworkIdentifier","f73kdq92p3.skadnetwork");
            skaditems.AddDict().SetString("SKAdNetworkIdentifier","v79kvwwj4g.skadnetwork");
            skaditems.AddDict().SetString("SKAdNetworkIdentifier","8s468mfl3y.skadnetwork");
            skaditems.AddDict().SetString("SKAdNetworkIdentifier","hs6bdukanm.skadnetwork");
            skaditems.AddDict().SetString("SKAdNetworkIdentifier","424m5254lk.skadnetwork");
            skaditems.AddDict().SetString("SKAdNetworkIdentifier","488r3q3dtq.skadnetwork");
            skaditems.AddDict().SetString("SKAdNetworkIdentifier","zmvfpc5aq8.skadnetwork");
            skaditems.AddDict().SetString("SKAdNetworkIdentifier","5lm9lj6jb7.skadnetwork");
            skaditems.AddDict().SetString("SKAdNetworkIdentifier","3sh42y64q3.skadnetwork");
            skaditems.AddDict().SetString("SKAdNetworkIdentifier","mlmmfzh3r3.skadnetwork");
            skaditems.AddDict().SetString("SKAdNetworkIdentifier","7ug5zh24hu.skadnetwork");
            skaditems.AddDict().SetString("SKAdNetworkIdentifier","3RD42EKR43.skadnetwork");
            skaditems.AddDict().SetString("SKAdNetworkIdentifier","wg4vff78zm.skadnetwork");
            skaditems.AddDict().SetString("SKAdNetworkIdentifier","44n7hlldy6.skadnetwork");
            skaditems.AddDict().SetString("SKAdNetworkIdentifier","v72qych5uu.skadnetwork");
            skaditems.AddDict().SetString("SKAdNetworkIdentifier","av6w8kgt66.skadnetwork");
            skaditems.AddDict().SetString("SKAdNetworkIdentifier","578prtvx9j.skadnetwork");
            skaditems.AddDict().SetString("SKAdNetworkIdentifier","4dzt52r2t5.skadnetwork");
            skaditems.AddDict().SetString("SKAdNetworkIdentifier","9t245vhmpl.skadnetwork");
            skaditems.AddDict().SetString("SKAdNetworkIdentifier","kbd757ywx3.skadnetwork");
            skaditems.AddDict().SetString("SKAdNetworkIdentifier","wzmmz9fp6w.skadnetwork");
            skaditems.AddDict().SetString("SKAdNetworkIdentifier","ppxm28t8ap.skadnetwork");
            skaditems.AddDict().SetString("SKAdNetworkIdentifier","9rd848q2bz.skadnetwork");
            skaditems.AddDict().SetString("SKAdNetworkIdentifier","t38b2kh725.skadnetwork");
            skaditems.AddDict().SetString("SKAdNetworkIdentifier","4pfyvq9l8r.skadnetwork");
            skaditems.AddDict().SetString("SKAdNetworkIdentifier","44jx6755aq.skadnetwork");

            plist.WriteToFile (plistPath);

        }
    }

    //添加lib方法
    public static void AddLibToProject(PBXProject inst, string targetGuid, string lib)
    {
        string fileGuid = inst.AddFile("usr/lib/" + lib, "Frameworks/" + lib, PBXSourceTree.Sdk);
        inst.AddFileToBuild(targetGuid, fileGuid);
    }

    

}
#endif